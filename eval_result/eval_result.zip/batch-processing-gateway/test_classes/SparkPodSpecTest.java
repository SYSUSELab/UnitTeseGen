package com.apple.spark.operator;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.*;
import static org.mockito.Mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@ExtendWith(MockitoExtension.class)
class SparkPodSpecTest {
    private SparkPodSpec sparkPodSpec;
    private SparkPodSpec anotherPodSpec;
    
    // Mock dependencies if needed
    @Mock
    private SecurityContext mockSecurityContext;
    @Mock
    private Affinity mockAffinity;
    @Mock
    private PodDNSConfig mockDnsConfig;
    @Mock
    private VolumeMount mockVolumeMount;
    @Mock
    private EnvVar mockEnvVar;

    @BeforeAll
    static void setupBeforeAll() {
        // One-time setup if needed
    }

    @BeforeEach
    void setupBeforeEach() {
        MockitoAnnotations.openMocks(this);
        
        sparkPodSpec = new SparkPodSpec();
        anotherPodSpec = new SparkPodSpec();
        
        // Initialize test data
        List<EnvVar> envVars = new ArrayList<>();
        envVars.add(mockEnvVar);
        
        Map<String, String> labels = new HashMap<>();
        labels.put("key1", "value1");
        
        Map<String, String> annotations = new HashMap<>();
        annotations.put("key1", "value1");
        
        List<VolumeMount> volumeMounts = new ArrayList<>();
        volumeMounts.add(mockVolumeMount);
        
        // Set values for anotherPodSpec
        anotherPodSpec.setCores(4);
        anotherPodSpec.setCoreRequest("1");
        anotherPodSpec.setCoreLimit("2");
        anotherPodSpec.setMemory("4g");
        anotherPodSpec.setMemoryOverhead("1g");
        anotherPodSpec.setImage("test-image");
        anotherPodSpec.setEnv(envVars);
        anotherPodSpec.setLabels(labels);
        anotherPodSpec.setAnnotations(annotations);
        anotherPodSpec.setTerminationGracePeriodSeconds(30L);
        anotherPodSpec.setServiceAccount("test-service-account");
        anotherPodSpec.setVolumeMounts(volumeMounts);
        anotherPodSpec.setSecurityContext(mockSecurityContext);
        anotherPodSpec.setAffinity(mockAffinity);
        anotherPodSpec.setDnsConfig(mockDnsConfig);
        anotherPodSpec.setJavaOptions("-Xmx2g");
    }

    @AfterEach
    void teardownAfterEach() {
        // Clean up if needed
        sparkPodSpec = null;
        anotherPodSpec = null;
    }

    @AfterAll
    static void teardownAfterAll() {
        // Final cleanup if needed
    }

    @Test
    @DisplayName("copyFrom should copy all non-null fields from source to target")
    void copyFrom_shouldCopyAllNonNullFields() {
        // Act
        sparkPodSpec.copyFrom(anotherPodSpec);

        // Assert
        assertEquals(anotherPodSpec.getCores(), sparkPodSpec.getCores());
        assertEquals(anotherPodSpec.getCoreLimit(), sparkPodSpec.getCoreLimit());
        assertEquals(anotherPodSpec.getMemory(), sparkPodSpec.getMemory());
        assertEquals(anotherPodSpec.getMemoryOverhead(), sparkPodSpec.getMemoryOverhead());
        assertEquals(anotherPodSpec.getImage(), sparkPodSpec.getImage());
        assertEquals(anotherPodSpec.getTerminationGracePeriodSeconds(), sparkPodSpec.getTerminationGracePeriodSeconds());
        assertEquals(anotherPodSpec.getServiceAccount(), sparkPodSpec.getServiceAccount());
        assertEquals(anotherPodSpec.getSecurityContext(), sparkPodSpec.getSecurityContext());
        assertEquals(anotherPodSpec.getAffinity(), sparkPodSpec.getAffinity());
        assertEquals(anotherPodSpec.getCoreRequest(), sparkPodSpec.getCoreRequest());
        assertEquals(anotherPodSpec.getJavaOptions(), sparkPodSpec.getJavaOptions());

        // Verify collections are copied as new instances
        assertNotSame(anotherPodSpec.getEnv(), sparkPodSpec.getEnv());
        assertEquals(anotherPodSpec.getEnv(), sparkPodSpec.getEnv());
        
        assertNotSame(anotherPodSpec.getLabels(), sparkPodSpec.getLabels());
        assertEquals(anotherPodSpec.getLabels(), sparkPodSpec.getLabels());
        
        assertNotSame(anotherPodSpec.getAnnotations(), sparkPodSpec.getAnnotations());
        assertEquals(anotherPodSpec.getAnnotations(), sparkPodSpec.getAnnotations());
        
        assertNotSame(anotherPodSpec.getVolumeMounts(), sparkPodSpec.getVolumeMounts());
        assertEquals(anotherPodSpec.getVolumeMounts(), sparkPodSpec.getVolumeMounts());
    }

    @Test
    @DisplayName("copyFrom should handle null source fields correctly")
    void copyFrom_shouldHandleNullSourceFields() {
        // Arrange - create a source spec with all null fields
        SparkPodSpec nullSource = new SparkPodSpec();
        
        // Act
        sparkPodSpec.copyFrom(nullSource);

        // Assert all fields remain unchanged (null by default in new instance)
        assertNull(sparkPodSpec.getCores());
        assertNull(sparkPodSpec.getCoreLimit());
        assertNull(sparkPodSpec.getMemory());
        assertNull(sparkPodSpec.getMemoryOverhead());
        assertNull(sparkPodSpec.getImage());
        assertNull(sparkPodSpec.getEnv());
        assertNull(sparkPodSpec.getLabels());
        assertNull(sparkPodSpec.getAnnotations());
        assertNull(sparkPodSpec.getTerminationGracePeriodSeconds());
        assertNull(sparkPodSpec.getServiceAccount());
        assertNull(sparkPodSpec.getVolumeMounts());
        assertNull(sparkPodSpec.getSecurityContext());
        assertNull(sparkPodSpec.getAffinity());
        assertNull(sparkPodSpec.getCoreRequest());
        assertNull(sparkPodSpec.getJavaOptions());
    }

    @Test
    @DisplayName("copyFrom should create new collection instances when source collections are not null")
    void copyFrom_shouldCreateNewCollectionInstances() {
        // Act
        sparkPodSpec.copyFrom(anotherPodSpec);

        // Assert that collections are new instances
        assertNotNull(sparkPodSpec.getEnv());
        assertNotSame(anotherPodSpec.getEnv(), sparkPodSpec.getEnv());
        
        assertNotNull(sparkPodSpec.getLabels());
        assertNotSame(anotherPodSpec.getLabels(), sparkPodSpec.getLabels());
        
        assertNotNull(sparkPodSpec.getAnnotations());
        assertNotSame(anotherPodSpec.getAnnotations(), sparkPodSpec.getAnnotations());
        
        assertNotNull(sparkPodSpec.getVolumeMounts());
        assertNotSame(anotherPodSpec.getVolumeMounts(), sparkPodSpec.getVolumeMounts());
    }

    @Test
    @DisplayName("copyFrom should set collection fields to null when source collections are null")
    void copyFrom_shouldSetCollectionsToNullWhenSourceIsNull() {
        // Arrange - set some collections to null in source
        anotherPodSpec.setEnv(null);
        anotherPodSpec.setLabels(null);
        anotherPodSpec.setAnnotations(null);
        anotherPodSpec.setVolumeMounts(null);

        // Act
        sparkPodSpec.copyFrom(anotherPodSpec);

        // Assert
        assertNull(sparkPodSpec.getEnv());
        assertNull(sparkPodSpec.getLabels());
        assertNull(sparkPodSpec.getAnnotations());
        assertNull(sparkPodSpec.getVolumeMounts());
    }

    @Test
    @DisplayName("copyFrom should not throw exception when source is null")
    void copyFrom_shouldNotThrowExceptionWhenSourceIsNull() {
        // Act & Assert
        assertDoesNotThrow(() -> sparkPodSpec.copyFrom(null));
    }

    @Test
    @DisplayName("copyFrom should copy primitive fields even when they are default values")
    void copyFrom_shouldCopyPrimitiveFieldsWithDefaultValues() {
        // Arrange - set primitive fields to default values
        anotherPodSpec.setTerminationGracePeriodSeconds(0L);
        anotherPodSpec.setServiceAccount("");

        // Act
        sparkPodSpec.copyFrom(anotherPodSpec);

        // Assert
        assertEquals(0L, sparkPodSpec.getTerminationGracePeriodSeconds());
        assertEquals("", sparkPodSpec.getServiceAccount());
    }

    @Test
    @DisplayName("copyFrom should overwrite existing values in target")
    void copyFrom_shouldOverwriteExistingValues() {
        // Arrange - set some initial values in target
        sparkPodSpec.setCores(2);
        sparkPodSpec.setMemory("2g");
        List<EnvVar> existingEnv = new ArrayList<>();
        existingEnv.add(new EnvVar("EXISTING", "VALUE"));
        sparkPodSpec.setEnv(existingEnv);

        // Act
        sparkPodSpec.copyFrom(anotherPodSpec);

        // Assert values are overwritten
        assertEquals(anotherPodSpec.getCores(), sparkPodSpec.getCores());
        assertEquals(anotherPodSpec.getMemory(), sparkPodSpec.getMemory());
        assertEquals(anotherPodSpec.getEnv(), sparkPodSpec.getEnv());
    }
}