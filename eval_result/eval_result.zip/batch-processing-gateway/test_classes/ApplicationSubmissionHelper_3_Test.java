package com.apple.spark.core;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.*;
import static org.mockito.Mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import com.apple.spark.AppConfig;
import com.apple.spark.AppConfig.SparkCluster;
import com.apple.spark.api.SubmitApplicationRequest;
import com.apple.spark.operator.ExecutorSpec;
import com.apple.spark.operator.NodeAffinity;
import com.apple.spark.operator.Affinity;
import com.apple.spark.operator.PodDNSConfig;
import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;
import java.util.Collections;

@ExtendWith(MockitoExtension.class)
class ApplicationSubmissionHelper_3_Test {
    @Mock
    private SubmitApplicationRequest mockRequest;
    
    @Mock
    private AppConfig mockAppConfig;
    
    @Mock
    private SparkCluster mockSparkCluster;
    
    private ExecutorSpec mockExecutorSpec;
    private ExecutorSpec mockClusterExecutorSpec;
    
    private static final String TEST_PARENT_QUEUE = "test-queue";
    private static final String DAG_NAME_LABEL = "dag-name";
    private static final String TASK_NAME_LABEL = "task-name";
    private static final String KUBE_CLUSTER_AUTOSCALER_SCALE_IN_ANNOTATION_KEY = "cluster-autoscaler.kubernetes.io/scale-in-disabled";
    private static final String KUBE_CLUSTER_AUTOSCALER_SCALE_IN_ANNOTATION_VALUE = "true";
    
    @BeforeEach
    void setupBeforeEach() {
        mockExecutorSpec = new ExecutorSpec();
        mockClusterExecutorSpec = new ExecutorSpec();
        
        // Setup common mock behaviors
        when(mockRequest.getExecutor()).thenReturn(mockExecutorSpec);
        when(mockRequest.getVolumes()).thenReturn(new ArrayList<>());
        when(mockSparkCluster.getExecutor()).thenReturn(mockClusterExecutorSpec);
        when(mockSparkCluster.getVolumes()).thenReturn(new ArrayList<>());
        
        // Setup default CPU and memory buffer ratios
        when(ApplicationSubmissionHelper.getExecutorCPUBufferForQueue(mockAppConfig, TEST_PARENT_QUEUE))
            .thenReturn(1.2);
        when(ApplicationSubmissionHelper.getExecutorMemBufferForQueue(mockAppConfig, TEST_PARENT_QUEUE))
            .thenReturn(1.1);
    }

    @AfterEach
    void teardownAfterEach() {
        reset(mockRequest, mockAppConfig, mockSparkCluster);
    }

    @Test
    void getExecutorSpec_shouldReturnBasicExecutorSpecWhenRequestExecutorIsNull() {
        // Given: Request with null executor
        when(mockRequest.getExecutor()).thenReturn(null);
        
        // When: Getting executor spec
        ExecutorSpec result = ApplicationSubmissionHelper.getExecutorSpec(
            mockRequest, mockAppConfig, TEST_PARENT_QUEUE, mockSparkCluster);
        
        // Then: Should return basic executor spec with default values
        assertNotNull(result);
        assertEquals(0, result.getCores());
        assertNotNull(result.getAnnotations());
        assertEquals(KUBE_CLUSTER_AUTOSCALER_SCALE_IN_ANNOTATION_VALUE,
            result.getAnnotations().get(KUBE_CLUSTER_AUTOSCALER_SCALE_IN_ANNOTATION_KEY));
        assertNotNull(result.getDnsConfig());
    }

    @Test
    void getExecutorSpec_shouldCopyExecutorSpecFromRequest() {
        // Given: Request with executor spec
        mockExecutorSpec.setCores(4);
        mockExecutorSpec.setMemory("4g");
        mockExecutorSpec.setCoreLimit("5");
        
        // When: Getting executor spec
        ExecutorSpec result = ApplicationSubmissionHelper.getExecutorSpec(
            mockRequest, mockAppConfig, TEST_PARENT_QUEUE, mockSparkCluster);
        
        // Then: Should copy values from request executor
        assertEquals(4, result.getCores());
        assertEquals("4g", result.getMemory());
        assertEquals("5", result.getCoreLimit());
    }

    @Test
    void getExecutorSpec_shouldNormalizeLabelsWhenPresent() {
        // Given: Request with executor containing labels
        Map<String, String> labels = new HashMap<>();
        labels.put(DAG_NAME_LABEL, "Test/DAG");
        labels.put(TASK_NAME_LABEL, "Test/Task");
        mockExecutorSpec.setLabels(labels);
        
        // When: Getting executor spec
        ExecutorSpec result = ApplicationSubmissionHelper.getExecutorSpec(
            mockRequest, mockAppConfig, TEST_PARENT_QUEUE, mockSparkCluster);
        
        // Then: Should normalize label values
        Map<String, String> resultLabels = result.getLabels();
        assertNotNull(resultLabels);
        assertEquals("test-dag", resultLabels.get(DAG_NAME_LABEL));
        assertEquals("test-task", resultLabels.get(TASK_NAME_LABEL));
    }

    @Test
    void getExecutorSpec_shouldUseRequestVolumeMountsWhenPresent() {
        // Given: Request with volumes and executor with volume mounts
        when(mockRequest.getVolumes()).thenReturn(Collections.singletonList(new Volume()));
        when(mockRequest.getExecutor().getVolumeMounts()).thenReturn(Collections.singletonList(new Volume.VolumeMount()));
        
        // When: Getting executor spec
        ExecutorSpec result = ApplicationSubmissionHelper.getExecutorSpec(
            mockRequest, mockAppConfig, TEST_PARENT_QUEUE, mockSparkCluster);
        
        // Then: Should use volume mounts from request
        assertNotNull(result.getVolumeMounts());
        assertEquals(1, result.getVolumeMounts().size());
    }

    @Test
    void getExecutorSpec_shouldUseClusterVolumeMountsWhenRequestVolumesEmpty() {
        // Given: Request with empty volumes but cluster has volumes
        when(mockRequest.getVolumes()).thenReturn(new ArrayList<>());
        when(mockSparkCluster.getVolumes()).thenReturn(Collections.singletonList(new Volume()));
        when(mockSparkCluster.getExecutor().getVolumeMounts()).thenReturn(Collections.singletonList(new Volume.VolumeMount()));
        
        // When: Getting executor spec
        ExecutorSpec result = ApplicationSubmissionHelper.getExecutorSpec(
            mockRequest, mockAppConfig, TEST_PARENT_QUEUE, mockSparkCluster);
        
        // Then: Should use volume mounts from cluster
        assertNotNull(result.getVolumeMounts());
        assertEquals(1, result.getVolumeMounts().size());
    }

    @Test
    void getExecutorSpec_shouldAdjustCoresBasedOnBufferRatio() {
        // Given: Request with executor cores and buffer ratio
        mockExecutorSpec.setCores(4);
        when(ApplicationSubmissionHelper.getExecutorCPUBufferForQueue(mockAppConfig, TEST_PARENT_QUEUE))
            .thenReturn(1.5);
        
        // When: Getting executor spec
        ExecutorSpec result = ApplicationSubmissionHelper.getExecutorSpec(
            mockRequest, mockAppConfig, TEST_PARENT_QUEUE, mockSparkCluster);
        
        // Then: Should adjust cores based on buffer ratio
        assertEquals(6, result.getCores()); // 4 * 1.5 = 6
    }

    @Test
    void getExecutorSpec_shouldSetCoreLimitWhenNotPresent() {
        // Given: Request with executor cores but no core limit
        mockExecutorSpec.setCores(4);
        mockExecutorSpec.setCoreLimit(null);
        when(ApplicationSubmissionHelper.getExecutorCPUBufferForQueue(mockAppConfig, TEST_PARENT_QUEUE))
            .thenReturn(1.2);
        
        // When: Getting executor spec
        ExecutorSpec result = ApplicationSubmissionHelper.getExecutorSpec(
            mockRequest, mockAppConfig, TEST_PARENT_QUEUE, mockSparkCluster);
        
        // Then: Should set core limit based on calculated value
        assertNotNull(result.getCoreLimit());
        // Expected: ceil(4 * CORE_LIMIT_RATIO * 1.2)
    }

    @Test
    void getExecutorSpec_shouldAdjustCoreLimitWhenPresent() {
        // Given: Request with executor core limit
        mockExecutorSpec.setCores(4);
        mockExecutorSpec.setCoreLimit("5");
        when(ApplicationSubmissionHelper.getExecutorCPUBufferForQueue(mockAppConfig, TEST_PARENT_QUEUE))
            .thenReturn(1.2);
        
        // When: Getting executor spec
        ExecutorSpec result = ApplicationSubmissionHelper.getExecutorSpec(
            mockRequest, mockAppConfig, TEST_PARENT_QUEUE, mockSparkCluster);
        
        // Then: Should adjust core limit based on buffer ratio
        assertEquals("6", result.getCoreLimit()); // 5 * 1.2 = 6
    }

    @Test
    void getExecutorSpec_shouldAdjustMemoryBasedOnBufferRatio() {
        // Given: Request with executor memory and buffer ratio
        mockExecutorSpec.setMemory("4g");
        when(ApplicationSubmissionHelper.getExecutorMemBufferForQueue(mockAppConfig, TEST_PARENT_QUEUE))
            .thenReturn(1.5);
        
        // When: Getting executor spec
        ExecutorSpec result = ApplicationSubmissionHelper.getExecutorSpec(
            mockRequest, mockAppConfig, TEST_PARENT_QUEUE, mockSparkCluster);
        
        // Then: Should adjust memory based on buffer ratio
        assertEquals("6g", result.getMemory()); // 4 * 1.5 = 6
    }

    @Test
    void getExecutorSpec_shouldSetAnnotationsWhenNotPresent() {
        // Given: Request with executor having no annotations
        mockExecutorSpec.setAnnotations(null);
        
        // When: Getting executor spec
        ExecutorSpec result = ApplicationSubmissionHelper.getExecutorSpec(
            mockRequest, mockAppConfig, TEST_PARENT_QUEUE, mockSparkCluster);
        
        // Then: Should set default annotations
        assertNotNull(result.getAnnotations());
        assertEquals(KUBE_CLUSTER_AUTOSCALER_SCALE_IN_ANNOTATION_VALUE,
            result.getAnnotations().get(KUBE_CLUSTER_AUTOSCALER_SCALE_IN_ANNOTATION_KEY));
    }

    @Test
    void getExecutorSpec_shouldNotOverrideExistingAnnotations() {
        // Given: Request with executor having existing annotations
        Map<String, String> existingAnnotations = new HashMap<>();
        existingAnnotations.put("existing-key", "existing-value");
        mockExecutorSpec.setAnnotations(existingAnnotations);
        
        // When: Getting executor spec
        ExecutorSpec result = ApplicationSubmissionHelper.getExecutorSpec(
            mockRequest, mockAppConfig, TEST_PARENT_QUEUE, mockSparkCluster);
        
        // Then: Should preserve existing annotations and add default ones
        assertNotNull(result.getAnnotations());
        assertEquals("existing-value", result.getAnnotations().get("existing-key"));
        assertEquals(KUBE_CLUSTER_AUTOSCALER_SCALE_IN_ANNOTATION_VALUE,
            result.getAnnotations().get(KUBE_CLUSTER_AUTOSCALER_SCALE_IN_ANNOTATION_KEY));
    }

    @Test
    void getExecutorSpec_shouldSetAffinityForSpotInstance() {
        // Given: Request with spot instance and mock node label values
        when(mockRequest.getSpotInstance()).thenReturn(true);
        when(ApplicationSubmissionHelper.getExecutorSpotNodeLabelValuesForQueue(mockAppConfig, TEST_PARENT_QUEUE))
            .thenReturn(Collections.singletonList("spot-node"));
        when(ApplicationSubmissionHelper.getExecutorNodeLabelKeyForQueue(mockAppConfig, TEST_PARENT_QUEUE))
            .thenReturn("node-label-key");
        
        // When: Getting executor spec
        ExecutorSpec result = ApplicationSubmissionHelper.getExecutorSpec(
            mockRequest, mockAppConfig, TEST_PARENT_QUEUE, mockSparkCluster);
        
        // Then: Should set affinity with spot node labels
        assertNotNull(result.getAffinity());
        NodeAffinity nodeAffinity = result.getAffinity().getNodeAffinity();
        assertNotNull(nodeAffinity);
    }

    @Test
    void getExecutorSpec_shouldSetAffinityForRegularInstance() {
        // Given: Request with regular instance and mock node label values
        when(mockRequest.getSpotInstance()).thenReturn(false);
        when(ApplicationSubmissionHelper.getExecutorNodeLabelValuesForQueue(mockAppConfig, TEST_PARENT_QUEUE))
            .thenReturn(Collections.singletonList("regular-node"));
        when(ApplicationSubmissionHelper.getExecutorNodeLabelKeyForQueue(mockAppConfig, TEST_PARENT_QUEUE))
            .thenReturn("node-label-key");
        
        // When: Getting executor spec
        ExecutorSpec result = ApplicationSubmissionHelper.getExecutorSpec(
            mockRequest, mockAppConfig, TEST_PARENT_QUEUE, mockSparkCluster);
        
        // Then: Should set affinity with regular node labels
        assertNotNull(result.getAffinity());
        NodeAffinity nodeAffinity = result.getAffinity().getNodeAffinity();
        assertNotNull(nodeAffinity);
    }

    @Test
    void getExecutorSpec_shouldSetDNSConfig() {
        // When: Getting executor spec
        ExecutorSpec result = ApplicationSubmissionHelper.getExecutorSpec(
            mockRequest, mockAppConfig, TEST_PARENT_QUEUE, mockSparkCluster);
        
        // Then: Should set DNS config with default options
        assertNotNull(result.getDnsConfig());
        PodDNSConfig dnsConfig = result.getDnsConfig();
        assertEquals(1, dnsConfig.getOptions().size());
        assertEquals("ndots", dnsConfig.getOptions().get(0).getName());
        assertEquals("2", dnsConfig.getOptions().get(0).getValue());
    }
}