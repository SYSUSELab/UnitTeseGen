package com.apple.spark.core;

import com.apple.spark.AppConfig;
import com.apple.spark.AppConfig.SparkCluster;
import com.apple.spark.api.SubmitApplicationRequest;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.*;
import static org.mockito.Mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import java.util.HashMap;
import java.util.Map;

@ExtendWith(MockitoExtension.class)
class ApplicationSubmissionHelperTest {
    @Mock
    private static AppConfig mockAppConfig;
    
    @Mock
    private static AppConfig.SparkCluster mockSparkCluster;
    
    @Mock
    private static SubmitApplicationRequest mockSubmitRequest;
    
    private static Map<String, String> defaultSparkConf;
    private static Map<String, String> fixedSparkConf;
    private static Map<String, String> clusterSparkConf;
    private static Map<String, String> requestSparkConf;
    private static final String TEST_SUBMISSION_ID = "test-submission-123";

    @BeforeAll
    static void setupBeforeAll() {
        // Initialize common test data that doesn't change between tests
        defaultSparkConf = new HashMap<>();
        defaultSparkConf.put("spark.default.key1", "value1");
        defaultSparkConf.put("spark.default.key2", "value2");
        
        fixedSparkConf = new HashMap<>();
        fixedSparkConf.put("spark.fixed.key1", "fixedValue1");
        
        clusterSparkConf = new HashMap<>();
        clusterSparkConf.put("spark.cluster.key1", "clusterValue1");
        
        requestSparkConf = new HashMap<>();
        requestSparkConf.put("spark.request.key1", "requestValue1");
    }

    @BeforeEach
    void setupBeforeEach() {
        // Reset mocks and set up common mock behaviors
        Mockito.reset(mockAppConfig, mockSparkCluster, mockSubmitRequest);
        
        when(mockAppConfig.getDefaultSparkConf()).thenReturn(defaultSparkConf);
        when(mockAppConfig.getFixedSparkConf()).thenReturn(fixedSparkConf);
        when(mockSparkCluster.getSparkConf()).thenReturn(clusterSparkConf);
        when(mockSubmitRequest.getSparkConf()).thenReturn(requestSparkConf);
        when(mockSubmitRequest.getApplicationName()).thenReturn("test-app");
        
        // Mock the static method behavior
        try (MockedStatic<ApplicationSubmissionHelper> mocked = Mockito.mockStatic(ApplicationSubmissionHelper.class)) {
            mocked.when(() -> ApplicationSubmissionHelper.applyFeatureGate(any(), any()))
                .thenAnswer(invocation -> invocation.getArgument(1));
            mocked.when(() -> ApplicationSubmissionHelper.substitutionSparkConfigValue(anyString(), anyString()))
                .thenAnswer(invocation -> invocation.getArgument(0));
        }
    }

    @AfterEach
    void teardownAfterEach() {
        // Clean up any test-specific state
    }

    @AfterAll
    static void teardownAfterAll() {
        // Clean up any static resources
        defaultSparkConf = null;
        fixedSparkConf = null;
        clusterSparkConf = null;
        requestSparkConf = null;
    }

    @Test
    @DisplayName("Should return combined spark config with all available configurations")
    void getSparkConf_shouldReturnCombinedConfigWhenAllConfigsPresent() {
        // Execute
        Map<String, String> result = ApplicationSubmissionHelper.getSparkConf(
            TEST_SUBMISSION_ID, mockSubmitRequest, mockAppConfig, mockSparkCluster);

        // Verify
        assertNotNull(result);
        assertEquals(5, result.size());
        assertEquals("value1", result.get("spark.default.key1"));
        assertEquals("value2", result.get("spark.default.key2"));
        assertEquals("clusterValue1", result.get("spark.cluster.key1"));
        assertEquals("requestValue1", result.get("spark.request.key1"));
        assertEquals("fixedValue1", result.get("spark.fixed.key1"));
        assertEquals("test-app", result.get(SparkConstants.SPARK_APP_NAME_CONFIG));
    }

    @Test
    @DisplayName("Should handle null default spark config")
    void getSparkConf_shouldHandleNullDefaultSparkConfig() {
        // Setup
        when(mockAppConfig.getDefaultSparkConf()).thenReturn(null);

        // Execute
        Map<String, String> result = ApplicationSubmissionHelper.getSparkConf(
            TEST_SUBMISSION_ID, mockSubmitRequest, mockAppConfig, mockSparkCluster);

        // Verify
        assertNotNull(result);
        assertEquals(3, result.size());
        assertEquals("clusterValue1", result.get("spark.cluster.key1"));
        assertEquals("requestValue1", result.get("spark.request.key1"));
        assertEquals("fixedValue1", result.get("spark.fixed.key1"));
    }

    @Test
    @DisplayName("Should handle null cluster spark config")
    void getSparkConf_shouldHandleNullClusterSparkConfig() {
        // Setup
        when(mockSparkCluster.getSparkConf()).thenReturn(null);

        // Execute
        Map<String, String> result = ApplicationSubmissionHelper.getSparkConf(
            TEST_SUBMISSION_ID, mockSubmitRequest, mockAppConfig, mockSparkCluster);

        // Verify
        assertNotNull(result);
        assertEquals(4, result.size());
        assertEquals("value1", result.get("spark.default.key1"));
        assertEquals("value2", result.get("spark.default.key2"));
        assertEquals("requestValue1", result.get("spark.request.key1"));
        assertEquals("fixedValue1", result.get("spark.fixed.key1"));
    }

    @Test
    @DisplayName("Should handle null request spark config")
    void getSparkConf_shouldHandleNullRequestSparkConfig() {
        // Setup
        when(mockSubmitRequest.getSparkConf()).thenReturn(null);

        // Execute
        Map<String, String> result = ApplicationSubmissionHelper.getSparkConf(
            TEST_SUBMISSION_ID, mockSubmitRequest, mockAppConfig, mockSparkCluster);

        // Verify
        assertNotNull(result);
        assertEquals(4, result.size());
        assertEquals("value1", result.get("spark.default.key1"));
        assertEquals("value2", result.get("spark.default.key2"));
        assertEquals("clusterValue1", result.get("spark.cluster.key1"));
        assertEquals("fixedValue1", result.get("spark.fixed.key1"));
    }

    @Test
    @DisplayName("Should handle null fixed spark config")
    void getSparkConf_shouldHandleNullFixedSparkConfig() {
        // Setup
        when(mockAppConfig.getFixedSparkConf()).thenReturn(null);

        // Execute
        Map<String, String> result = ApplicationSubmissionHelper.getSparkConf(
            TEST_SUBMISSION_ID, mockSubmitRequest, mockAppConfig, mockSparkCluster);

        // Verify
        assertNotNull(result);
        assertEquals(4, result.size());
        assertEquals("value1", result.get("spark.default.key1"));
        assertEquals("value2", result.get("spark.default.key2"));
        assertEquals("clusterValue1", result.get("spark.cluster.key1"));
        assertEquals("requestValue1", result.get("spark.request.key1"));
    }

    @Test
    @DisplayName("Should handle null application name")
    void getSparkConf_shouldHandleNullApplicationName() {
        // Setup
        when(mockSubmitRequest.getApplicationName()).thenReturn(null);

        // Execute
        Map<String, String> result = ApplicationSubmissionHelper.getSparkConf(
            TEST_SUBMISSION_ID, mockSubmitRequest, mockAppConfig, mockSparkCluster);

        // Verify
        assertNotNull(result);
        assertFalse(result.containsKey(SparkConstants.SPARK_APP_NAME_CONFIG));
    }

    @Test
    @DisplayName("Should handle empty application name")
    void getSparkConf_shouldHandleEmptyApplicationName() {
        // Setup
        when(mockSubmitRequest.getApplicationName()).thenReturn("");

        // Execute
        Map<String, String> result = ApplicationSubmissionHelper.getSparkConf(
            TEST_SUBMISSION_ID, mockSubmitRequest, mockAppConfig, mockSparkCluster);

        // Verify
        assertNotNull(result);
        assertFalse(result.containsKey(SparkConstants.SPARK_APP_NAME_CONFIG));
    }

    @Test
    @DisplayName("Should handle when all configs are null except fixed")
    void getSparkConf_shouldHandleAllNullConfigsExceptFixed() {
        // Setup
        when(mockAppConfig.getDefaultSparkConf()).thenReturn(null);
        when(mockSparkCluster.getSparkConf()).thenReturn(null);
        when(mockSubmitRequest.getSparkConf()).thenReturn(null);
        when(mockSubmitRequest.getApplicationName()).thenReturn(null);

        // Execute
        Map<String, String> result = ApplicationSubmissionHelper.getSparkConf(
            TEST_SUBMISSION_ID, mockSubmitRequest, mockAppConfig, mockSparkCluster);

        // Verify
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("fixedValue1", result.get("spark.fixed.key1"));
    }

    @Test
    @DisplayName("Should handle when all configs are null except default")
    void getSparkConf_shouldHandleAllNullConfigsExceptDefault() {
        // Setup
        when(mockAppConfig.getFixedSparkConf()).thenReturn(null);
        when(mockSparkCluster.getSparkConf()).thenReturn(null);
        when(mockSubmitRequest.getSparkConf()).thenReturn(null);
        when(mockSubmitRequest.getApplicationName()).thenReturn(null);

        // Execute
        Map<String, String> result = ApplicationSubmissionHelper.getSparkConf(
            TEST_SUBMISSION_ID, mockSubmitRequest, mockAppConfig, mockSparkCluster);

        // Verify
        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("value1", result.get("spark.default.key1"));
        assertEquals("value2", result.get("spark.default.key2"));
    }

    @Test
    @DisplayName("Should handle when all configs are null")
    void getSparkConf_shouldHandleAllNullConfigs() {
        // Setup
        when(mockAppConfig.getDefaultSparkConf()).thenReturn(null);
        when(mockAppConfig.getFixedSparkConf()).thenReturn(null);
        when(mockSparkCluster.getSparkConf()).thenReturn(null);
        when(mockSubmitRequest.getSparkConf()).thenReturn(null);
        when(mockSubmitRequest.getApplicationName()).thenReturn(null);

        // Execute
        Map<String, String> result = ApplicationSubmissionHelper.getSparkConf(
            TEST_SUBMISSION_ID, mockSubmitRequest, mockAppConfig, mockSparkCluster);

        // Verify
        assertNull(result);
    }

    @Test
    @DisplayName("Should apply value substitution for default config values")
    void getSparkConf_shouldApplyValueSubstitutionForDefaultConfig() {
        // Setup
        try (MockedStatic<ApplicationSubmissionHelper> mocked = Mockito.mockStatic(ApplicationSubmissionHelper.class)) {
            mocked.when(() -> ApplicationSubmissionHelper.applyFeatureGate(any(), any()))
                .thenAnswer(invocation -> invocation.getArgument(1));
            mocked.when(() -> ApplicationSubmissionHelper.substitutionSparkConfigValue(anyString(), anyString()))
                .thenAnswer(invocation -> "substituted-" + invocation.getArgument(0));

            // Execute
            Map<String, String> result = ApplicationSubmissionHelper.getSparkConf(
                TEST_SUBMISSION_ID, mockSubmitRequest, mockAppConfig, mockSparkCluster);

            // Verify
            assertNotNull(result);
            assertEquals("substituted-value1", result.get("spark.default.key1"));
            assertEquals("substituted-value2", result.get("spark.default.key2"));
            assertEquals("clusterValue1", result.get("spark.cluster.key1")); // Not substituted
        }
    }

    @Test
    @DisplayName("Should apply value substitution for cluster config values")
    void getSparkConf_shouldApplyValueSubstitutionForClusterConfig() {
        // Setup
        try (MockedStatic<ApplicationSubmissionHelper> mocked = Mockito.mockStatic(ApplicationSubmissionHelper.class)) {
            mocked.when(() -> ApplicationSubmissionHelper.applyFeatureGate(any(), any()))
                .thenAnswer(invocation -> invocation.getArgument(1));
            mocked.when(() -> ApplicationSubmissionHelper.substitutionSparkConfigValue(anyString(), anyString()))
                .thenAnswer(invocation -> "substituted-" + invocation.getArgument(0));

            // Execute
            Map<String, String> result = ApplicationSubmissionHelper.getSparkConf(
                TEST_SUBMISSION_ID, mockSubmitRequest, mockAppConfig, mockSparkCluster);

            // Verify
            assertNotNull(result);
            assertEquals("substituted-clusterValue1", result.get("spark.cluster.key1"));
            assertEquals("value1", result.get("spark.default.key1")); // Also substituted but verified in previous test
        }
    }

    @Test
    @DisplayName("Should not apply value substitution for request config values")
    void getSparkConf_shouldNotSubstituteRequestConfigValues() {
        // Setup
        try (MockedStatic<ApplicationSubmissionHelper> mocked = Mockito.mockStatic(ApplicationSubmissionHelper.class)) {
            mocked.when(() -> ApplicationSubmissionHelper.applyFeatureGate(any(), any()))
                .thenAnswer(invocation -> invocation.getArgument(1));
            mocked.when(() -> ApplicationSubmissionHelper.substitutionSparkConfigValue(anyString(), anyString()))
                .thenAnswer(invocation -> "substituted-" + invocation.getArgument(0));

            // Execute
            Map<String, String> result = ApplicationSubmissionHelper.getSparkConf(
                TEST_SUBMISSION_ID, mockSubmitRequest, mockAppConfig, mockSparkCluster);

            // Verify
            assertNotNull(result);
            assertEquals("requestValue1", result.get("spark.request.key1")); // Not substituted
        }
    }

    @Test
    @DisplayName("Should apply feature gate filtering for default config")
    void getSparkConf_shouldApplyFeatureGateForDefaultConfig() {
        // Setup
        Map<String, String> filteredDefaultConf = new HashMap<>();
        filteredDefaultConf.put("spark.default.key1", "filteredValue1");
        
        try (MockedStatic<ApplicationSubmissionHelper> mocked = Mockito.mockStatic(ApplicationSubmissionHelper.class)) {
            mocked.when(() -> ApplicationSubmissionHelper.applyFeatureGate(any(), any()))
                .thenReturn(filteredDefaultConf);
            mocked.when(() -> ApplicationSubmissionHelper.substitutionSparkConfigValue(anyString(), anyString()))
                .thenAnswer(invocation -> invocation.getArgument(0));

            // Execute
            Map<String, String> result = ApplicationSubmissionHelper.getSparkConf(
                TEST_SUBMISSION_ID, mockSubmitRequest, mockAppConfig, mockSparkCluster);

            // Verify
            assertNotNull(result);
            assertEquals("filteredValue1", result.get("spark.default.key1"));
            assertFalse(result.containsKey("spark.default.key2")); // Should be filtered out
            assertEquals("clusterValue1", result.get("spark.cluster.key1"));
        }
    }
}