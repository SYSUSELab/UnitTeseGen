package com.apple.spark.api;

import com.apple.spark.AppConfig;
import com.apple.spark.core.Constants;
import com.apple.spark.core.SparkConstants;
import com.apple.spark.operator.DriverSpec;
import com.apple.spark.operator.ExecutorSpec;
import com.apple.spark.operator.SparkApplication;
import com.apple.spark.operator.SparkApplicationSpec;

import io.fabric8.kubernetes.api.model.ObjectMeta;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.*;
import static org.mockito.Mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;

@ExtendWith(MockitoExtension.class)
class SubmissionSummaryTest {
    @Mock
    private SparkApplication mockSparkApplication;
    
    @Mock
    private SparkApplicationSpec mockSparkApplicationSpec;
    
    @Mock
    private AppConfig mockAppConfig;
    
    @Mock
    private AppConfig.SparkCluster mockSparkCluster;
    
    @InjectMocks
    private SubmissionSummary submissionSummary;
    
    @BeforeAll
    static void setupBeforeAll() {
        // Initialize any static resources if needed
    }

    @BeforeEach
    void setupBeforeEach() {
        // Reset mocks before each test
        MockitoAnnotations.openMocks(this);
        reset(mockSparkApplication, mockSparkApplicationSpec, mockAppConfig, mockSparkCluster);
        
        // Initialize default mock behaviors
        when(mockSparkApplication.getSpec()).thenReturn(mockSparkApplicationSpec);
    }

    @AfterEach
    void teardownAfterEach() {
        // Clean up any resources if needed
    }

    @AfterAll
    static void teardownAfterAll() {
        // Clean up any static resources if needed
    }

    @Test
    @DisplayName("Should copy basic fields when SparkApplication has minimal data")
    void copyFrom_withMinimalData_shouldCopyBasicFields() {
        // Arrange
        ObjectMeta metadata = mockSparkApplication.getMetadata();
        when(mockSparkApplication.getMetadata()).thenReturn(metadata);
        when(metadata.getName()).thenReturn("test-submission-id");
        
        // Act
        submissionSummary.copyFrom(mockSparkApplication);
        
        // Assert
        assertEquals("test-submission-id", submissionSummary.getSubmissionId());
        assertEquals(1, submissionSummary.getDriverCores());
        assertEquals(0L, submissionSummary.getDriverMemoryGB());
        assertEquals(1, submissionSummary.getExecutorInstances());
        assertEquals(1, submissionSummary.getExecutorCores());
        assertEquals(0L, submissionSummary.getExecutorMemoryGB());
        assertEquals(1, submissionSummary.getTotalCores());
        assertEquals(0L, submissionSummary.getTotalMemoryGB());
    }

    @Test
    @DisplayName("Should copy all fields when SparkApplication has complete data")
    void copyFrom_withCompleteData_shouldCopyAllFields() {
        // Arrange
        // Setup metadata with labels
        Map<String, String> labels = new HashMap<>();
        labels.put(Constants.PROXY_USER_LABEL, "test-user");
        labels.put(Constants.QUEUE_LABEL, "test-queue");
        
        ObjectMeta metadata = mockSparkApplication.getMetadata();
        when(mockSparkApplication.getMetadata()).thenReturn(metadata);
        when(metadata.getName()).thenReturn("test-submission-id");
        when(metadata.getLabels()).thenReturn(labels);
        
        // Setup driver labels
        Map<String, String> driverLabels = new HashMap<>();
        driverLabels.put(Constants.DAG_NAME_LABEL, "test-dag");
        DriverSpec driver = mockSparkApplicationSpec.getDriver();
        when(mockSparkApplicationSpec.getDriver()).thenReturn(driver);
        when(driver.getLabels()).thenReturn(driverLabels);
        when(driver.getCores()).thenReturn(2);
        when(driver.getMemory()).thenReturn("2Gi");
        
        // Setup executor
        // SparkApplication.Executor executor = mock(SparkApplication.Executor.class);
        ExecutorSpec executor =  mockSparkApplicationSpec.getExecutor();
        when(mockSparkApplicationSpec.getExecutor()).thenReturn(executor);
        when(executor.getCores()).thenReturn(4);
        when(executor.getInstances()).thenReturn(3);
        when(executor.getMemory()).thenReturn("4Gi");
        
        // Setup spec
        when(mockSparkApplicationSpec.getSparkVersion()).thenReturn("3.2.1");
        
        Map<String, String> sparkConf = new HashMap<>();
        sparkConf.put(SparkConstants.SPARK_APP_NAME_CONFIG, "test-app-name");
        when(mockSparkApplicationSpec.getSparkConf()).thenReturn(sparkConf);
        
        // Act
        submissionSummary.copyFrom(mockSparkApplication);
        
        // Assert
        assertEquals("test-submission-id", submissionSummary.getSubmissionId());
        assertEquals("test-user", submissionSummary.getUser());
        assertEquals("test-queue", submissionSummary.getQueue());
        assertEquals("test-dag", submissionSummary.getDagName());
        assertEquals(2, submissionSummary.getDriverCores());
        assertEquals(2L, submissionSummary.getDriverMemoryGB());
        assertEquals(3, submissionSummary.getExecutorInstances());
        assertEquals(4, submissionSummary.getExecutorCores());
        assertEquals(4L, submissionSummary.getExecutorMemoryGB());
        assertEquals(14, submissionSummary.getTotalCores()); // 3*4 + 2
        assertEquals(14L, submissionSummary.getTotalMemoryGB()); // 3*4 + 2
        assertEquals("3.2.1", submissionSummary.getSparkVersion());
        assertEquals("test-app-name", submissionSummary.getApplicationName());
    }

    @Test
    @DisplayName("Should handle null labels gracefully")
    void copyFrom_withNullLabels_shouldNotFail() {
        // Arrange
        // SparkApplication.Metadata metadata = mock(SparkApplication.Metadata.class);
        ObjectMeta metadata = mockSparkApplication.getMetadata();
        when(mockSparkApplication.getMetadata()).thenReturn(metadata);
        when(metadata.getName()).thenReturn("test-submission-id");
        when(metadata.getLabels()).thenReturn(null);
        
        // Act
        submissionSummary.copyFrom(mockSparkApplication);
        
        // Assert
        assertEquals("test-submission-id", submissionSummary.getSubmissionId());
        assertNull(submissionSummary.getUser());
        assertEquals("", submissionSummary.getQueue());
        assertEquals("", submissionSummary.getDagName());
    }

    @Test
    @DisplayName("Should handle null driver labels gracefully")
    void copyFrom_withNullDriverLabels_shouldNotFail() {
        // Arrange
        // Setup metadata with labels
        Map<String, String> labels = new HashMap<>();
        labels.put(Constants.PROXY_USER_LABEL, "test-user");
        
        // SparkApplication.Metadata metadata = mock(SparkApplication.Metadata.class);
        ObjectMeta metadata = mockSparkApplication.getMetadata();
        when(mockSparkApplication.getMetadata()).thenReturn(metadata);
        when(metadata.getName()).thenReturn("test-submission-id");
        when(metadata.getLabels()).thenReturn(labels);
        
        // Setup driver with null labels
        // SparkApplication.Driver driver = mock(SparkApplication.Driver.class);
        DriverSpec driver = mockSparkApplicationSpec.getDriver();
        when(mockSparkApplicationSpec.getDriver()).thenReturn(driver);
        when(driver.getLabels()).thenReturn(null);
        
        // Act
        submissionSummary.copyFrom(mockSparkApplication);
        
        // Assert
        assertEquals("test-submission-id", submissionSummary.getSubmissionId());
        assertEquals("test-user", submissionSummary.getUser());
        assertEquals("", submissionSummary.getDagName());
    }

    @Test
    @DisplayName("Should handle memory conversion errors gracefully")
    void copyFrom_withInvalidMemoryFormat_shouldUseDefaultValues() {
        // Arrange
        // Setup metadata with labels
        Map<String, String> labels = new HashMap<>();
        labels.put(Constants.PROXY_USER_LABEL, "test-user");
        
        // SparkApplication.Metadata metadata = mock(SparkApplication.Metadata.class);
        ObjectMeta metadata = mockSparkApplication.getMetadata();
        when(mockSparkApplication.getMetadata()).thenReturn(metadata);
        when(metadata.getName()).thenReturn("test-submission-id");
        when(metadata.getLabels()).thenReturn(labels);
        
        // Setup driver with invalid memory format
        // SparkApplication.Driver driver = mock(SparkApplication.Driver.class);
        DriverSpec driver = mockSparkApplicationSpec.getDriver();
        when(mockSparkApplicationSpec.getDriver()).thenReturn(driver);
        when(driver.getMemory()).thenReturn("invalid-format");
        
        // Setup executor with invalid memory format
        // SparkApplication.Executor executor = mock(SparkApplication.Executor.class);
        ExecutorSpec executor = mockSparkApplicationSpec.getExecutor();
        when(mockSparkApplicationSpec.getExecutor()).thenReturn(executor);
        when(executor.getMemory()).thenReturn("invalid-format");
        
        // Act
        submissionSummary.copyFrom(mockSparkApplication);
        
        // Assert
        assertEquals(0L, submissionSummary.getDriverMemoryGB());
        assertEquals(0L, submissionSummary.getExecutorMemoryGB());
        assertEquals(0L, submissionSummary.getTotalMemoryGB());
    }

    @Test
    @DisplayName("Should handle null spec gracefully")
    void copyFrom_withNullSpec_shouldNotFail() {
        // Arrange
        // SparkApplication.Metadata metadata = mock(SparkApplication.Metadata.class);
        ObjectMeta metadata = mockSparkApplication.getMetadata();
        when(mockSparkApplication.getMetadata()).thenReturn(metadata);
        when(metadata.getName()).thenReturn("test-submission-id");
        when(mockSparkApplication.getSpec()).thenReturn(null);
        
        // Act
        submissionSummary.copyFrom(mockSparkApplication);
        
        // Assert
        assertEquals("test-submission-id", submissionSummary.getSubmissionId());
        assertNull(submissionSummary.getSparkVersion());
        assertNull(submissionSummary.getApplicationName());
    }

    @Test
    @DisplayName("Should handle null sparkConf gracefully")
    void copyFrom_withNullSparkConf_shouldNotFail() {
        // Arrange
        // SparkApplication.Metadata metadata = mock(SparkApplication.Metadata.class);
        ObjectMeta metadata = mockSparkApplication.getMetadata();
        when(mockSparkApplication.getMetadata()).thenReturn(metadata);
        when(metadata.getName()).thenReturn("test-submission-id");
        when(mockSparkApplicationSpec.getSparkConf()).thenReturn(null);
        
        // Act
        submissionSummary.copyFrom(mockSparkApplication);
        
        // Assert
        assertEquals("test-submission-id", submissionSummary.getSubmissionId());
        assertNull(submissionSummary.getApplicationName());
    }

    @Test
    @DisplayName("Should calculate correct total resources")
    void copyFrom_withMultipleExecutors_shouldCalculateCorrectTotals() {
        // Arrange
        // SparkApplication.Metadata metadata = mock(SparkApplication.Metadata.class);
        ObjectMeta metadata = mockSparkApplication.getMetadata();
        when(mockSparkApplication.getMetadata()).thenReturn(metadata);
        when(metadata.getName()).thenReturn("test-submission-id");
        
        // Setup driver
        // SparkApplication.Driver driver = mock(SparkApplication.Driver.class);
        DriverSpec driver = mockSparkApplicationSpec.getDriver();
        when(mockSparkApplicationSpec.getDriver()).thenReturn(driver);
        when(driver.getCores()).thenReturn(2);
        when(driver.getMemory()).thenReturn("2Gi");
        
        // Setup executor
        // SparkApplication.Executor executor = mock(SparkApplication.Executor.class);
        ExecutorSpec executor = mockSparkApplicationSpec.getExecutor();
        when(mockSparkApplicationSpec.getExecutor()).thenReturn(executor);
        when(executor.getCores()).thenReturn(4);
        when(executor.getInstances()).thenReturn(5);
        when(executor.getMemory()).thenReturn("4Gi");
        
        // Act
        submissionSummary.copyFrom(mockSparkApplication);
        
        // Assert
        assertEquals(22, submissionSummary.getTotalCores()); // 5*4 + 2
        assertEquals(22L, submissionSummary.getTotalMemoryGB()); // 5*4 + 2
    }
}