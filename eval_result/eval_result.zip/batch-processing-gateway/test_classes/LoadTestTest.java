package com.apple.spark.tools;

import com.apple.spark.api.GetDriverInfoResponse;
import com.apple.spark.api.GetSubmissionStatusResponse;
import com.apple.spark.api.SubmitApplicationResponse;
import com.apple.spark.core.SparkConstants;
import com.apple.spark.util.HttpUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentLinkedQueue;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class LoadTestTest {
    private MockedStatic<HttpUtils> mockedHttpUtils;
    private MockedStatic<CompletableFuture> mockedCompletableFuture;
    private MockedStatic<System> mockedSystem;
    
    private static final String TEST_SUBMISSION_ID = "test-submission-123";
    private static final String TEST_APPLICATION_STATE = "FINISHED";
    private static final String TEST_TERMINATION_TIME = "2023-01-01T00:00:00Z";
    private static final String TEST_START_TIME = "2023-01-01T00:00:00Z";
    
    @BeforeEach
    void setUp() {
        // Mock static methods
        mockedHttpUtils = mockStatic(HttpUtils.class);
        mockedCompletableFuture = mockStatic(CompletableFuture.class);
        mockedSystem = mockStatic(System.class);
        
        // Clear static queues before each test
        LoadTest.runningApps.clear();
        LoadTest.finishedApps.clear();
    }
    
    @AfterEach
    void tearDown() {
        // Close static mocks
        mockedHttpUtils.close();
        mockedCompletableFuture.close();
        mockedSystem.close();
    }
    
    @Test
    void main_shouldParseAllCommandLineArgumentsCorrectly() {
        // Setup test arguments
        String[] args = {
            "-applications", "5",
            "-mapTasks", "3",
            "-sleepSeconds", "10",
            "-maxWaitSeconds", "120",
            "-executors", "2",
            "-deleteApplication", "false"
        };
        
        // Mock system exit to prevent actual JVM exit
        mockedSystem.when(() -> System.exit(anyInt())).thenAnswer(invocation -> null);
        
        // Execute
        LoadTest.main(args);
        
        // Verify no exceptions were thrown during argument parsing
        // (Verification is implicit - if parsing failed, test would have thrown exception)
    }
    
    @Test
    void main_shouldThrowExceptionForUnsupportedArgument() {
        // Setup test with unsupported argument
        String[] args = {"-unsupportedArg", "value"};
        
        // Execute and verify
        RuntimeException exception = assertThrows(RuntimeException.class, () -> LoadTest.main(args));
        assertEquals("Unsupported argument: -unsupportedArg", exception.getMessage());
    }
    
    @Test
    void main_shouldSubmitCorrectNumberOfApplications() {
        // Setup test arguments
        String[] args = {"-applications", "3"};
        
        // Mock system exit
        mockedSystem.when(() -> System.exit(anyInt())).thenAnswer(invocation -> null);
        
        // Mock CompletableFuture.runAsync to capture submitted applications
        CompletableFuture<Void> mockFuture = mock(CompletableFuture.class);
        mockedCompletableFuture.when(() -> CompletableFuture.runAsync(any(Runnable.class)))
            .thenReturn(mockFuture);
        
        // Execute
        LoadTest.main(args);
        
        // Verify 3 applications were submitted
        mockedCompletableFuture.verify(() -> CompletableFuture.runAsync(any(Runnable.class)), times(3));
    }
    
    @Test
    void main_shouldHandleApplicationStatusChecks() {
        // Setup test arguments
        String[] args = {"-applications", "1", "-maxWaitSeconds", "1"};
        
        // Mock system exit
        mockedSystem.when(() -> System.exit(anyInt())).thenAnswer(invocation -> null);
        
        // Mock current time to simulate waiting
        mockedSystem.when(System::currentTimeMillis)
            .thenReturn(0L) // Initial time
            .thenReturn(500L); // After first check
        
        // Mock application submission
        CompletableFuture<Void> mockFuture = mock(CompletableFuture.class);
        mockedCompletableFuture.when(() -> CompletableFuture.runAsync(any(Runnable.class)))
            .thenAnswer(invocation -> {
                // Simulate adding a running application
                LoadTest.TestApplicationInfo app = new LoadTest.TestApplicationInfo();
                app.setSubmissionId(TEST_SUBMISSION_ID);
                LoadTest.runningApps.add(app);
                return mockFuture;
            });
        
        // Mock HTTP responses for status check
        GetSubmissionStatusResponse statusResponse = new GetSubmissionStatusResponse();
        statusResponse.setApplicationState(TEST_APPLICATION_STATE);
        statusResponse.setTerminationTime(TEST_TERMINATION_TIME);
        
        GetDriverInfoResponse driverResponse = new GetDriverInfoResponse();
        driverResponse.setStartTime(TEST_START_TIME);
        
        mockedHttpUtils.when(() -> HttpUtils.get(
            contains("/status"),
            anyString(),
            anyString(),
            eq(GetSubmissionStatusResponse.class)
        )).thenReturn(statusResponse);
        
        mockedHttpUtils.when(() -> HttpUtils.get(
            contains("/driver"),
            anyString(),
            anyString(),
            eq(GetDriverInfoResponse.class)
        )).thenReturn(driverResponse);
        
        // Execute
        LoadTest.main(args);
        
        // Verify application was moved from running to finished
        assertEquals(0, LoadTest.runningApps.size());
        assertEquals(1, LoadTest.finishedApps.size());
    }
    
    @Test
    void main_shouldTimeoutWhenMaxWaitExceeded() {
        // Setup test arguments with short timeout
        String[] args = {"-applications", "1", "-maxWaitSeconds", "1"};
        
        // Mock system exit
        mockedSystem.when(() -> System.exit(anyInt())).thenAnswer(invocation -> null);
        
        // Mock current time to simulate timeout
        mockedSystem.when(System::currentTimeMillis)
            .thenReturn(0L) // Initial time
            .thenReturn(TimeUnit.SECONDS.toMillis(61)); // After timeout
        
        // Mock application submission
        CompletableFuture<Void> mockFuture = mock(CompletableFuture.class);
        mockedCompletableFuture.when(() -> CompletableFuture.runAsync(any(Runnable.class)))
            .thenReturn(mockFuture);
        
        // Execute
        LoadTest.main(args);
        
        // Verify timeout occurred (application still in running queue)
        assertEquals(1, LoadTest.runningApps.size());
        assertEquals(0, LoadTest.finishedApps.size());
    }
    
    @Test
    void main_shouldDeleteApplicationsWhenEnabled() {
        // Setup test arguments with delete enabled
        String[] args = {"-applications", "1", "-deleteApplication", "true"};
        
        // Mock system exit
        mockedSystem.when(() -> System.exit(anyInt())).thenAnswer(invocation -> null);
        
        // Mock application lifecycle
        CompletableFuture<Void> mockFuture = mock(CompletableFuture.class);
        mockedCompletableFuture.when(() -> CompletableFuture.runAsync(any(Runnable.class)))
            .thenAnswer(invocation -> {
                // Simulate adding and immediately completing an application
                LoadTest.TestApplicationInfo app = new LoadTest.TestApplicationInfo();
                app.setSubmissionId(TEST_SUBMISSION_ID);
                LoadTest.runningApps.add(app);
                
                GetSubmissionStatusResponse statusResponse = new GetSubmissionStatusResponse();
                statusResponse.setApplicationState(TEST_APPLICATION_STATE);
                statusResponse.setTerminationTime(TEST_TERMINATION_TIME);
                
                GetDriverInfoResponse driverResponse = new GetDriverInfoResponse();
                driverResponse.setStartTime(TEST_START_TIME);
                
                mockedHttpUtils.when(() -> HttpUtils.get(
                    contains("/status"),
                    anyString(),
                    anyString(),
                    eq(GetSubmissionStatusResponse.class)
                )).thenReturn(statusResponse);
                
                mockedHttpUtils.when(() -> HttpUtils.get(
                    contains("/driver"),
                    anyString(),
                    anyString(),
                    eq(GetDriverInfoResponse.class)
                )).thenReturn(driverResponse);
                
                return mockFuture;
            });
        
        // Execute
        LoadTest.main(args);
        
        // Verify delete was called
        mockedHttpUtils.verify(() -> HttpUtils.delete(
            contains(TEST_SUBMISSION_ID),
            anyString(),
            anyString()
        ));
    }
    
    @Test
    void main_shouldNotDeleteApplicationsWhenDisabled() {
        // Setup test arguments with delete disabled
        String[] args = {"-applications", "1", "-deleteApplication", "false"};
        
        // Mock system exit
        mockedSystem.when(() -> System.exit(anyInt())).thenAnswer(invocation -> null);
        
        // Mock application lifecycle
        CompletableFuture<Void> mockFuture = mock(CompletableFuture.class);
        mockedCompletableFuture.when(() -> CompletableFuture.runAsync(any(Runnable.class)))
            .thenAnswer(invocation -> {
                // Simulate adding and immediately completing an application
                LoadTest.TestApplicationInfo app = new LoadTest.TestApplicationInfo();
                app.setSubmissionId(TEST_SUBMISSION_ID);
                LoadTest.runningApps.add(app);
                
                GetSubmissionStatusResponse statusResponse = new GetSubmissionStatusResponse();
                statusResponse.setApplicationState(TEST_APPLICATION_STATE);
                statusResponse.setTerminationTime(TEST_TERMINATION_TIME);
                
                GetDriverInfoResponse driverResponse = new GetDriverInfoResponse();
                driverResponse.setStartTime(TEST_START_TIME);
                
                mockedHttpUtils.when(() -> HttpUtils.get(
                    contains("/status"),
                    anyString(),
                    anyString(),
                    eq(GetSubmissionStatusResponse.class)
                )).thenReturn(statusResponse);
                
                mockedHttpUtils.when(() -> HttpUtils.get(
                    contains("/driver"),
                    anyString(),
                    anyString(),
                    eq(GetDriverInfoResponse.class)
                )).thenReturn(driverResponse);
                
                return mockFuture;
            });
        
        // Execute
        LoadTest.main(args);
        
        // Verify delete was NOT called
        mockedHttpUtils.verify(() -> HttpUtils.delete(
            anyString(),
            anyString(),
            anyString()
        ), never());
    }
    
    @Test
    void main_shouldHandleInterruptedExceptionGracefully() {
        // Setup test arguments
        String[] args = {"-applications", "1"};
        
        // Mock system exit
        mockedSystem.when(() -> System.exit(anyInt())).thenAnswer(invocation -> null);
        
        // Mock current time to trigger sleep
        mockedSystem.when(System::currentTimeMillis)
            .thenReturn(0L) // Initial time
            .thenReturn(500L); // After first check
        
        // Mock application submission
        CompletableFuture<Void> mockFuture = mock(CompletableFuture.class);
        mockedCompletableFuture.when(() -> CompletableFuture.runAsync(any(Runnable.class)))
            .thenAnswer(invocation -> {
                // Simulate adding a running application
                LoadTest.TestApplicationInfo app = new LoadTest.TestApplicationInfo();
                app.setSubmissionId(TEST_SUBMISSION_ID);
                LoadTest.runningApps.add(app);
                return mockFuture;
            });
        
        // Mock Thread.sleep to throw InterruptedException
        mockedSystem.when(() -> Thread.sleep(anyLong()))
            .thenThrow(new InterruptedException("Test interruption"));
        
        // Execute (should not throw)
        assertDoesNotThrow(() -> LoadTest.main(args));
    }
}