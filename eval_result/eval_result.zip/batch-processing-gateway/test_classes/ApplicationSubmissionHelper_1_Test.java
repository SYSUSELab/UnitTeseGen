package com.apple.spark.core;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.*;
import static org.mockito.Mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import com.apple.spark.AppConfig;
import com.apple.spark.AppConfig.SparkCluster;
import com.apple.spark.api.SubmitApplicationRequest;
import com.apple.spark.operator.DriverSpec;
import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;

@ExtendWith(MockitoExtension.class)
class ApplicationSubmissionHelper_1_Test {
    @Mock
    private SubmitApplicationRequest mockRequest;
    @Mock
    private SubmitApplicationRequest.Driver mockDriver;
    @Mock
    private AppConfig mockAppConfig;
    @Mock
    private SparkCluster mockSparkCluster;
    @Mock
    private SparkCluster.Driver mockClusterDriver;

    private final String testParentQueue = "test-queue";
    private Map<String, String> testLabels;
    private Map<String, String> testAnnotations;

    @BeforeAll
    static void setupBeforeAll() {
        // Initialize any static resources if needed
    }

    @BeforeEach
    void setupBeforeEach() {
        testLabels = new HashMap<>();
        testAnnotations = new HashMap<>();
        
        when(mockRequest.getDriver()).thenReturn(mockDriver);
        when(mockDriver.getLabels()).thenReturn(testLabels);
        when(mockDriver.getVolumeMounts()).thenReturn(new ArrayList<>());
        when(mockSparkCluster.getDriver()).thenReturn(mockClusterDriver);
        when(mockSparkCluster.getSparkServiceAccount()).thenReturn("test-service-account");
        
        // Mock default values for config
        when(mockAppConfig.getDriverCPUBufferRatio()).thenReturn(1.0);
        when(mockAppConfig.getDriverMemBufferRatio()).thenReturn(1.0);
    }

    @AfterEach
    void teardownAfterEach() {
        reset(mockRequest, mockDriver, mockAppConfig, mockSparkCluster, mockClusterDriver);
        testLabels.clear();
        testAnnotations.clear();
    }

    @AfterAll
    static void teardownAfterAll() {
        // Clean up any static resources if needed
    }

    @Test
    @DisplayName("Should create basic DriverSpec when request has no driver")
    void getDriverSpec_whenRequestHasNoDriver_shouldCreateBasicSpec() {
        // Arrange
        when(mockRequest.getDriver()).thenReturn(null);
        
        // Act
        DriverSpec result = ApplicationSubmissionHelper.getDriverSpec(
            mockRequest, mockAppConfig, testParentQueue, mockSparkCluster);
        
        // Assert
        assertNotNull(result);
        assertEquals("test-service-account", result.getServiceAccount());
        assertNotNull(result.getAnnotations());
        assertEquals("false", result.getAnnotations().get("cluster-autoscaler.kubernetes.io/scale-in-disabled"));
    }

    @Test
    @DisplayName("Should copy driver properties from request when present")
    void getDriverSpec_whenRequestHasDriver_shouldCopyProperties() {
        // Arrange
        when(mockDriver.getCores()).thenReturn(2);
        when(mockDriver.getMemory()).thenReturn("2G");
        when(mockDriver.getServiceAccount()).thenReturn("custom-service-account");
        
        // Act
        DriverSpec result = ApplicationSubmissionHelper.getDriverSpec(
            mockRequest, mockAppConfig, testParentQueue, mockSparkCluster);
        
        // Assert
        assertEquals(2, result.getCores());
        assertEquals("2G", result.getMemory());
        assertEquals("custom-service-account", result.getServiceAccount());
    }

    @Test
    @DisplayName("Should normalize DAG and TASK labels when present")
    void getDriverSpec_whenLabelsPresent_shouldNormalizeSpecialLabels() {
        // Arrange
        testLabels.put(Constants.DAG_NAME_LABEL, "My/DAG");
        testLabels.put(Constants.TASK_NAME_LABEL, "Task@Name");
        
        // Act
        DriverSpec result = ApplicationSubmissionHelper.getDriverSpec(
            mockRequest, mockAppConfig, testParentQueue, mockSparkCluster);
        
        // Assert
        assertEquals("My-DAG", result.getLabels().get(Constants.DAG_NAME_LABEL));
        assertEquals("Task-Name", result.getLabels().get(Constants.TASK_NAME_LABEL));
    }

    @Test
    @DisplayName("Should use request volume mounts when both request and cluster have volumes")
    void getDriverSpec_whenBothRequestAndClusterHaveVolumes_shouldUseRequestMounts() {
        // Arrange
        List<Object> requestMounts = new ArrayList<>();
        requestMounts.add("request-mount");
        List<Object> clusterMounts = new ArrayList<>();
        clusterMounts.add("cluster-mount");
        
        when(mockRequest.getVolumes()).thenReturn(new ArrayList<>());
        when(mockDriver.getVolumeMounts()).thenReturn(requestMounts);
        when(mockSparkCluster.getVolumes()).thenReturn(new ArrayList<>());
        when(mockClusterDriver.getVolumeMounts()).thenReturn(clusterMounts);
        
        // Act
        DriverSpec result = ApplicationSubmissionHelper.getDriverSpec(
            mockRequest, mockAppConfig, testParentQueue, mockSparkCluster);
        
        // Assert
        assertEquals(requestMounts, result.getVolumeMounts());
    }

    @Test
    @DisplayName("Should use cluster volume mounts when only cluster has volumes")
    void getDriverSpec_whenOnlyClusterHasVolumes_shouldUseClusterMounts() {
        // Arrange
        List<Object> clusterMounts = new ArrayList<>();
        clusterMounts.add("cluster-mount");
        
        when(mockRequest.getDriver()).thenReturn(null);
        when(mockSparkCluster.getVolumes()).thenReturn(new ArrayList<>());
        when(mockClusterDriver.getVolumeMounts()).thenReturn(clusterMounts);
        
        // Act
        DriverSpec result = ApplicationSubmissionHelper.getDriverSpec(
            mockRequest, mockAppConfig, testParentQueue, mockSparkCluster);
        
        // Assert
        assertEquals(clusterMounts, result.getVolumeMounts());
    }

    @Test
    @DisplayName("Should apply CPU buffer ratio to cores")
    void getDriverSpec_shouldApplyCpuBufferRatioToCores() {
        // Arrange
        when(mockDriver.getCores()).thenReturn(4);
        when(mockAppConfig.getDriverCPUBufferRatio()).thenReturn(1.5);
        
        // Act
        DriverSpec result = ApplicationSubmissionHelper.getDriverSpec(
            mockRequest, mockAppConfig, testParentQueue, mockSparkCluster);
        
        // Assert
        assertEquals(6, result.getCores()); // 4 * 1.5 = 6
    }

    @Test
    @DisplayName("Should calculate core limit when not specified")
    void getDriverSpec_whenCoreLimitNotSpecified_shouldCalculateIt() {
        // Arrange
        when(mockDriver.getCores()).thenReturn(4);
        when(mockDriver.getCoreLimit()).thenReturn(null);
        when(mockAppConfig.getDriverCPUBufferRatio()).thenReturn(1.5);
        
        // Act
        DriverSpec result = ApplicationSubmissionHelper.getDriverSpec(
            mockRequest, mockAppConfig, testParentQueue, mockSparkCluster);
        
        // Assert
        assertNotNull(result.getCoreLimit());
        // Expected: ceil(4 * CORE_LIMIT_RATIO * 1.5) = ceil(4 * 1.1 * 1.5) = ceil(6.6) = 7
        assertEquals("7m", result.getCoreLimit());
    }

    @Test
    @DisplayName("Should apply CPU buffer ratio to existing core limit")
    void getDriverSpec_whenCoreLimitSpecified_shouldApplyBufferRatio() {
        // Arrange
        when(mockDriver.getCores()).thenReturn(4);
        when(mockDriver.getCoreLimit()).thenReturn("5");
        when(mockAppConfig.getDriverCPUBufferRatio()).thenReturn(1.2);
        
        // Act
        DriverSpec result = ApplicationSubmissionHelper.getDriverSpec(
            mockRequest, mockAppConfig, testParentQueue, mockSparkCluster);
        
        // Assert
        assertEquals("6", result.getCoreLimit()); // 5 * 1.2 = 6
    }

    @Test
    @DisplayName("Should apply memory buffer ratio to memory")
    void getDriverSpec_shouldApplyMemBufferRatioToMemory() {
        // Arrange
        when(mockDriver.getMemory()).thenReturn("4G");
        when(mockAppConfig.getDriverMemBufferRatio()).thenReturn(1.5);
        
        // Act
        DriverSpec result = ApplicationSubmissionHelper.getDriverSpec(
            mockRequest, mockAppConfig, testParentQueue, mockSparkCluster);
        
        // Assert
        assertEquals("6G", result.getMemory()); // 4 * 1.5 = 6
    }

    @Test
    @DisplayName("Should set scale-in annotation")
    void getDriverSpec_shouldSetScaleInAnnotation() {
        // Act
        DriverSpec result = ApplicationSubmissionHelper.getDriverSpec(
            mockRequest, mockAppConfig, testParentQueue, mockSparkCluster);
        
        // Assert
        assertNotNull(result.getAnnotations());
        assertEquals("false", result.getAnnotations().get("cluster-autoscaler.kubernetes.io/scale-in-disabled"));
    }

    @Test
    @DisplayName("Should set affinity when not specified and node labels available")
    void getDriverSpec_whenAffinityNotSetAndNodeLabelsAvailable_shouldSetAffinity() {
        // Arrange
        List<String> nodeLabelValues = List.of("spark-driver");
        when(mockAppConfig.getDriverNodeLabelKeyForQueue(testParentQueue)).thenReturn("node-role");
        when(mockAppConfig.getDriverNodeLabelValuesForQueue(testParentQueue)).thenReturn(nodeLabelValues);
        
        // Act
        DriverSpec result = ApplicationSubmissionHelper.getDriverSpec(
            mockRequest, mockAppConfig, testParentQueue, mockSparkCluster);
        
        // Assert
        assertNotNull(result.getAffinity());
        assertNotNull(result.getAffinity().getNodeAffinity());
    }

    @Test
    @DisplayName("Should not modify existing affinity")
    void getDriverSpec_whenAffinityAlreadySet_shouldNotModifyIt() {
        // Arrange
        Affinity existingAffinity = new Affinity();
        when(mockDriver.getAffinity()).thenReturn(existingAffinity);
        
        // Act
        DriverSpec result = ApplicationSubmissionHelper.getDriverSpec(
            mockRequest, mockAppConfig, testParentQueue, mockSparkCluster);
        
        // Assert
        assertSame(existingAffinity, result.getAffinity());
    }

    @Test
    @DisplayName("Should handle empty service account by using cluster default")
    void getDriverSpec_whenServiceAccountEmpty_shouldUseClusterDefault() {
        // Arrange
        when(mockDriver.getServiceAccount()).thenReturn("");
        
        // Act
        DriverSpec result = ApplicationSubmissionHelper.getDriverSpec(
            mockRequest, mockAppConfig, testParentQueue, mockSparkCluster);
        
        // Assert
        assertEquals("test-service-account", result.getServiceAccount());
    }

    @Test
    @DisplayName("Should handle null service account by using cluster default")
    void getDriverSpec_whenServiceAccountNull_shouldUseClusterDefault() {
        // Arrange
        when(mockDriver.getServiceAccount()).thenReturn(null);
        
        // Act
        DriverSpec result = ApplicationSubmissionHelper.getDriverSpec(
            mockRequest, mockAppConfig, testParentQueue, mockSparkCluster);
        
        // Assert
        assertEquals("test-service-account", result.getServiceAccount());
    }

    @Test
    @DisplayName("Should handle memory with decimal values correctly")
    void getDriverSpec_whenMemoryHasDecimal_shouldRoundUp() {
        // Arrange
        when(mockDriver.getMemory()).thenReturn("1.5G");
        when(mockAppConfig.getDriverMemBufferRatio()).thenReturn(1.2);
        
        // Act
        DriverSpec result = ApplicationSubmissionHelper.getDriverSpec(
            mockRequest, mockAppConfig, testParentQueue, mockSparkCluster);
        
        // Assert
        // 1.5G * 1.2 = 1.8G -> ceil(1.8) = 2G
        assertEquals("2G", result.getMemory());
    }

    @Test
    @DisplayName("Should handle memory with different units")
    void getDriverSpec_shouldHandleDifferentMemoryUnits() {
        // Arrange
        when(mockDriver.getMemory()).thenReturn("512M");
        when(mockAppConfig.getDriverMemBufferRatio()).thenReturn(1.5);
        
        // Act
        DriverSpec result = ApplicationSubmissionHelper.getDriverSpec(
            mockRequest, mockAppConfig, testParentQueue, mockSparkCluster);
        
        // Assert
        // 512M * 1.5 = 768M
        assertEquals("768M", result.getMemory());
    }
}