package com.apple.spark.core;

import com.apple.spark.AppConfig;
import com.apple.spark.api.SubmitApplicationRequest;
import com.apple.spark.operator.DriverSpec;
import com.apple.spark.operator.ExecutorSpec;
import com.apple.spark.operator.SparkApplicationSpec;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ApplicationSubmissionHelper_2_Test {
    @Mock
    private SparkApplicationSpec mockSparkSpec;
    @Mock
    private SubmitApplicationRequest mockRequest;
    @Mock
    private AppConfig.SparkCluster mockSparkCluster;
    @Mock
    private DriverSpec mockDriverSpec;
    @Mock
    private ExecutorSpec mockExecutorSpec;
    
    private List<String> driverEnvVars;
    private List<String> executorEnvVars;
    private List<String> clusterDriverEnvVars;
    private List<String> clusterExecutorEnvVars;

    @BeforeAll
    static void setupBeforeAll() {
        // No static setup needed for this test
    }

    @BeforeEach
    void setupBeforeEach() {
        driverEnvVars = new ArrayList<>();
        executorEnvVars = new ArrayList<>();
        clusterDriverEnvVars = new ArrayList<>();
        clusterExecutorEnvVars = new ArrayList<>();

        // Setup common mock behaviors
        when(mockSparkSpec.getDriver()).thenReturn(mockDriverSpec);
        when(mockSparkSpec.getExecutor()).thenReturn(mockExecutorSpec);
        when(mockDriverSpec.getEnv()).thenReturn(driverEnvVars);
        when(mockExecutorSpec.getEnv()).thenReturn(executorEnvVars);
    }

    @AfterEach
    void teardownAfterEach() {
        reset(mockSparkSpec, mockRequest, mockSparkCluster, mockDriverSpec, mockExecutorSpec);
    }

    @AfterAll
    static void teardownAfterAll() {
        // No static cleanup needed for this test
    }

    @Test
    @DisplayName("Should not populate env when no env configurations exist")
    void populateEnv_shouldDoNothingWhenNoEnvConfigsExist() {
        // Given - all env configurations are null
        when(mockSparkCluster.getDriver()).thenReturn(null);
        when(mockRequest.getDriver()).thenReturn(null);
        when(mockSparkCluster.getExecutor()).thenReturn(null);
        when(mockRequest.getExecutor()).thenReturn(null);

        // When
        ApplicationSubmissionHelper.populateEnv(mockSparkSpec, mockRequest, mockSparkCluster);

        // Then - verify no interactions with SparkSpecHelper
        verifyNoInteractions(SparkSpecHelper.class);
    }

    @Test
    @DisplayName("Should populate driver env from spark cluster when present")
    void populateEnv_shouldPopulateDriverEnvFromSparkCluster() {
        // Given - spark cluster has driver env
        DriverSpec clusterDriverSpec = mock(DriverSpec.class);
        List<String> clusterDriverEnv = Arrays.asList("CLUSTER_VAR1=value1", "CLUSTER_VAR2=value2");
        when(clusterDriverSpec.getEnv()).thenReturn(clusterDriverEnv);
        when(mockSparkCluster.getDriver()).thenReturn(clusterDriverSpec);

        // When
        ApplicationSubmissionHelper.populateEnv(mockSparkSpec, mockRequest, mockSparkCluster);

        // Then - verify env was copied from cluster to spec
        verify(SparkSpecHelper.class);
        SparkSpecHelper.copyEnv(clusterDriverEnv, driverEnvVars);
    }

    @Test
    @DisplayName("Should populate driver env from request when present")
    void populateEnv_shouldPopulateDriverEnvFromRequest() {
        // Given - request has driver env
        SubmitApplicationRequest.Driver requestDriver = mock(SubmitApplicationRequest.Driver.class);
        List<String> requestDriverEnv = Arrays.asList("REQUEST_VAR1=value1", "REQUEST_VAR2=value2");
        when(requestDriver.getEnv()).thenReturn(requestDriverEnv);
        when(mockRequest.getDriver()).thenReturn(requestDriver);

        // When
        ApplicationSubmissionHelper.populateEnv(mockSparkSpec, mockRequest, mockSparkCluster);

        // Then - verify env was copied from request to spec
        verify(SparkSpecHelper.class);
        SparkSpecHelper.copyEnv(requestDriverEnv, driverEnvVars);
    }

    @Test
    @DisplayName("Should populate executor env from spark cluster when present")
    void populateEnv_shouldPopulateExecutorEnvFromSparkCluster() {
        // Given - spark cluster has executor env
        ExecutorSpec clusterExecutorSpec = mock(ExecutorSpec.class);
        List<String> clusterExecutorEnv = Arrays.asList("CLUSTER_VAR1=value1", "CLUSTER_VAR2=value2");
        when(clusterExecutorSpec.getEnv()).thenReturn(clusterExecutorEnv);
        when(mockSparkCluster.getExecutor()).thenReturn(clusterExecutorSpec);

        // When
        ApplicationSubmissionHelper.populateEnv(mockSparkSpec, mockRequest, mockSparkCluster);

        // Then - verify env was copied from cluster to spec
        verify(SparkSpecHelper.class);
        SparkSpecHelper.copyEnv(clusterExecutorEnv, executorEnvVars);
    }

    @Test
    @DisplayName("Should populate executor env from request when present")
    void populateEnv_shouldPopulateExecutorEnvFromRequest() {
        // Given - request has executor env
        SubmitApplicationRequest.Executor requestExecutor = mock(SubmitApplicationRequest.Executor.class);
        List<String> requestExecutorEnv = Arrays.asList("REQUEST_VAR1=value1", "REQUEST_VAR2=value2");
        when(requestExecutor.getEnv()).thenReturn(requestExecutorEnv);
        when(mockRequest.getExecutor()).thenReturn(requestExecutor);

        // When
        ApplicationSubmissionHelper.populateEnv(mockSparkSpec, mockRequest, mockSparkCluster);

        // Then - verify env was copied from request to spec
        verify(SparkSpecHelper.class);
        SparkSpecHelper.copyEnv(requestExecutorEnv, executorEnvVars);
    }

    @Test
    @DisplayName("Should initialize driver spec when null and env exists in spark cluster")
    void populateEnv_shouldInitializeDriverSpecWhenNullAndClusterHasEnv() {
        // Given - spark spec has no driver spec but cluster has driver env
        when(mockSparkSpec.getDriver()).thenReturn(null);
        DriverSpec clusterDriverSpec = mock(DriverSpec.class);
        List<String> clusterDriverEnv = Arrays.asList("CLUSTER_VAR=value");
        when(clusterDriverSpec.getEnv()).thenReturn(clusterDriverEnv);
        when(mockSparkCluster.getDriver()).thenReturn(clusterDriverSpec);

        // When
        ApplicationSubmissionHelper.populateEnv(mockSparkSpec, mockRequest, mockSparkCluster);

        // Then - verify driver spec was initialized
        verify(mockSparkSpec).setDriver(any(DriverSpec.class));
        verify(SparkSpecHelper.class);
        SparkSpecHelper.copyEnv(clusterDriverEnv, driverEnvVars);
    }

    @Test
    @DisplayName("Should initialize executor spec when null and env exists in request")
    void populateEnv_shouldInitializeExecutorSpecWhenNullAndRequestHasEnv() {
        // Given - spark spec has no executor spec but request has executor env
        when(mockSparkSpec.getExecutor()).thenReturn(null);
        SubmitApplicationRequest.Executor requestExecutor = mock(SubmitApplicationRequest.Executor.class);
        List<String> requestExecutorEnv = Arrays.asList("REQUEST_VAR=value");
        when(requestExecutor.getEnv()).thenReturn(requestExecutorEnv);
        when(mockRequest.getExecutor()).thenReturn(requestExecutor);

        // When
        ApplicationSubmissionHelper.populateEnv(mockSparkSpec, mockRequest, mockSparkCluster);

        // Then - verify executor spec was initialized
        verify(mockSparkSpec).setExecutor(any(ExecutorSpec.class));
        verify(SparkSpecHelper.class);
        SparkSpecHelper.copyEnv(requestExecutorEnv, executorEnvVars);
    }

    @Test
    @DisplayName("Should initialize driver env list when null and env exists in request")
    void populateEnv_shouldInitializeDriverEnvListWhenNullAndRequestHasEnv() {
        // Given - spark spec has driver but no env list, and request has driver env
        when(mockDriverSpec.getEnv()).thenReturn(null);
        SubmitApplicationRequest.Driver requestDriver = mock(SubmitApplicationRequest.Driver.class);
        List<String> requestDriverEnv = Arrays.asList("REQUEST_VAR=value");
        when(requestDriver.getEnv()).thenReturn(requestDriverEnv);
        when(mockRequest.getDriver()).thenReturn(requestDriver);

        // When
        ApplicationSubmissionHelper.populateEnv(mockSparkSpec, mockRequest, mockSparkCluster);

        // Then - verify env list was initialized
        verify(mockDriverSpec).setEnv(anyList());
        verify(SparkSpecHelper.class);
        SparkSpecHelper.copyEnv(requestDriverEnv, driverEnvVars);
    }

    @Test
    @DisplayName("Should handle all env sources together correctly")
    void populateEnv_shouldHandleAllEnvSourcesTogether() {
        // Given - all possible env sources exist
        // Cluster driver env
        DriverSpec clusterDriverSpec = mock(DriverSpec.class);
        List<String> clusterDriverEnv = Arrays.asList("CLUSTER_DRIVER_VAR=value");
        when(clusterDriverSpec.getEnv()).thenReturn(clusterDriverEnv);
        when(mockSparkCluster.getDriver()).thenReturn(clusterDriverSpec);
        
        // Request driver env
        SubmitApplicationRequest.Driver requestDriver = mock(SubmitApplicationRequest.Driver.class);
        List<String> requestDriverEnv = Arrays.asList("REQUEST_DRIVER_VAR=value");
        when(requestDriver.getEnv()).thenReturn(requestDriverEnv);
        when(mockRequest.getDriver()).thenReturn(requestDriver);
        
        // Cluster executor env
        ExecutorSpec clusterExecutorSpec = mock(ExecutorSpec.class);
        List<String> clusterExecutorEnv = Arrays.asList("CLUSTER_EXECUTOR_VAR=value");
        when(clusterExecutorSpec.getEnv()).thenReturn(clusterExecutorEnv);
        when(mockSparkCluster.getExecutor()).thenReturn(clusterExecutorSpec);
        
        // Request executor env
        SubmitApplicationRequest.Executor requestExecutor = mock(SubmitApplicationRequest.Executor.class);
        List<String> requestExecutorEnv = Arrays.asList("REQUEST_EXECUTOR_VAR=value");
        when(requestExecutor.getEnv()).thenReturn(requestExecutorEnv);
        when(mockRequest.getExecutor()).thenReturn(requestExecutor);

        // When
        ApplicationSubmissionHelper.populateEnv(mockSparkSpec, mockRequest, mockSparkCluster);

        // Then - verify all env sources were processed
        verify(SparkSpecHelper.class, times(4));
        SparkSpecHelper.copyEnv(clusterDriverEnv, driverEnvVars);
        SparkSpecHelper.copyEnv(requestDriverEnv, driverEnvVars);
        SparkSpecHelper.copyEnv(clusterExecutorEnv, executorEnvVars);
        SparkSpecHelper.copyEnv(requestExecutorEnv, executorEnvVars);
    }

    @Test
    @DisplayName("Should not fail when env lists are empty")
    void populateEnv_shouldHandleEmptyEnvLists() {
        // Given - env configurations exist but lists are empty
        DriverSpec clusterDriverSpec = mock(DriverSpec.class);
        when(clusterDriverSpec.getEnv()).thenReturn(new ArrayList<>());
        when(mockSparkCluster.getDriver()).thenReturn(clusterDriverSpec);
        
        SubmitApplicationRequest.Driver requestDriver = mock(SubmitApplicationRequest.Driver.class);
        when(requestDriver.getEnv()).thenReturn(new ArrayList<>());
        when(mockRequest.getDriver()).thenReturn(requestDriver);

        // When
        ApplicationSubmissionHelper.populateEnv(mockSparkSpec, mockRequest, mockSparkCluster);

        // Then - verify no errors occurred
        verify(SparkSpecHelper.class, times(2));
        SparkSpecHelper.copyEnv(anyList(), anyList());
    }
}