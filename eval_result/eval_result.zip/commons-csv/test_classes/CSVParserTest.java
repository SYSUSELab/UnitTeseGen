package org.apache.commons.csv;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.*;
import static org.mockito.Mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import java.io.*;
import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.Collections;

@ExtendWith(MockitoExtension.class)
class CSVParserTest {
    @Mock
    private Reader mockReader;
    
    @Mock
    private CSVFormat mockFormat;
    
    @Mock
    private Lexer mockLexer;
    
    @Mock
    private CSVRecordIterator mockCsvRecordIterator;
    
    private CSVParser csvParser;
    private static final CSVFormat DEFAULT_FORMAT = CSVFormat.DEFAULT;
    private static final String TEST_CSV_DATA = "header1,header2\nvalue1,value2";

    @BeforeEach
    void setupBeforeEach() throws IOException {
        MockitoAnnotations.openMocks(this);
        csvParser = new CSVParser(new StringReader(TEST_CSV_DATA), DEFAULT_FORMAT);
    }

    @AfterEach
    void teardownAfterEach() throws IOException {
        if (csvParser != null && !csvParser.isClosed()) {
            csvParser.close();
        }
    }

    @Nested
    @DisplayName("createHeaders() tests")
    class CreateHeadersTests {
        @Test
        @DisplayName("Should return empty headers when formatHeader is null")
        void createHeaders_WhenFormatHeaderIsNull_ReturnsEmptyHeaders() throws IOException {
            // Arrange
            CSVFormat format = CSVFormat.newFormat(',').withHeader((String[]) null);
            CSVParser parser = new CSVParser(new StringReader(""), format);
            
            // Act
            Headers headers = parser.createHeaders();
            
            // Assert
            assertNotNull(headers);
            assertEquals(Collections.emptyList(), headers.getHeaderNames());
            assertTrue(headers.getHeaderMap().isEmpty());
        }

        @Test
        @DisplayName("Should read headers from first line when formatHeader is empty")
        void createHeaders_WhenFormatHeaderIsEmpty_ReadsFromFirstLine() throws IOException {
            // Arrange
            String csvData = "col1,col2\nvalue1,value2";
            CSVFormat format = CSVFormat.newFormat(',').withHeader();
            CSVParser parser = new CSVParser(new StringReader(csvData), format);
            
            // Act
            Headers headers = parser.createHeaders();
            
            // Assert
            assertNotNull(headers);
            assertEquals(Arrays.asList("col1", "col2"), headers.getHeaderNames());
            assertEquals(0, (int) headers.getHeaderMap().get("col1"));
            assertEquals(1, (int) headers.getHeaderMap().get("col2"));
        }

        @Test
        @DisplayName("Should use formatHeader when provided and skipHeaderRecord is false")
        void createHeaders_WhenFormatHeaderProvidedAndNoSkip_UseFormatHeader() throws IOException {
            // Arrange
            String[] formatHeader = {"header1", "header2"};
            CSVFormat format = CSVFormat.newFormat(',')
                .withHeader(formatHeader)
                .withSkipHeaderRecord(false);
            CSVParser parser = new CSVParser(new StringReader(""), format);
            
            // Act
            Headers headers = parser.createHeaders();
            
            // Assert
            assertNotNull(headers);
            assertEquals(Arrays.asList("header1", "header2"), headers.getHeaderNames());
            assertEquals(0, (int) headers.getHeaderMap().get("header1"));
            assertEquals(1, (int) headers.getHeaderMap().get("header2"));
        }

        @Test
        @DisplayName("Should skip first record when formatHeader provided and skipHeaderRecord is true")
        void createHeaders_WhenFormatHeaderProvidedAndSkipTrue_SkipsFirstRecord() throws IOException {
            // Arrange
            String csvData = "skip1,skip2\nvalue1,value2";
            String[] formatHeader = {"header1", "header2"};
            CSVFormat format = CSVFormat.newFormat(',')
                .withHeader(formatHeader)
                .withSkipHeaderRecord(true);
            CSVParser parser = new CSVParser(new StringReader(csvData), format);
            
            // Act
            Headers headers = parser.createHeaders();
            
            // Assert
            assertNotNull(headers);
            assertEquals(Arrays.asList("header1", "header2"), headers.getHeaderNames());
            assertEquals(0, (int) headers.getHeaderMap().get("header1"));
            assertEquals(1, (int) headers.getHeaderMap().get("header2"));
        }

        @Test
        @DisplayName("Should throw exception when blank header and allowMissingColumnNames is false")
        void createHeaders_WhenBlankHeaderAndNotAllowed_ThrowsException() {
            // Arrange
            String[] formatHeader = {"header1", "", "header3"};
            CSVFormat format = CSVFormat.newFormat(',')
                .withHeader(formatHeader)
                .withAllowMissingColumnNames(false);
            CSVParser parser = new CSVParser(new StringReader(""), format);
            
            // Act & Assert
            IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, 
                () -> parser.createHeaders());
            assertTrue(exception.getMessage().contains("A header name is missing"));
        }

        @Test
        @DisplayName("Should allow blank header when allowMissingColumnNames is true")
        void createHeaders_WhenBlankHeaderAndAllowed_DoesNotThrow() throws IOException {
            // Arrange
            String[] formatHeader = {"header1", "", "header3"};
            CSVFormat format = CSVFormat.newFormat(',')
                .withHeader(formatHeader)
                .withAllowMissingColumnNames(true);
            CSVParser parser = new CSVParser(new StringReader(""), format);
            
            // Act
            Headers headers = parser.createHeaders();
            
            // Assert
            assertNotNull(headers);
            assertEquals(Arrays.asList("header1", "header3"), headers.getHeaderNames());
        }

        @Test
        @DisplayName("Should throw exception when duplicate headers not allowed")
        void createHeaders_WhenDuplicateHeadersNotAllowed_ThrowsException() {
            // Arrange
            String[] formatHeader = {"header1", "header1", "header3"};
            CSVFormat format = CSVFormat.newFormat(',')
                .withHeader(formatHeader)
                .withDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW);
            CSVParser parser = new CSVParser(new StringReader(""), format);
            
            // Act & Assert
            IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, 
                () -> parser.createHeaders());
            assertTrue(exception.getMessage().contains("The header contains a duplicate name"));
        }

        @Test
        @DisplayName("Should allow duplicate headers when ALLOW_ALL mode is set")
        void createHeaders_WhenDuplicateHeadersAllowed_DoesNotThrow() throws IOException {
            // Arrange
            String[] formatHeader = {"header1", "header1", "header3"};
            CSVFormat format = CSVFormat.newFormat(',')
                .withHeader(formatHeader)
                .withDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_ALL);
            CSVParser parser = new CSVParser(new StringReader(""), format);
            
            // Act
            Headers headers = parser.createHeaders();
            
            // Assert
            assertNotNull(headers);
            assertEquals(Arrays.asList("header1", "header1", "header3"), headers.getHeaderNames());
        }

        @Test
        @DisplayName("Should allow empty duplicate headers when ALLOW_EMPTY mode is set")
        void createHeaders_WhenEmptyDuplicateHeadersAllowed_DoesNotThrow() throws IOException {
            // Arrange
            String[] formatHeader = {"", "", "header3"};
            CSVFormat format = CSVFormat.newFormat(',')
                .withHeader(formatHeader)
                .withDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY);
            CSVParser parser = new CSVParser(new StringReader(""), format);
            
            // Act
            Headers headers = parser.createHeaders();
            
            // Assert
            assertNotNull(headers);
            assertEquals(Collections.singletonList("header3"), headers.getHeaderNames());
        }

        @Test
        @DisplayName("Should handle null header values gracefully")
        void createHeaders_WhenNullHeaderValues_HandlesGracefully() throws IOException {
            // Arrange
            String[] formatHeader = {"header1", null, "header3"};
            CSVFormat format = CSVFormat.newFormat(',')
                .withHeader(formatHeader)
                .withAllowMissingColumnNames(true);
            CSVParser parser = new CSVParser(new StringReader(""), format);
            
            // Act
            Headers headers = parser.createHeaders();
            
            // Assert
            assertNotNull(headers);
            assertEquals(Arrays.asList("header1", "header3"), headers.getHeaderNames());
        }

        @Test
        @DisplayName("Should return immutable header names collection")
        void createHeaders_ReturnsImmutableHeaderNames() throws IOException {
            // Arrange
            String[] formatHeader = {"header1", "header2"};
            CSVFormat format = CSVFormat.newFormat(',')
                .withHeader(formatHeader);
            CSVParser parser = new CSVParser(new StringReader(""), format);
            
            // Act
            Headers headers = parser.createHeaders();
            
            // Assert
            assertThrows(UnsupportedOperationException.class, 
                () -> headers.getHeaderNames().add("newHeader"));
        }
    }
}