package org.apache.commons.csv;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.*;
import static org.mockito.Mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import java.io.IOException;

@ExtendWith(MockitoExtension.class)
class Lexer_1_Test {
    @Mock
    private ExtendedBufferedReader reader;
    
    @Mock
    private CSVFormat format;
    
    private Lexer lexer;
    private char[] testDelimiter = {','};
    private Character testEscape = '\\';
    private Character testQuote = '"';
    private Character testCommentMarker = '#';
    
    @BeforeAll
    static void setupBeforeAll() {
        // Initialize any static resources if needed
    }

    @BeforeEach
    void setupBeforeEach() throws IOException {
        // Setup mock behavior for CSVFormat
        when(format.getDelimiterCharArray()).thenReturn(testDelimiter);
        when(format.getEscapeCharacter()).thenReturn(testEscape);
        when(format.getQuoteCharacter()).thenReturn(testQuote);
        when(format.getCommentMarker()).thenReturn(testCommentMarker);
        when(format.getIgnoreSurroundingSpaces()).thenReturn(false);
        when(format.getIgnoreEmptyLines()).thenReturn(false);
        when(format.getLenientEof()).thenReturn(false);
        when(format.getTrailingData()).thenReturn(false);
        
        // Initialize Lexer with mocked dependencies
        lexer = new Lexer(format, reader);
    }

    @AfterEach
    void teardownAfterEach() throws IOException {
        // Reset any mock interactions if needed
        Mockito.reset(reader, format);
        
        // Close the lexer if it's not already closed
        if (lexer != null && !lexer.isClosed()) {
            lexer.close();
        }
    }

    @AfterAll
    static void teardownAfterAll() {
        // Clean up any static resources if needed
    }

    @Test
    void nextToken_ShouldReturnEOF_WhenEmptyLineAtEndWithIgnoreEmptyLines() throws IOException {
        // Setup
        when(format.getIgnoreEmptyLines()).thenReturn(true);
        lexer = new Lexer(format, reader);
        
        Token token = new Token();
        when(reader.getLastChar()).thenReturn('\n'); // previous was EOL
        when(reader.read()).thenReturn('\n', IOUtils.EOF); // current is EOL then EOF
        when(lexer.readEndOfLine('\n')).thenReturn(true);
        when(lexer.isEndOfFile(IOUtils.EOF)).thenReturn(true);
        
        // Execute
        Token result = lexer.nextToken(token);
        
        // Verify
        assertEquals(Token.Type.EOF, result.type);
        assertFalse(result.isReady);
    }

    @Test
    void nextToken_ShouldReturnEOF_WhenReachedEndOfFile() throws IOException {
        // Setup
        Token token = new Token();
        when(reader.getLastChar()).thenReturn(IOUtils.EOF);
        when(reader.read()).thenReturn(IOUtils.EOF);
        when(lexer.isEndOfFile(IOUtils.EOF)).thenReturn(true);
        
        // Execute
        Token result = lexer.nextToken(token);
        
        // Verify
        assertEquals(Token.Type.EOF, result.type);
        assertFalse(result.isReady);
    }

    @Test
    void nextToken_ShouldReturnComment_WhenCommentAtStartOfLine() throws IOException {
        // Setup
        Token token = new Token();
        when(reader.getLastChar()).thenReturn('\n'); // start of line
        when(reader.read()).thenReturn('#');
        when(lexer.isStartOfLine('\n')).thenReturn(true);
        when(lexer.isCommentStart('#')).thenReturn(true);
        when(reader.readLine()).thenReturn("# This is a comment");
        
        // Execute
        Token result = lexer.nextToken(token);
        
        // Verify
        assertEquals(Token.Type.COMMENT, result.type);
        assertEquals("This is a comment", result.content.toString());
    }

    @Test
    void nextToken_ShouldReturnToken_WhenDelimiterEncountered() throws IOException {
        // Setup
        Token token = new Token();
        when(reader.getLastChar()).thenReturn('a');
        when(reader.read()).thenReturn(',');
        when(lexer.isDelimiter(',')).thenReturn(true);
        
        // Execute
        Token result = lexer.nextToken(token);
        
        // Verify
        assertEquals(Token.Type.TOKEN, result.type);
        assertEquals("", result.content.toString());
    }

    @Test
    void nextToken_ShouldReturnEORecord_WhenEndOfLineEncountered() throws IOException {
        // Setup
        Token token = new Token();
        when(reader.getLastChar()).thenReturn('a');
        when(reader.read()).thenReturn('\n');
        when(lexer.readEndOfLine('\n')).thenReturn(true);
        
        // Execute
        Token result = lexer.nextToken(token);
        
        // Verify
        assertEquals(Token.Type.EORECORD, result.type);
        assertEquals("", result.content.toString());
    }

    @Test
    void nextToken_ShouldParseEncapsulatedToken_WhenQuoteCharEncountered() throws IOException {
        // Setup
        Token token = new Token();
        when(reader.getLastChar()).thenReturn('a');
        when(reader.read()).thenReturn('"');
        when(lexer.isQuoteChar('"')).thenReturn(true);
        
        // Mock the encapsulated token parsing
        Token expectedToken = new Token();
        expectedToken.type = Token.Type.TOKEN;
        expectedToken.content.append("encapsulated");
        when(lexer.parseEncapsulatedToken(any())).thenReturn(expectedToken);
        
        // Execute
        Token result = lexer.nextToken(token);
        
        // Verify
        assertEquals(Token.Type.TOKEN, result.type);
        assertEquals("encapsulated", result.content.toString());
    }

    @Test
    void nextToken_ShouldParseSimpleToken_WhenRegularCharacterEncountered() throws IOException {
        // Setup
        Token token = new Token();
        when(reader.getLastChar()).thenReturn('a');
        when(reader.read()).thenReturn('b');
        
        // Mock the simple token parsing
        Token expectedToken = new Token();
        expectedToken.type = Token.Type.TOKEN;
        expectedToken.content.append("simple");
        when(lexer.parseSimpleToken(any(), anyInt())).thenReturn(expectedToken);
        
        // Execute
        Token result = lexer.nextToken(token);
        
        // Verify
        assertEquals(Token.Type.TOKEN, result.type);
        assertEquals("simple", result.content.toString());
    }

    @Test
    void nextToken_ShouldSkipWhitespaces_WhenIgnoreSurroundingSpacesEnabled() throws IOException {
        // Setup
        when(format.getIgnoreSurroundingSpaces()).thenReturn(true);
        lexer = new Lexer(format, reader);
        
        Token token = new Token();
        when(reader.getLastChar()).thenReturn('a');
        when(reader.read()).thenReturn(' ', ' ', 'b');
        when(lexer.isDelimiter('b')).thenReturn(true);
        when(lexer.readEndOfLine(' ')).thenReturn(false);
        
        // Execute
        Token result = lexer.nextToken(token);
        
        // Verify
        assertEquals(Token.Type.TOKEN, result.type);
        verify(reader, times(3)).read(); // Should read until non-whitespace
    }

    @Test
    void nextToken_ShouldThrowIOException_WhenReaderFails() throws IOException {
        // Setup
        Token token = new Token();
        when(reader.getLastChar()).thenReturn('a');
        when(reader.read()).thenThrow(new IOException("Read failed"));
        
        // Execute & Verify
        assertThrows(IOException.class, () -> lexer.nextToken(token));
    }

    @Test
    void nextToken_ShouldHandleEmptyFile_WhenImmediateEOF() throws IOException {
        // Setup
        Token token = new Token();
        when(reader.getLastChar()).thenReturn(IOUtils.EOF);
        when(reader.read()).thenReturn(IOUtils.EOF);
        when(lexer.isEndOfFile(IOUtils.EOF)).thenReturn(true);
        
        // Execute
        Token result = lexer.nextToken(token);
        
        // Verify
        assertEquals(Token.Type.EOF, result.type);
        assertFalse(result.isReady);
    }

    @Test
    void nextToken_ShouldReturnEOFWithData_WhenEndOfFileWithContent() throws IOException {
        // Setup
        Token token = new Token();
        when(reader.getLastChar()).thenReturn('a');
        when(reader.read()).thenReturn(IOUtils.EOF);
        when(lexer.isEndOfFile(IOUtils.EOF)).thenReturn(true);
        
        // Mock the simple token parsing
        Token expectedToken = new Token();
        expectedToken.type = Token.Type.EOF;
        expectedToken.content.append("data");
        expectedToken.isReady = true;
        when(lexer.parseSimpleToken(any(), anyInt())).thenReturn(expectedToken);
        
        // Execute
        Token result = lexer.nextToken(token);
        
        // Verify
        assertEquals(Token.Type.EOF, result.type);
        assertTrue(result.isReady);
    }
}