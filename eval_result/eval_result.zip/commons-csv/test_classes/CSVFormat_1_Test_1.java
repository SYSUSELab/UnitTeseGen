package org.apache.commons.csv;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.*;
import static org.mockito.Mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class CSVFormat_1_Test {
    private CSVFormat defaultFormat;
    private CSVFormat excelFormat;
    private CSVFormat customFormat;
    
    @BeforeEach
    void setupBeforeEach() {
        defaultFormat = CSVFormat.DEFAULT;
        excelFormat = CSVFormat.EXCEL;
        
        customFormat = CSVFormat.DEFAULT.builder()
            .setDelimiter(';')
            .setEscape('\\')
            .setQuote('\'')
            .setQuoteMode(QuoteMode.ALL)
            .setCommentMarker('#')
            .setNullString("NULL")
            .setRecordSeparator("\r\n")
            .setIgnoreEmptyLines(true)
            .setIgnoreSurroundingSpaces(true)
            .setIgnoreHeaderCase(true)
            .setSkipHeaderRecord(true)
            .setHeaderComments("HeaderComment")
            .setHeader("Header1", "Header2")
            .get();
    }

    @AfterEach
    void teardownAfterEach() {
        defaultFormat = null;
        excelFormat = null;
        customFormat = null;
    }

    @Test
    @DisplayName("Test toString() with DEFAULT format")
    void testToStringWithDefaultFormat() {
        // Arrange - DEFAULT format is already set up in beforeEach
        
        // Act
        String result = defaultFormat.toString();
        
        // Assert
        assertNotNull(result);
        assertTrue(result.startsWith("Delimiter=<,>"));
        assertFalse(result.contains("Escape="));  // No escape character in DEFAULT
        assertFalse(result.contains("QuoteChar=")); // No quote character in DEFAULT
        assertFalse(result.contains("QuoteMode=")); // No quote mode in DEFAULT
        assertFalse(result.contains("CommentStart=")); // No comment marker in DEFAULT
        assertFalse(result.contains("NullString=")); // No null string in DEFAULT
        assertFalse(result.contains("RecordSeparator=")); // No record separator in DEFAULT
        assertFalse(result.contains("EmptyLines:ignored")); // Not ignoring empty lines
        assertFalse(result.contains("SurroundingSpaces:ignored")); // Not ignoring spaces
        assertFalse(result.contains("IgnoreHeaderCase:ignored")); // Not ignoring header case
        assertTrue(result.contains("SkipHeaderRecord:false")); // Default skip header record
        assertFalse(result.contains("HeaderComments:")); // No header comments
        assertFalse(result.contains("Header:")); // No headers
    }

    @Test
    @DisplayName("Test toString() with all optional fields set")
    void testToStringWithAllFieldsSet() {
        // Arrange - customFormat has all optional fields set
        
        // Act
        String result = customFormat.toString();
        
        // Assert
        assertNotNull(result);
        assertTrue(result.startsWith("Delimiter=<;>"));
        assertTrue(result.contains(" Escape=<\\>"));
        assertTrue(result.contains(" QuoteChar=<'>"));
        assertTrue(result.contains(" QuoteMode=<ALL>"));
        assertTrue(result.contains(" CommentStart=<#>"));
        assertTrue(result.contains(" NullString=<NULL>"));
        assertTrue(result.contains(" RecordSeparator=<\r\n>"));
        assertTrue(result.contains(" EmptyLines:ignored"));
        assertTrue(result.contains(" SurroundingSpaces:ignored"));
        assertTrue(result.contains(" IgnoreHeaderCase:ignored"));
        assertTrue(result.contains(" SkipHeaderRecord:true"));
        assertTrue(result.contains(" HeaderComments:[HeaderComment]"));
        assertTrue(result.contains(" Header:[Header1, Header2]"));
    }

    @Test
    @DisplayName("Test toString() with only delimiter set")
    void testToStringWithOnlyDelimiter() {
        // Arrange
        CSVFormat format = CSVFormat.newFormat('|');
        
        // Act
        String result = format.toString();
        
        // Assert
        assertEquals("Delimiter=<|> SkipHeaderRecord:false", result);
    }

    @Test
    @DisplayName("Test toString() with null quote character")
    void testToStringWithNullQuoteCharacter() {
        // Arrange
        CSVFormat format = CSVFormat.DEFAULT.builder()
            .setQuote(null)
            .get();
        
        // Act
        String result = format.toString();
        
        // Assert
        assertFalse(result.contains("QuoteChar="));
    }

    @Test
    @DisplayName("Test toString() with null record separator")
    void testToStringWithNullRecordSeparator() {
        // Arrange
        CSVFormat format = CSVFormat.DEFAULT.builder()
            .setRecordSeparator(null)
            .get();
        
        // Act
        String result = format.toString();
        
        // Assert
        assertFalse(result.contains("RecordSeparator="));
    }

    @Test
    @DisplayName("Test toString() with empty header comments")
    void testToStringWithEmptyHeaderComments() {
        // Arrange
        CSVFormat format = CSVFormat.DEFAULT.builder()
            .setHeaderComments(new String[0])
            .get();
        
        // Act
        String result = format.toString();
        
        // Assert
        assertTrue(result.contains("HeaderComments:[]"));
    }

    @Test
    @DisplayName("Test toString() with multiple header comments")
    void testToStringWithMultipleHeaderComments() {
        // Arrange
        CSVFormat format = CSVFormat.DEFAULT.builder()
            .setHeaderComments("Comment1", "Comment2")
            .get();
        
        // Act
        String result = format.toString();
        
        // Assert
        assertTrue(result.contains("HeaderComments:[Comment1, Comment2]"));
    }

    @Test
    @DisplayName("Test toString() with empty headers")
    void testToStringWithEmptyHeaders() {
        // Arrange
        CSVFormat format = CSVFormat.DEFAULT.builder()
            .setHeader(new String[0])
            .get();
        
        // Act
        String result = format.toString();
        
        // Assert
        assertTrue(result.contains("Header:[]"));
    }

    @Test
    @DisplayName("Test toString() with multiple headers")
    void testToStringWithMultipleHeaders() {
        // Arrange
        CSVFormat format = CSVFormat.DEFAULT.builder()
            .setHeader("Col1", "Col2", "Col3")
            .get();
        
        // Act
        String result = format.toString();
        
        // Assert
        assertTrue(result.contains("Header:[Col1, Col2, Col3]"));
    }

    @Test
    @DisplayName("Test toString() with EXCEL format")
    void testToStringWithExcelFormat() {
        // Arrange - excelFormat is already set up in beforeEach
        
        // Act
        String result = excelFormat.toString();
        
        // Assert
        assertNotNull(result);
        assertTrue(result.startsWith("Delimiter=<,>"));
        assertFalse(result.contains("Escape=")); // No escape in EXCEL
        assertTrue(result.contains(" QuoteChar=<\">")); // EXCEL uses double quote
        assertFalse(result.contains("QuoteMode=")); // No quote mode in EXCEL
        assertFalse(result.contains("CommentStart=")); // No comment marker in EXCEL
        assertFalse(result.contains("NullString=")); // No null string in EXCEL
        assertFalse(result.contains("RecordSeparator=")); // No record separator in EXCEL
        assertFalse(result.contains("EmptyLines:ignored")); // EXCEL doesn't ignore empty lines
        assertFalse(result.contains("SurroundingSpaces:ignored")); // EXCEL doesn't ignore spaces
        assertFalse(result.contains("IgnoreHeaderCase:ignored")); // EXCEL doesn't ignore header case
        assertTrue(result.contains("SkipHeaderRecord:false")); // Default skip header record
        assertFalse(result.contains("HeaderComments:")); // No header comments
        assertFalse(result.contains("Header:")); // No headers
    }

    @Test
    @DisplayName("Test toString() with minimal configuration")
    void testToStringWithMinimalConfiguration() {
        // Arrange
        CSVFormat format = CSVFormat.newFormat('\t');
        
        // Act
        String result = format.toString();
        
        // Assert
        assertEquals("Delimiter=<\t> SkipHeaderRecord:false", result);
    }

    @Test
    @DisplayName("Test toString() with all boolean flags set to false")
    void testToStringWithAllBooleanFlagsFalse() {
        // Arrange
        CSVFormat format = CSVFormat.DEFAULT.builder()
            .setIgnoreEmptyLines(false)
            .setIgnoreSurroundingSpaces(false)
            .setIgnoreHeaderCase(false)
            .setSkipHeaderRecord(false)
            .get();
        
        // Act
        String result = format.toString();
        
        // Assert
        assertFalse(result.contains("EmptyLines:ignored"));
        assertFalse(result.contains("SurroundingSpaces:ignored"));
        assertFalse(result.contains("IgnoreHeaderCase:ignored"));
        assertTrue(result.contains("SkipHeaderRecord:false"));
    }
}