package org.apache.commons.csv;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.*;
import static org.mockito.Mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import java.io.IOException;
import java.io.StringWriter;

@ExtendWith(MockitoExtension.class)
class CSVFormatTest {
    private CSVFormat defaultFormat;
    private CSVFormat excelFormat;
    private CSVFormat rfc4180Format;
    private StringWriter writer;
    
    @Mock
    private Appendable mockAppendable;

    @BeforeEach
    void setupBeforeEach() {
        defaultFormat = CSVFormat.DEFAULT;
        excelFormat = CSVFormat.EXCEL;
        rfc4180Format = CSVFormat.RFC4180;
        writer = new StringWriter();
        Mockito.reset(mockAppendable);
    }

    @AfterEach
    void teardownAfterEach() {
        writer = null;
    }

    // Helper method to get a format with specific quote mode
    private CSVFormat getFormatWithQuoteMode(QuoteMode quoteMode) {
        return defaultFormat.builder()
                .setQuote('"')
                .setQuoteMode(quoteMode)
                .get();
    }

    @Test
    void testPrintWithQuotes_QuoteModeAll() throws IOException {
        // Setup
        CSVFormat format = getFormatWithQuoteMode(QuoteMode.ALL);
        String input = "test";
        
        // Execute
        format.printWithQuotes(null, input, writer, false);
        
        // Verify
        assertEquals("\"test\"", writer.toString());
    }

    @Test
    void testPrintWithQuotes_QuoteModeAllNonNull_WithNullObject() throws IOException {
        // Setup
        CSVFormat format = getFormatWithQuoteMode(QuoteMode.ALL_NON_NULL);
        String input = "test";
        
        // Execute
        format.printWithQuotes(null, input, writer, false);
        
        // Verify
        assertEquals("\"test\"", writer.toString());
    }

    @Test
    void testPrintWithQuotes_QuoteModeNonNumeric_WithNumber() throws IOException {
        // Setup
        CSVFormat format = getFormatWithQuoteMode(QuoteMode.NON_NUMERIC);
        Integer number = 123;
        
        // Execute
        format.printWithQuotes(number, number.toString(), writer, false);
        
        // Verify
        assertEquals("123", writer.toString());
    }

    @Test
    void testPrintWithQuotes_QuoteModeNonNumeric_WithString() throws IOException {
        // Setup
        CSVFormat format = getFormatWithQuoteMode(QuoteMode.NON_NUMERIC);
        String input = "test";
        
        // Execute
        format.printWithQuotes(input, input, writer, false);
        
        // Verify
        assertEquals("\"test\"", writer.toString());
    }

    @Test
    void testPrintWithQuotes_QuoteModeNone() throws IOException {
        // Setup
        CSVFormat format = getFormatWithQuoteMode(QuoteMode.NONE);
        String input = "test,value";
        
        // Execute
        format.printWithQuotes(null, input, writer, false);
        
        // Verify
        assertEquals("test,value", writer.toString());
    }

    @Test
    void testPrintWithQuotes_QuoteModeMinimal_EmptyStringNewRecord() throws IOException {
        // Setup
        CSVFormat format = getFormatWithQuoteMode(QuoteMode.MINIMAL);
        
        // Execute
        format.printWithQuotes(null, "", writer, true);
        
        // Verify
        assertEquals("\"\"", writer.toString());
    }

    @Test
    void testPrintWithQuotes_QuoteModeMinimal_EmptyStringNotNewRecord() throws IOException {
        // Setup
        CSVFormat format = getFormatWithQuoteMode(QuoteMode.MINIMAL);
        
        // Execute
        format.printWithQuotes(null, "", writer, false);
        
        // Verify
        assertEquals("", writer.toString());
    }

    @Test
    void testPrintWithQuotes_QuoteModeMinimal_ContainsDelimiter() throws IOException {
        // Setup
        CSVFormat format = defaultFormat.builder()
                .setQuote('"')
                .setDelimiter(',')
                .setQuoteMode(QuoteMode.MINIMAL)
                .get();
        String input = "test,value";
        
        // Execute
        format.printWithQuotes(null, input, writer, false);
        
        // Verify
        assertEquals("\"test,value\"", writer.toString());
    }

    @Test
    void testPrintWithQuotes_QuoteModeMinimal_ContainsQuoteChar() throws IOException {
        // Setup
        CSVFormat format = getFormatWithQuoteMode(QuoteMode.MINIMAL);
        String input = "test\"value";
        
        // Execute
        format.printWithQuotes(null, input, writer, false);
        
        // Verify
        assertEquals("\"test\"\"value\"", writer.toString());
    }

    @Test
    void testPrintWithQuotes_QuoteModeMinimal_ContainsEscapeChar() throws IOException {
        // Setup
        CSVFormat format = defaultFormat.builder()
                .setQuote('"')
                .setEscape('\\')
                .setQuoteMode(QuoteMode.MINIMAL)
                .get();
        String input = "test\\value";
        
        // Execute
        format.printWithQuotes(null, input, writer, false);
        
        // Verify
        assertEquals("\"test\\value\"", writer.toString());
    }

    @Test
    void testPrintWithQuotes_QuoteModeMinimal_StartsWithControlChar() throws IOException {
        // Setup
        CSVFormat format = getFormatWithQuoteMode(QuoteMode.MINIMAL);
        String input = "\u0001test";
        
        // Execute
        format.printWithQuotes(null, input, writer, false);
        
        // Verify
        assertEquals("\"\u0001test\"", writer.toString());
    }

    @Test
    void testPrintWithQuotes_QuoteModeMinimal_EndsWithTrimChar() throws IOException {
        // Setup
        CSVFormat format = getFormatWithQuoteMode(QuoteMode.MINIMAL);
        String input = "test ";
        
        // Execute
        format.printWithQuotes(null, input, writer, false);
        
        // Verify
        assertEquals("\"test \"", writer.toString());
    }

    @Test
    void testPrintWithQuotes_QuoteModeMinimal_NoSpecialChars() throws IOException {
        // Setup
        CSVFormat format = getFormatWithQuoteMode(QuoteMode.MINIMAL);
        String input = "test";
        
        // Execute
        format.printWithQuotes(null, input, writer, false);
        
        // Verify
        assertEquals("test", writer.toString());
    }

    @Test
    void testPrintWithQuotes_InvalidQuoteMode() throws IOException {
        // Setup
        CSVFormat format = defaultFormat.builder()
                .setQuoteMode(null) // Will be set to MINIMAL in the method
                .get();
        
        // This should not throw an exception
        assertDoesNotThrow(() -> format.printWithQuotes(null, "test", writer, false));
    }

    @Test
    void testPrintWithQuotes_IOExceptionFromAppendable() throws IOException {
        // Setup
        CSVFormat format = getFormatWithQuoteMode(QuoteMode.ALL);
        doThrow(new IOException("Test exception")).when(mockAppendable).append(anyChar());
        
        // Execute & Verify
        assertThrows(IOException.class, () -> 
            format.printWithQuotes(null, "test", mockAppendable, false));
    }

    @Test
    void testPrintWithQuotes_NullCharSequence() throws IOException {
        // Setup
        CSVFormat format = getFormatWithQuoteMode(QuoteMode.ALL);
        
        // Execute & Verify
        assertThrows(NullPointerException.class, () -> 
            format.printWithQuotes(null, null, writer, false));
    }

    @Test
    void testPrintWithQuotes_NullAppendable() throws IOException {
        // Setup
        CSVFormat format = getFormatWithQuoteMode(QuoteMode.ALL);
        
        // Execute & Verify
        assertThrows(NullPointerException.class, () -> 
            format.printWithQuotes(null, "test", null, false));
    }
}