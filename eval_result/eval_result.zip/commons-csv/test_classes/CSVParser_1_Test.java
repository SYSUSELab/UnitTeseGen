package org.apache.commons.csv;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.*;
import static org.mockito.Mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import java.io.*;
import java.nio.charset.Charset;
import java.lang.reflect.Field;

@ExtendWith(MockitoExtension.class)
class CSVParser_1_Test {
    @Mock
    private Reader mockReader;
    @Mock
    private Lexer mockLexer;
    @Mock
    private ExtendedBufferedReader mockBufferedReader;
    
    private CSVFormat csvFormat;
    private CSVParser csvParser;
    private Token reusableToken;

    @BeforeAll
    static void setupBeforeAll() {
        // Initialize any static resources if needed
    }

    @BeforeEach
    void setupBeforeEach() throws IOException {
        csvFormat = CSVFormat.DEFAULT;
        reusableToken = new Token();
        
        // Setup mock behavior
        when(mockLexer.getCharacterPosition()).thenReturn(0L);
        when(mockLexer.getBytesRead()).thenReturn(0L);
        
        // Create parser instance with mocks
        csvParser = new CSVParser(mockReader, csvFormat);
        
        // Use reflection to inject mock lexer for testing
        try {
            Field lexerField = CSVParser.class.getDeclaredField("lexer");
            lexerField.setAccessible(true);
            lexerField.set(csvParser, mockLexer);
            
            Field tokenField = CSVParser.class.getDeclaredField("reusableToken");
            tokenField.setAccessible(true);
            tokenField.set(csvParser, reusableToken);
        } catch (Exception e) {
            throw new RuntimeException("Failed to inject mock dependencies", e);
        }
    }

    @AfterEach
    void teardownAfterEach() throws IOException {
        if (csvParser != null) {
            csvParser.close();
        }
        reset(mockReader, mockLexer, mockBufferedReader);
    }

    @AfterAll
    static void teardownAfterAll() {
        // Clean up any static resources if needed
    }

    @Test
    @DisplayName("Should return null when no records are parsed")
    void nextRecord_ShouldReturnNull_WhenNoRecords() throws IOException {
        // Arrange
        when(mockLexer.nextToken(any(Token.class))).thenAnswer(invocation -> {
            Token token = invocation.getArgument(0);
            token.type = Token.Type.EOF;
            token.isReady = false;
            return null;
        });

        // Act
        CSVRecord result = csvParser.nextRecord();

        // Assert
        assertNull(result);
    }

    @Test
    @DisplayName("Should return valid CSVRecord when TOKEN and EORECORD tokens are received")
    void nextRecord_ShouldReturnCSVRecord_WhenTokenAndEORecord() throws IOException {
        // Arrange
        when(mockLexer.nextToken(any(Token.class))).thenAnswer(invocation -> {
            Token token = invocation.getArgument(0);
            token.type = Token.Type.TOKEN;
            token.content = "value1";
            return null;
        }).thenAnswer(invocation -> {
            Token token = invocation.getArgument(0);
            token.type = Token.Type.EORECORD;
            return null;
        });

        // Act
        CSVRecord result = csvParser.nextRecord();

        // Assert
        assertNotNull(result);
        assertEquals(1, result.getRecordNumber());
        assertArrayEquals(new String[]{"value1"}, result.values());
    }

    @Test
    @DisplayName("Should handle EOF token with isReady=true by creating record")
    void nextRecord_ShouldCreateRecord_WhenEOFWithIsReadyTrue() throws IOException {
        // Arrange
        when(mockLexer.nextToken(any(Token.class))).thenAnswer(invocation -> {
            Token token = invocation.getArgument(0);
            token.type = Token.Type.TOKEN;
            token.content = "value1";
            return null;
        }).thenAnswer(invocation -> {
            Token token = invocation.getArgument(0);
            token.type = Token.Type.EOF;
            token.isReady = true;
            return null;
        });

        // Act
        CSVRecord result = csvParser.nextRecord();

        // Assert
        assertNotNull(result);
        assertEquals(1, result.getRecordNumber());
        assertArrayEquals(new String[]{"value1"}, result.values());
    }

    @Test
    @DisplayName("Should store trailer comment when EOF token with isReady=false and sb exists")
    void nextRecord_ShouldStoreTrailerComment_WhenEOFWithIsReadyFalseAndStringBuilderExists() throws IOException {
        // Arrange
        when(mockLexer.nextToken(any(Token.class))).thenAnswer(invocation -> {
            Token token = invocation.getArgument(0);
            token.type = Token.Type.COMMENT;
            token.content = "comment1";
            return null;
        }).thenAnswer(invocation -> {
            Token token = invocation.getArgument(0);
            token.type = Token.Type.EOF;
            token.isReady = false;
            return null;
        });

        // Act
        CSVRecord result = csvParser.nextRecord();

        // Assert
        assertNull(result);
        assertEquals("comment1", csvParser.getTrailerComment());
    }

    @Test
    @DisplayName("Should throw CSVException when INVALID token is received")
    void nextRecord_ShouldThrowCSVException_WhenInvalidToken() throws IOException {
        // Arrange
        when(mockLexer.nextToken(any(Token.class))).thenAnswer(invocation -> {
            Token token = invocation.getArgument(0);
            token.type = Token.Type.INVALID;
            return null;
        });

        // Act & Assert
        assertThrows(CSVException.class, () -> csvParser.nextRecord());
    }

    @Test
    @DisplayName("Should throw CSVException when unexpected token type is received")
    void nextRecord_ShouldThrowCSVException_WhenUnexpectedTokenType() throws IOException {
        // Arrange
        when(mockLexer.nextToken(any(Token.class))).thenAnswer(invocation -> {
            Token token = invocation.getArgument(0);
            token.type = Token.Type.UNKNOWN; // Some unexpected type
            return null;
        });

        // Act & Assert
        assertThrows(CSVException.class, () -> csvParser.nextRecord());
    }

    @Test
    @DisplayName("Should handle multiple comments and append them with line breaks")
    void nextRecord_ShouldHandleMultipleComments_WithLineBreaks() throws IOException {
        // Arrange
        when(mockLexer.nextToken(any(Token.class))).thenAnswer(invocation -> {
            Token token = invocation.getArgument(0);
            token.type = Token.Type.COMMENT;
            token.content = "comment1";
            return null;
        }).thenAnswer(invocation -> {
            Token token = invocation.getArgument(0);
            token.type = Token.Type.TOKEN;
            token.content = "value1";
            return null;
        }).thenAnswer(invocation -> {
            Token token = invocation.getArgument(0);
            token.type = Token.Type.COMMENT;
            token.content = "comment2";
            return null;
        }).thenAnswer(invocation -> {
            Token token = invocation.getArgument(0);
            token.type = Token.Type.EORECORD;
            return null;
        });

        // Act
        CSVRecord result = csvParser.nextRecord();

        // Assert
        assertNotNull(result);
        assertEquals("comment1\ncomment2", result.getComment());
    }

    @Test
    @DisplayName("Should clear recordList before processing new record")
    void nextRecord_ShouldClearRecordList_BeforeProcessing() throws IOException {
        // Arrange
        // First call - create a record
        when(mockLexer.nextToken(any(Token.class))).thenAnswer(invocation -> {
            Token token = invocation.getArgument(0);
            token.type = Token.Type.TOKEN;
            token.content = "value1";
            return null;
        }).thenAnswer(invocation -> {
            Token token = invocation.getArgument(0);
            token.type = Token.Type.EORECORD;
            return null;
        });

        CSVRecord firstRecord = csvParser.nextRecord();
        assertNotNull(firstRecord);

        // Second call - verify recordList was cleared
        when(mockLexer.nextToken(any(Token.class))).thenAnswer(invocation -> {
            Token token = invocation.getArgument(0);
            token.type = Token.Type.TOKEN;
            token.content = "value2";
            return null;
        }).thenAnswer(invocation -> {
            Token token = invocation.getArgument(0);
            token.type = Token.Type.EORECORD;
            return null;
        });

        // Act
        CSVRecord secondRecord = csvParser.nextRecord();

        // Assert
        assertNotNull(secondRecord);
        assertEquals(2, secondRecord.getRecordNumber());
        assertArrayEquals(new String[]{"value2"}, secondRecord.values());
    }

    @Test
    @DisplayName("Should increment recordNumber for each new record")
    void nextRecord_ShouldIncrementRecordNumber_ForEachNewRecord() throws IOException {
        // Arrange
        when(mockLexer.nextToken(any(Token.class)))
            .thenAnswer(invocation -> {
                Token token = invocation.getArgument(0);
                token.type = Token.Type.TOKEN;
                token.content = "value1";
                return null;
            })
            .thenAnswer(invocation -> {
                Token token = invocation.getArgument(0);
                token.type = Token.Type.EORECORD;
                return null;
            })
            .thenAnswer(invocation -> {
                Token token = invocation.getArgument(0);
                token.type = Token.Type.TOKEN;
                token.content = "value2";
                return null;
            })
            .thenAnswer(invocation -> {
                Token token = invocation.getArgument(0);
                token.type = Token.Type.EORECORD;
                return null;
            });

        // Act
        CSVRecord firstRecord = csvParser.nextRecord();
        CSVRecord secondRecord = csvParser.nextRecord();

        // Assert
        assertEquals(1, firstRecord.getRecordNumber());
        assertEquals(2, secondRecord.getRecordNumber());
    }
}