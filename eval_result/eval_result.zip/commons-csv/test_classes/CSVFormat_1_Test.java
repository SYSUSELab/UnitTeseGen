package org.apache.commons.csv;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.stream.Stream;

class CSVFormat_1_Test {

    @Test
    void toString_withMinimumSettings_shouldReturnBasicFormat() {
        // Setup: Create format with only delimiter set (minimum required)
        CSVFormat format = CSVFormat.newFormat(',').builder().get();
        
        // Execute
        String result = format.toString();
        
        // Verify
        assertEquals("Delimiter=<,> SkipHeaderRecord:false", result);
    }

    @Test
    void toString_withEscapeCharacter_shouldIncludeEscapeSetting() {
        // Setup: Create format with delimiter and escape character
        CSVFormat format = CSVFormat.newFormat(',')
            .builder()
            .setEscape('\\')
            .get();
        
        // Execute
        String result = format.toString();
        
        // Verify
        assertEquals("Delimiter=<,> Escape=<\\> SkipHeaderRecord:false", result);
    }

    @Test
    void toString_withQuoteCharacter_shouldIncludeQuoteSetting() {
        // Setup: Create format with delimiter and quote character
        CSVFormat format = CSVFormat.newFormat(',')
            .builder()
            .setQuote('"')
            .get();
        
        // Execute
        String result = format.toString();
        
        // Verify
        assertEquals("Delimiter=<,> QuoteChar=<\"> SkipHeaderRecord:false", result);
    }

    @Test
    void toString_withQuoteMode_shouldIncludeQuoteModeSetting() {
        // Setup: Create format with delimiter and quote mode
        CSVFormat format = CSVFormat.newFormat(',')
            .builder()
            .setQuoteMode(QuoteMode.ALL)
            .get();
        
        // Execute
        String result = format.toString();
        
        // Verify
        assertEquals("Delimiter=<,> QuoteMode=<ALL> SkipHeaderRecord:false", result);
    }

    @Test
    void toString_withCommentMarker_shouldIncludeCommentSetting() {
        // Setup: Create format with delimiter and comment marker
        CSVFormat format = CSVFormat.newFormat(',')
            .builder()
            .setCommentMarker('#')
            .get();
        
        // Execute
        String result = format.toString();
        
        // Verify
        assertEquals("Delimiter=<,> CommentStart=<#> SkipHeaderRecord:false", result);
    }

    @Test
    void toString_withNullString_shouldIncludeNullStringSetting() {
        // Setup: Create format with delimiter and null string
        CSVFormat format = CSVFormat.newFormat(',')
            .builder()
            .setNullString("NULL")
            .get();
        
        // Execute
        String result = format.toString();
        
        // Verify
        assertEquals("Delimiter=<,> NullString=<NULL> SkipHeaderRecord:false", result);
    }

    @Test
    void toString_withRecordSeparator_shouldIncludeRecordSeparatorSetting() {
        // Setup: Create format with delimiter and record separator
        CSVFormat format = CSVFormat.newFormat(',')
            .builder()
            .setRecordSeparator("\r\n")
            .get();
        
        // Execute
        String result = format.toString();
        
        // Verify
        assertEquals("Delimiter=<,> RecordSeparator=<\r\n> SkipHeaderRecord:false", result);
    }

    @Test
    void toString_withIgnoreEmptyLines_shouldIncludeEmptyLinesSetting() {
        // Setup: Create format with delimiter and ignore empty lines
        CSVFormat format = CSVFormat.newFormat(',')
            .builder()
            .setIgnoreEmptyLines(true)
            .get();
        
        // Execute
        String result = format.toString();
        
        // Verify
        assertEquals("Delimiter=<,> EmptyLines:ignored SkipHeaderRecord:false", result);
    }

    @Test
    void toString_withIgnoreSurroundingSpaces_shouldIncludeSurroundingSpacesSetting() {
        // Setup: Create format with delimiter and ignore surrounding spaces
        CSVFormat format = CSVFormat.newFormat(',')
            .builder()
            .setIgnoreSurroundingSpaces(true)
            .get();
        
        // Execute
        String result = format.toString();
        
        // Verify
        assertEquals("Delimiter=<,> SurroundingSpaces:ignored SkipHeaderRecord:false", result);
    }

    @Test
    void toString_withIgnoreHeaderCase_shouldIncludeHeaderCaseSetting() {
        // Setup: Create format with delimiter and ignore header case
        CSVFormat format = CSVFormat.newFormat(',')
            .builder()
            .setIgnoreHeaderCase(true)
            .get();
        
        // Execute
        String result = format.toString();
        
        // Verify
        assertEquals("Delimiter=<,> IgnoreHeaderCase:ignored SkipHeaderRecord:false", result);
    }

    @Test
    void toString_withSkipHeaderRecord_shouldIncludeSkipHeaderRecordSetting() {
        // Setup: Create format with delimiter and skip header record
        CSVFormat format = CSVFormat.newFormat(',')
            .builder()
            .setSkipHeaderRecord(true)
            .get();
        
        // Execute
        String result = format.toString();
        
        // Verify
        assertEquals("Delimiter=<,> SkipHeaderRecord:true", result);
    }

    @Test
    void toString_withHeaderComments_shouldIncludeHeaderCommentsSetting() {
        // Setup: Create format with delimiter and header comments
        CSVFormat format = CSVFormat.newFormat(',')
            .builder()
            .setHeaderComments("Comment1", "Comment2")
            .get();
        
        // Execute
        String result = format.toString();
        
        // Verify
        assertEquals("Delimiter=<,> SkipHeaderRecord:false HeaderComments:[Comment1, Comment2]", result);
    }

    @Test
    void toString_withHeaders_shouldIncludeHeadersSetting() {
        // Setup: Create format with delimiter and headers
        CSVFormat format = CSVFormat.newFormat(',')
            .builder()
            .setHeader("Col1", "Col2")
            .get();
        
        // Execute
        String result = format.toString();
        
        // Verify
        assertEquals("Delimiter=<,> SkipHeaderRecord:false Header:[Col1, Col2]", result);
    }

    @Test
    void toString_withAllSettings_shouldIncludeAllEnabledSettings() {
        // Setup: Create format with all possible settings enabled
        CSVFormat format = CSVFormat.newFormat(',')
            .builder()
            .setEscape('\\')
            .setQuote('"')
            .setQuoteMode(QuoteMode.ALL)
            .setCommentMarker('#')
            .setNullString("NULL")
            .setRecordSeparator("\r\n")
            .setIgnoreEmptyLines(true)
            .setIgnoreSurroundingSpaces(true)
            .setIgnoreHeaderCase(true)
            .setSkipHeaderRecord(true)
            .setHeaderComments("Comment1", "Comment2")
            .setHeader("Col1", "Col2")
            .get();
        
        // Execute
        String result = format.toString();
        
        // Verify
        assertEquals("Delimiter=<,> Escape=<\\> QuoteChar=<\"> QuoteMode=<ALL> " +
                     "CommentStart=<#> NullString=<NULL> RecordSeparator=<\r\n> " +
                     "EmptyLines:ignored SurroundingSpaces:ignored IgnoreHeaderCase:ignored " +
                     "SkipHeaderRecord:true HeaderComments:[Comment1, Comment2] Header:[Col1, Col2]", 
                     result);
    }

    // @Test
    // void toString_withNullValues_shouldHandleNullsGracefully() {
    //     // Setup: Create format with some null values
    //     CSVFormat format = CSVFormat.newFormat(',')
    //         .builder()
    //         .setQuote(null)  // explicitly set to null
    //         .setRecordSeparator(null)  // explicitly set to null
    //         .setHeaderComments(null)  // explicitly set to null
    //         .setHeader(null)  // explicitly set to null
    //         .get();
        
    //     // Execute
    //     String result = format.toString();
        
    //     // Verify - null values should be omitted from output
    //     assertEquals("Delimiter=<,> SkipHeaderRecord:false", result);
    // }

    @ParameterizedTest
    @MethodSource("predefinedFormatsProvider")
    void toString_withPredefinedFormats_shouldReturnExpectedFormat(CSVFormat format, String expected) {
        // Execute
        String result = format.toString();
        
        // Verify
        assertEquals(expected, result);
    }

    private static Stream<Arguments> predefinedFormatsProvider() {
        return Stream.of(
            Arguments.of(CSVFormat.DEFAULT, 
                "Delimiter=<,> QuoteChar=<\"> RecordSeparator=<\r\n> EmptyLines:ignored SkipHeaderRecord:false"),
            Arguments.of(CSVFormat.EXCEL, 
                "Delimiter=<,> QuoteChar=<\"> RecordSeparator=<\r\n> SkipHeaderRecord:false"),
            Arguments.of(CSVFormat.RFC4180, 
                "Delimiter=<,> QuoteChar=<\"> RecordSeparator=<\r\n> SkipHeaderRecord:false"),
            Arguments.of(CSVFormat.TDF, 
                "Delimiter=<	> QuoteChar=<\"> RecordSeparator=<\r\n> EmptyLines:ignored SurroundingSpaces:ignored SkipHeaderRecord:false")
        );
    }
}