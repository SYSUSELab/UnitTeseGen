package org.apache.commons.csv;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.*;
import static org.mockito.Mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import java.io.IOException;

@ExtendWith(MockitoExtension.class)
class LexerTest {
    @Mock
    private ExtendedBufferedReader reader;
    
    @Mock
    private CSVFormat format;
    
    @Mock
    private Token token;
    
    private Lexer lexer;
    
    @BeforeAll
    static void setupBeforeAll() {
        // Initialize any static resources if needed
    }

    @BeforeEach
    void setupBeforeEach() throws IOException {
        // Setup default mock behaviors
        when(format.getDelimiterCharArray()).thenReturn(new char[]{','});
        when(format.getEscapeCharacter()).thenReturn('\\');
        when(format.getQuoteCharacter()).thenReturn('"');
        when(format.getCommentMarker()).thenReturn('#');
        when(format.getIgnoreSurroundingSpaces()).thenReturn(false);
        when(format.getIgnoreEmptyLines()).thenReturn(false);
        when(format.getLenientEof()).thenReturn(false);
        when(format.getTrailingData()).thenReturn(false);
        
        // Initialize lexer with mocked dependencies
        lexer = new Lexer(format, reader);
        
        // Setup common token behaviors
        when(token.content).thenReturn(new StringBuilder());
        when(token.isQuoted).thenReturn(false);
    }

    @AfterEach
    void teardownAfterEach() throws IOException {
        // Verify no more interactions with mocks if needed
        Mockito.validateMockitoUsage();
        
        // Clean up lexer if needed
        if (lexer != null) {
            lexer.close();
        }
    }

    @AfterAll
    static void teardownAfterAll() {
        // Clean up any static resources if needed
    }

    @Test
    @DisplayName("Should handle double quote character by adding single quote to token")
    void parseEncapsulatedToken_WhenDoubleQuote_ShouldAddSingleQuote() throws IOException {
        // Arrange
        when(reader.read()).thenReturn((int) '"');
        when(reader.peek()).thenReturn((int) '"');
        when(token.content).thenReturn(new StringBuilder());
        
        // Act
        Token result = lexer.parseEncapsulatedToken(token);
        
        // Assert
        verify(reader, times(2)).read(); // reads both quotes
        verify(token.content).append('"');
        assertTrue(result.isQuoted);
    }

    @Test
    @DisplayName("Should return TOKEN type when delimiter is found after quote")
    void parseEncapsulatedToken_WhenDelimiterAfterQuote_ShouldReturnToken() throws IOException {
        // Arrange
        when(reader.read())
            .thenReturn((int) '"') // first read - quote
            .thenReturn((int) ','); // second read - delimiter
        when(isDelimiter(',')).thenReturn(true);
        
        // Act
        Token result = lexer.parseEncapsulatedToken(token);
        
        // Assert
        assertEquals(Token.Type.TOKEN, result.type);
        assertTrue(result.isQuoted);
    }

    @Test
    @DisplayName("Should return EOF type when EOF is found after quote")
    void parseEncapsulatedToken_WhenEOFAfterQuote_ShouldReturnEOF() throws IOException {
        // Arrange
        when(reader.read())
            .thenReturn((int) '"') // first read - quote
            .thenReturn(IOUtils.EOF); // second read - EOF
        when(lexer.isEndOfFile(IOUtils.EOF)).thenReturn(true);
        
        // Act
        Token result = lexer.parseEncapsulatedToken(token);
        
        // Assert
        assertEquals(Token.Type.EOF, result.type);
        assertTrue(result.isReady);
        assertTrue(result.isQuoted);
    }

    @Test
    @DisplayName("Should return EORECORD type when EOL is found after quote")
    void parseEncapsulatedToken_WhenEOLAfterQuote_ShouldReturnEORECORD() throws IOException {
        // Arrange
        when(reader.read())
            .thenReturn((int) '"') // first read - quote
            .thenReturn((int) '\n'); // second read - EOL
        when(lexer.readEndOfLine('\n')).thenReturn(true);
        
        // Act
        Token result = lexer.parseEncapsulatedToken(token);
        
        // Assert
        assertEquals(Token.Type.EORECORD, result.type);
        assertTrue(result.isQuoted);
    }

    @Test
    @DisplayName("Should throw CSVException when invalid char is found between token and delimiter")
    void parseEncapsulatedToken_WhenInvalidCharAfterQuote_ShouldThrowException() throws IOException {
        // Arrange
        when(reader.read())
            .thenReturn((int) '"') // first read - quote
            .thenReturn((int) 'x'); // second read - invalid char
        when(lexer.getCurrentLineNumber()).thenReturn(1L);
        when(lexer.getCharacterPosition()).thenReturn(1L);
        
        // Act & Assert
        CSVException exception = assertThrows(CSVException.class, () -> {
            lexer.parseEncapsulatedToken(token);
        });
        assertTrue(exception.getMessage().contains("Invalid character between encapsulated token and delimiter"));
    }

    @Test
    @DisplayName("Should handle escape character by appending escaped character")
    void parseEncapsulatedToken_WhenEscapeChar_ShouldAppendEscapedCharacter() throws IOException {
        // Arrange
        when(reader.read())
            .thenReturn((int) '\\') // escape char
            .thenReturn((int) '"'); // quote to end token
        when(lexer.isEscape('\\')).thenReturn(true);
        when(lexer.isQuoteChar('"')).thenReturn(true);
        
        // Act
        Token result = lexer.parseEncapsulatedToken(token);
        
        // Assert
        verify(lexer).appendNextEscapedCharacterToToken(token);
        assertTrue(result.isQuoted);
    }

    @Test
    @DisplayName("Should throw CSVException when EOF is reached before token finishes (strict mode)")
    void parseEncapsulatedToken_WhenPrematureEOF_ShouldThrowException() throws IOException {
        // Arrange
        when(reader.read()).thenReturn(IOUtils.EOF);
        when(lexer.isEndOfFile(IOUtils.EOF)).thenReturn(true);
        when(lexer.getCurrentLineNumber()).thenReturn(1L);
        
        // Act & Assert
        CSVException exception = assertThrows(CSVException.class, () -> {
            lexer.parseEncapsulatedToken(token);
        });
        assertTrue(exception.getMessage().contains("EOF reached before encapsulated token finished"));
    }

    @Test
    @DisplayName("Should return EOF type when EOF is reached in lenient mode")
    void parseEncapsulatedToken_WhenPrematureEOFInLenientMode_ShouldReturnEOF() throws IOException {
        // Arrange
        when(format.getLenientEof()).thenReturn(true);
        lexer = new Lexer(format, reader); // Recreate lexer with lenient mode
        when(reader.read()).thenReturn(IOUtils.EOF);
        when(lexer.isEndOfFile(IOUtils.EOF)).thenReturn(true);
        
        // Act
        Token result = lexer.parseEncapsulatedToken(token);
        
        // Assert
        assertEquals(Token.Type.EOF, result.type);
        assertTrue(result.isReady);
        assertTrue(result.isQuoted);
    }

    @Test
    @DisplayName("Should append regular character to token content")
    void parseEncapsulatedToken_WhenRegularChar_ShouldAppendToToken() throws IOException {
        // Arrange
        when(reader.read())
            .thenReturn((int) 'a') // regular char
            .thenReturn((int) '"'); // quote to end token
        when(lexer.isQuoteChar('"')).thenReturn(true);
        
        // Act
        Token result = lexer.parseEncapsulatedToken(token);
        
        // Assert
        verify(token.content).append('a');
        assertTrue(result.isQuoted);
    }

    @Test
    @DisplayName("Should append trailing data when configured")
    void parseEncapsulatedToken_WhenTrailingDataEnabled_ShouldAppendChars() throws IOException {
        // Arrange
        when(format.getTrailingData()).thenReturn(true);
        lexer = new Lexer(format, reader); // Recreate lexer with trailing data enabled
        when(reader.read())
            .thenReturn((int) '"') // quote
            .thenReturn((int) 'x') // invalid char (would normally throw exception)
            .thenReturn((int) ','); // delimiter
        when(lexer.isDelimiter(',')).thenReturn(true);
        
        // Act
        Token result = lexer.parseEncapsulatedToken(token);
        
        // Assert
        verify(token.content).append('x');
        assertEquals(Token.Type.TOKEN, result.type);
        assertTrue(result.isQuoted);
    }
}