package org.apache.commons.collections4.sequence;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.*;
import static org.mockito.Mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import java.util.List;
import org.apache.commons.collections4.Equator;

@ExtendWith(MockitoExtension.class)
class SequencesComparatorTest {
    private SequencesComparator<String> sequencesComparator;
    private List<String> sequence1;
    private List<String> sequence2;
    @Mock
    private Equator<String> mockEquator;

    @BeforeAll
    static void setupBeforeAll() {
        // No static setup needed for this test class
    }

    @BeforeEach
    void setupBeforeEach() {
        sequence1 = Mockito.mock(List.class);
        sequence2 = Mockito.mock(List.class);
        
        // Initialize with default constructor
        sequencesComparator = new SequencesComparator<>(sequence1, sequence2);
        
        // Alternatively, could initialize with mock equator:
        // sequencesComparator = new SequencesComparator<>(sequence1, sequence2, mockEquator);
    }

    @AfterEach
    void teardownAfterEach() {
        sequencesComparator = null;
        sequence1 = null;
        sequence2 = null;
        Mockito.reset(mockEquator);
    }

    @AfterAll
    static void teardownAfterAll() {
        // No static cleanup needed for this test class
    }
}