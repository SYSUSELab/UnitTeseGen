package org.apache.commons.collections4.map;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.*;
import static org.mockito.Mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import java.util.HashMap;
import java.util.Map;

@ExtendWith(MockitoExtension.class)
class Flat3Map_1_Test {
    private Flat3Map<String, Integer> flat3Map;
    private Map<String, Integer> sampleMap;
    
    @BeforeAll
    static void setupBeforeAll() {
        // No static setup needed for this test
    }

    @BeforeEach
    void setupBeforeEach() {
        // Initialize a fresh Flat3Map instance before each test
        flat3Map = new Flat3Map<>();
        
        // Create a sample map that can be used for testing
        sampleMap = new HashMap<>();
        sampleMap.put("one", 1);
        sampleMap.put("two", 2);
        sampleMap.put("three", 3);
    }

    @AfterEach
    void teardownAfterEach() {
        // Clear the map to ensure no state leaks between tests
        if (flat3Map != null) {
            flat3Map.clear();
        }
        
        // Reset the sample map
        if (sampleMap != null) {
            sampleMap.clear();
        }
    }

    @AfterAll
    static void teardownAfterAll() {
        // No static cleanup needed for this test
    }
}