You are a professional Java software testing expert. I need you to help me generate high-quality unit test code for a focused method.

I will provide you with:
1. The focused method needs testing
2. Basic information of target class to which the focus method belongs
3. The existing test class structure
4. The context information for generate tests

Please generate unit test code that meets these requirements:

1. Test Coverage Requirements: 
    - Generate test cases to cover all condition branches in the target method
    - Test boundary conditions and edge cases.
2. Code Quality Requirements: 
    - Follow testing best practices and patterns
    - Use clear and descriptive test method names
    - Add detailed comments explaining test scenarios
    - Make the test code easy to understand and maintain.
3. Test Structure:
    - Follow the existing test class, and appropriate test frameworks and assertions
    - Properly set up test fixtures and dependencies
    - Clean up resources after tests
    - Divide test cases into different functions logically
4. Additional Guidelines:
- Mock external dependencies when needed
- Include error/exception test cases
- Validate both expected outputs 

@input{focused method}
```Java
public boolean containsValue(final Object value){
    if (delegateMap != null) {
        return delegateMap.containsValue(value);
    }
    if (value == null) {
        // drop through
        switch(size) {
            case 3:
                if (value3 == null) {
                    return true;
                }
            case 2:
                if (value2 == null) {
                    return true;
                }
            case 1:
                if (value1 == null) {
                    return true;
                }
        }
    } else {
        switch(// drop through
        size) {
            case 3:
                if (value.equals(value3)) {
                    return true;
                }
            case 2:
                if (value.equals(value2)) {
                    return true;
                }
            case 1:
                if (value.equals(value1)) {
                    return true;
                }
        }
    }
    return false;
}
```

@input{target class}
```Java
package org.apache.commons.collections4.map;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.AbstractCollection;
import java.util.AbstractSet;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.Set;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.IterableMap;
import org.apache.commons.collections4.MapIterator;
import org.apache.commons.collections4.ResettableIterator;
import org.apache.commons.collections4.iterators.EmptyIterator;
import org.apache.commons.collections4.iterators.EmptyMapIterator;

public class Flat3Map<K, V> implements IterableMap<K, V>, Serializable, Cloneable {
    private static final long serialVersionUID = -6701087419741928296L;
    private transient int size;
    private transient int hash1;
    private transient int hash2;
    private transient int hash3;
    private transient K key1;
    private transient K key2;
    private transient K key3;
    private transient V value1;
    private transient V value2;
    private transient V value3;
    private transient AbstractHashedMap<K, V> delegateMap;
    public Flat3Map();
    public Flat3Map(final Map<? extends K, ? extends V> map);
    public void clear();
    public Flat3Map<K, V> clone();
    public boolean containsKey(Object);
    public boolean containsValue(Object);
    private void convertToMap();
    protected AbstractHashedMap<K, V> createDelegateMap();
    public Set<Map.Entry<K, V>> entrySet();
    public boolean equals(Object);
    public V get(Object);
    public int hashCode();
    public boolean isEmpty();
    public Set<K> keySet();
    public MapIterator<K, V> mapIterator();
    public V put(K, V);
    public void putAll(Map<? extends K, ? extends V>);
    private void readObject(ObjectInputStream) throws IOException, ClassNotFoundException;
    public V remove(Object);
    public int size();
    public String toString();
    public Collection<V> values();
    private void writeObject(ObjectOutputStream) throws IOException
}
```
@input{existing test class}
```Java
<initial_class>
```


@input{context information}

api document of class org.apache.commons.collections4.map.Flat3Map: 

 * A {@code Map} implementation that stores data in simple fields until
 * the size is greater than 3.
 * <p>
 * This map is designed for performance and can outstrip HashMap.
 * It also has good garbage collection characteristics.
 * </p>
 * <ul>
 * <li>Optimised for operation at size 3 or less.
 * <li>Still works well once size 3 exceeded.
 * <li>Gets at size 3 or less are about 0-10% faster than HashMap,
 * <li>Puts at size 3 or less are over 4 times faster than HashMap.
 * <li>Performance 5% slower than HashMap once size 3 exceeded once.
 * </ul>
 * <p>
 * The design uses two distinct modes of operation - flat and delegate.
 * While the map is size 3 or less, operations map straight onto fields using
 * switch statements. Once size 4 is reached, the map switches to delegate mode
 * and only switches back when cleared. In delegate mode, all operations are
 * forwarded straight to a HashMap resulting in the 5% performance loss.
 * </p>
 * <p>
 * The performance gains on puts are due to not needing to create a Map Entry
 * object. This is a large saving not only in performance but in garbage collection.
 * </p>
 * <p>
 * Whilst in flat mode this map is also easy for the garbage collector to dispatch.
 * This is because it contains no complex objects or arrays which slow the progress.
 * </p>
 * <p>
 * Do not use {@code Flat3Map} if the size is likely to grow beyond 3.
 * </p>
 * <p>
 * <strong>Note that Flat3Map is not synchronized and is not thread-safe.</strong>
 * If you wish to use this map from multiple threads concurrently, you must use
 * appropriate synchronization. The simplest approach is to wrap this map
 * using {@link java.util.Collections#synchronizedMap(Map)}. This class may throw
 * exceptions when accessed by concurrent threads without synchronization.
 * </p>
 *
 * @param <K> the type of the keys in this map
 * @param <V> the type of the values in this map
 * @since 3.0
 

api document of method containsValue(Object): 

     * Checks whether the map contains the specified value.
     *
     * @param value  the value to search for
     * @return true if the map contains the key
     

parameters: 
java.lang.Object value

calling methods: 
method: java.lang.Object.equals(java.lang.Object), return: boolean
method: org.apache.commons.collections4.map.AbstractHashedMap.containsValue(java.lang.Object), return: boolean


@output{test class}: complete by you