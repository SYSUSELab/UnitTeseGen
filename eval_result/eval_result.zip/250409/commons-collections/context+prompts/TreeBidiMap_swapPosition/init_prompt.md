You are a professional Java developer. I will provide you with a Java class with its context and a test class template. Your task is to generate a test class framework for this class based on the template. You don't need to generate test cases, just complete the functions in the template.

Please analyze the following information and help me complete the test class template:

1. The target class and its constructor parameters
2. Field declarations and their types
3. Dependencies and external resources used by the class

Requirements:
1. Complete the setupBeforeAll(), setupBeforeEach(), teardownAfterEach(), and teardownAfterAll() methods
2. Initialize necessary fields and dependencies
3. Handle any required cleanup
4. Ensure the generated code has no syntax errors

Please provide the completed test class template with proper field declarations and setup/teardown methods.

@input{focused method}
```java
private void swapPosition(final Node<K, V> x, final Node<K, V> y, final DataElement dataElement){
    // Save initial values.
    final Node<K, V> xFormerParent = x.getParent(dataElement);
    final Node<K, V> xFormerLeftChild = x.getLeft(dataElement);
    final Node<K, V> xFormerRightChild = x.getRight(dataElement);
    final Node<K, V> yFormerParent = y.getParent(dataElement);
    final Node<K, V> yFormerLeftChild = y.getLeft(dataElement);
    final Node<K, V> yFormerRightChild = y.getRight(dataElement);
    final boolean xWasLeftChild = x.getParent(dataElement) != null && x == x.getParent(dataElement).getLeft(dataElement);
    final boolean yWasLeftChild = y.getParent(dataElement) != null && y == y.getParent(dataElement).getLeft(dataElement);
    // Swap, handling special cases of one being the other's parent.
    if (x == yFormerParent) {
        // x was y's parent
        x.setParent(y, dataElement);
        if (yWasLeftChild) {
            y.setLeft(x, dataElement);
            y.setRight(xFormerRightChild, dataElement);
        } else {
            y.setRight(x, dataElement);
            y.setLeft(xFormerLeftChild, dataElement);
        }
    } else {
        x.setParent(yFormerParent, dataElement);
        if (yFormerParent != null) {
            if (yWasLeftChild) {
                yFormerParent.setLeft(x, dataElement);
            } else {
                yFormerParent.setRight(x, dataElement);
            }
        }
        y.setLeft(xFormerLeftChild, dataElement);
        y.setRight(xFormerRightChild, dataElement);
    }
    if (y == xFormerParent) {
        // y was x's parent
        y.setParent(x, dataElement);
        if (xWasLeftChild) {
            x.setLeft(y, dataElement);
            x.setRight(yFormerRightChild, dataElement);
        } else {
            x.setRight(y, dataElement);
            x.setLeft(yFormerLeftChild, dataElement);
        }
    } else {
        y.setParent(xFormerParent, dataElement);
        if (xFormerParent != null) {
            if (xWasLeftChild) {
                xFormerParent.setLeft(y, dataElement);
            } else {
                xFormerParent.setRight(y, dataElement);
            }
        }
        x.setLeft(yFormerLeftChild, dataElement);
        x.setRight(yFormerRightChild, dataElement);
    }
    // Fix children's parent pointers
    if (x.getLeft(dataElement) != null) {
        x.getLeft(dataElement).setParent(x, dataElement);
    }
    if (x.getRight(dataElement) != null) {
        x.getRight(dataElement).setParent(x, dataElement);
    }
    if (y.getLeft(dataElement) != null) {
        y.getLeft(dataElement).setParent(y, dataElement);
    }
    if (y.getRight(dataElement) != null) {
        y.getRight(dataElement).setParent(y, dataElement);
    }
    x.swapColors(y, dataElement);
    // Check if root changed
    if (rootNode[dataElement.ordinal()] == x) {
        rootNode[dataElement.ordinal()] = y;
    } else if (rootNode[dataElement.ordinal()] == y) {
        rootNode[dataElement.ordinal()] = x;
    }
}
```

@input{target class}
```java
package org.apache.commons.collections4.bidimap;

import static org.apache.commons.collections4.bidimap.TreeBidiMap.DataElement.KEY;
import static org.apache.commons.collections4.bidimap.TreeBidiMap.DataElement.VALUE;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.AbstractSet;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.Set;
import org.apache.commons.collections4.KeyValue;
import org.apache.commons.collections4.MapIterator;
import org.apache.commons.collections4.OrderedBidiMap;
import org.apache.commons.collections4.OrderedIterator;
import org.apache.commons.collections4.OrderedMapIterator;
import org.apache.commons.collections4.iterators.EmptyOrderedMapIterator;
import org.apache.commons.collections4.keyvalue.UnmodifiableMapEntry;

public class TreeBidiMap<K extends Comparable<K>, V extends Comparable<V>> implements OrderedBidiMap<K, V>, Serializable {
    private static final long serialVersionUID = 721969328361807L;
    private transient Node<K, V>[] rootNode;
    private transient int nodeCount;
    private transient int modifications;
    private transient Set<K> keySet;
    private transient Set<V> valuesSet;
    private transient Set<Map.Entry<K, V>> entrySet;
    private transient Inverse inverse;
    public TreeBidiMap();
    public TreeBidiMap(final Map<? extends K, ? extends V> map);
    private static void checkKey(Object);
    private static void checkKeyAndValue(Object, Object);
    private static void checkNonNullComparable(Object, DataElement);
    private static void checkValue(Object);
    private static int compare(T, T);
    private static boolean isBlack(Node<?, ?>, DataElement);
    private static boolean isRed(Node<?, ?>, DataElement);
    private static void makeBlack(Node<?, ?>, DataElement);
    private static void makeRed(Node<?, ?>, DataElement);
    public void clear();
    public boolean containsKey(Object);
    public boolean containsValue(Object);
    private void copyColor(Node<K, V>, Node<K, V>, DataElement);
    private boolean doEquals(Object, DataElement);
    private int doHashCode(DataElement);
    private void doPut(K, V);
    private void doRedBlackDelete(Node<K, V>);
    private void doRedBlackDeleteFixup(Node<K, V>, DataElement);
    private void doRedBlackInsert(Node<K, V>, DataElement);
    private V doRemoveKey(Object);
    private K doRemoveValue(Object);
    private String doToString(DataElement);
    public Set<Map.Entry<K, V>> entrySet();
    public boolean equals(Object);
    public K firstKey();
    public V get(Object);
    private Node<K, V> getGrandParent(Node<K, V>, DataElement);
    public K getKey(Object);
    private Node<K, V> getLeftChild(Node<K, V>, DataElement);
    private MapIterator<?, ?> getMapIterator(DataElement);
    private Node<K, V> getParent(Node<K, V>, DataElement);
    private Node<K, V> getRightChild(Node<K, V>, DataElement);
    private Node<K, V> greatestNode(Node<K, V>, DataElement);
    private void grow();
    public int hashCode();
    private void insertValue(Node<K, V>) throws IllegalArgumentException;
    public OrderedBidiMap<V, K> inverseBidiMap();
    public boolean isEmpty();
    public Set<K> keySet();
    public K lastKey();
    private Node<K, V> leastNode(Node<K, V>, DataElement);
    private Node<K, V> lookup(Object, DataElement);
    private Node<K, V> lookupKey(Object);
    private Node<K, V> lookupValue(Object);
    public OrderedMapIterator<K, V> mapIterator();
    private void modify();
    private Node<K, V> nextGreater(Node<K, V>, DataElement);
    public K nextKey(K);
    private Node<K, V> nextSmaller(Node<K, V>, DataElement);
    public K previousKey(K);
    public V put(K, V);
    public void putAll(Map<? extends K, ? extends V>);
    private void readObject(ObjectInputStream) throws IOException, ClassNotFoundException;
    public V remove(Object);
    public K removeValue(Object);
    private void rotateLeft(Node<K, V>, DataElement);
    private void rotateRight(Node<K, V>, DataElement);
    private void shrink();
    public int size();
    private void swapPosition(Node<K, V>, Node<K, V>, DataElement);
    public String toString();
    public Set<V> values();
    private void writeObject(ObjectOutputStream) throws IOException
}
```

@input{context information}

constructors for class `org.apache.commons.collections4.bidimap.TreeBidiMap`: 
```java
params: 
body:
```java
public TreeBidiMap()
{
    rootNode = new Node[2];
}
```params: java.util.Map<? extends K, ? extends V> map
body:
```java
public TreeBidiMap(final Map<? extends K, ? extends V> map)
{
    this();
    putAll(map);
}
```
```

api document of class org.apache.commons.collections4.bidimap.TreeBidiMap: 

 * Red-Black tree-based implementation of BidiMap where all objects added
 * implement the {@code Comparable} interface.
 * <p>
 * This class guarantees that the map will be in both ascending key order
 * and ascending value order, sorted according to the natural order for
 * the key's and value's classes.
 * </p>
 * <p>
 * This Map is intended for applications that need to be able to look
 * up a key-value pairing by either key or value, and need to do so
 * with equal efficiency.
 * </p>
 * <p>
 * While that goal could be accomplished by taking a pair of TreeMaps
 * and redirecting requests to the appropriate TreeMap (e.g.,
 * containsKey would be directed to the TreeMap that maps values to
 * keys, containsValue would be directed to the TreeMap that maps keys
 * to values), there are problems with that implementation.
 * If the data contained in the TreeMaps is large, the cost of redundant
 * storage becomes significant. The {@link DualTreeBidiMap} and
 * {@link DualHashBidiMap} implementations use this approach.
 * </p>
 * <p>
 * This solution keeps minimizes the data storage by holding data only once.
 * The red-black algorithm is based on {@link java.util.TreeMap}, but has been modified
 * to simultaneously map a tree node by key and by value. This doubles the
 * cost of put operations (but so does using two TreeMaps), and nearly doubles
 * the cost of remove operations (there is a savings in that the lookup of the
 * node to be removed only has to be performed once). And since only one node
 * contains the key and value, storage is significantly less than that
 * required by two TreeMaps.
 * </p>
 * <p>
 * The Map.Entry instances returned by the appropriate methods will
 * not allow setValue() and will throw an
 * UnsupportedOperationException on attempts to call that method.
 * </p>
 *
 * @param <K> the type of the keys in this map
 * @param <V> the type of the values in this map
 *
 * @since 3.0 (previously DoubleOrderedMap v2.0)
 


@input{test class template}
```java
package org.apache.commons.collections4.bidimap;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.*;
import static org.mockito.Mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
// Add other imports if necessary

@ExtendWith(MockitoExtension.class)
class TreeBidiMap_1_Test {
    @BeforeAll
    static void setupBeforeAll() {
    }

    @BeforeEach
    void setupBeforeEach() {
    }

    @AfterEach
    void teardownAfterEach() {
    }

    @AfterAll
    static void teardownAfterAll() {
    }
}
```

@output{initial test class}: completed by you