You are a professional Java developer. I will provide you with a Java class with its context and a test class template. Your task is to generate a test class framework for this class based on the template. You don't need to generate test cases, just complete the functions in the template.

Please analyze the following information and help me complete the test class template:

1. The target class and its constructor parameters
2. Field declarations and their types
3. Dependencies and external resources used by the class

Requirements:
1. Complete the setupBeforeAll(), setupBeforeEach(), teardownAfterEach(), and teardownAfterAll() methods
2. Initialize necessary fields and dependencies
3. Handle any required cleanup
4. Ensure the generated code has no syntax errors

Please provide the completed test class template with proper field declarations and setup/teardown methods.

@input{focused method}
```java
public static Iterator<?> getIterator(final Object obj){
    if (obj == null) {
        return emptyIterator();
    }
    if (obj instanceof Iterator) {
        return (Iterator<?>) obj;
    }
    if (obj instanceof Iterable) {
        return ((Iterable<?>) obj).iterator();
    }
    if (obj instanceof Object[]) {
        return new ObjectArrayIterator<>((Object[]) obj);
    }
    if (obj instanceof Enumeration) {
        return new EnumerationIterator<>((Enumeration<?>) obj);
    }
    if (obj instanceof Map) {
        return ((Map<?, ?>) obj).values().iterator();
    }
    if (obj instanceof NodeList) {
        return new NodeListIterator((NodeList) obj);
    }
    if (obj instanceof Node) {
        return new NodeListIterator((Node) obj);
    }
    if (obj instanceof Dictionary) {
        return new EnumerationIterator<>(((Dictionary<?, ?>) obj).elements());
    }
    if (obj.getClass().isArray()) {
        return new ArrayIterator<>(obj);
    }
    try {
        final Method method = obj.getClass().getMethod("iterator", (Class[]) null);
        if (Iterator.class.isAssignableFrom(method.getReturnType())) {
            final Iterator<?> it = (Iterator<?>) method.invoke(obj, (Object[]) null);
            if (it != null) {
                return it;
            }
        }
    } catch (final RuntimeException | ReflectiveOperationException ignore) {
        // NOPMD
        // ignore
    }
    return singletonIterator(obj);
}
```

@input{target class}
```java
package org.apache.commons.collections4;

import java.lang.reflect.Array;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Dictionary;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Objects;
import org.apache.commons.collections4.functors.EqualPredicate;
import org.apache.commons.collections4.iterators.ArrayIterator;
import org.apache.commons.collections4.iterators.ArrayListIterator;
import org.apache.commons.collections4.iterators.BoundedIterator;
import org.apache.commons.collections4.iterators.CollatingIterator;
import org.apache.commons.collections4.iterators.EmptyIterator;
import org.apache.commons.collections4.iterators.EmptyListIterator;
import org.apache.commons.collections4.iterators.EmptyMapIterator;
import org.apache.commons.collections4.iterators.EmptyOrderedIterator;
import org.apache.commons.collections4.iterators.EmptyOrderedMapIterator;
import org.apache.commons.collections4.iterators.EnumerationIterator;
import org.apache.commons.collections4.iterators.FilterIterator;
import org.apache.commons.collections4.iterators.FilterListIterator;
import org.apache.commons.collections4.iterators.IteratorChain;
import org.apache.commons.collections4.iterators.IteratorEnumeration;
import org.apache.commons.collections4.iterators.IteratorIterable;
import org.apache.commons.collections4.iterators.ListIteratorWrapper;
import org.apache.commons.collections4.iterators.LoopingIterator;
import org.apache.commons.collections4.iterators.LoopingListIterator;
import org.apache.commons.collections4.iterators.NodeListIterator;
import org.apache.commons.collections4.iterators.ObjectArrayIterator;
import org.apache.commons.collections4.iterators.ObjectArrayListIterator;
import org.apache.commons.collections4.iterators.ObjectGraphIterator;
import org.apache.commons.collections4.iterators.PeekingIterator;
import org.apache.commons.collections4.iterators.PushbackIterator;
import org.apache.commons.collections4.iterators.SingletonIterator;
import org.apache.commons.collections4.iterators.SingletonListIterator;
import org.apache.commons.collections4.iterators.SkippingIterator;
import org.apache.commons.collections4.iterators.TransformIterator;
import org.apache.commons.collections4.iterators.UnmodifiableIterator;
import org.apache.commons.collections4.iterators.UnmodifiableListIterator;
import org.apache.commons.collections4.iterators.UnmodifiableMapIterator;
import org.apache.commons.collections4.iterators.ZippingIterator;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class IteratorUtils {
    // validation is done in this class in certain cases because the
// public classes allow invalid states
@SuppressWarnings("rawtypes")
public static final ResettableIterator EMPTY_ITERATOR = EmptyIterator.RESETTABLE_INSTANCE;
    @SuppressWarnings("rawtypes")
public static final ResettableListIterator EMPTY_LIST_ITERATOR = EmptyListIterator.RESETTABLE_INSTANCE;
    @SuppressWarnings("rawtypes")
public static final OrderedIterator EMPTY_ORDERED_ITERATOR = EmptyOrderedIterator.INSTANCE;
    @SuppressWarnings("rawtypes")
public static final MapIterator EMPTY_MAP_ITERATOR = EmptyMapIterator.INSTANCE;
    @SuppressWarnings("rawtypes")
public static final OrderedMapIterator EMPTY_ORDERED_MAP_ITERATOR = EmptyOrderedMapIterator.INSTANCE;
    private static final String DEFAULT_TOSTRING_DELIMITER = ", ";
    private IteratorUtils();
    public static ResettableIterator<E> arrayIterator(E...);
    public static ResettableIterator<E> arrayIterator(E[], int);
    public static ResettableIterator<E> arrayIterator(E[], int, int);
    public static ResettableIterator<E> arrayIterator(Object);
    public static ResettableIterator<E> arrayIterator(Object, int);
    public static ResettableIterator<E> arrayIterator(Object, int, int);
    public static ResettableListIterator<E> arrayListIterator(E...);
    public static ResettableListIterator<E> arrayListIterator(E[], int);
    public static ResettableListIterator<E> arrayListIterator(E[], int, int);
    public static ResettableListIterator<E> arrayListIterator(Object);
    public static ResettableListIterator<E> arrayListIterator(Object, int);
    public static ResettableListIterator<E> arrayListIterator(Object, int, int);
    public static Enumeration<E> asEnumeration(Iterator<? extends E>);
    public static Iterable<E> asIterable(Iterator<? extends E>);
    public static Iterator<E> asIterator(Enumeration<? extends E>);
    public static Iterator<E> asIterator(Enumeration<? extends E>, Collection<? super E>);
    public static Iterable<E> asMultipleUseIterable(Iterator<? extends E>);
    public static BoundedIterator<E> boundedIterator(Iterator<? extends E>, long);
    public static BoundedIterator<E> boundedIterator(Iterator<? extends E>, long, long);
    public static Iterator<E> chainedIterator(Collection<Iterator<? extends E>>);
    public static Iterator<E> chainedIterator(Iterator<? extends E>...);
    public static Iterator<E> chainedIterator(Iterator<? extends E>, Iterator<? extends E>);
    public static Iterator<E> collatedIterator(Comparator<? super E>, Collection<Iterator<? extends E>>);
    public static Iterator<E> collatedIterator(Comparator<? super E>, Iterator<? extends E>...);
    public static Iterator<E> collatedIterator(Comparator<? super E>, Iterator<? extends E>, Iterator<? extends E>);
    public static boolean contains(Iterator<E>, Object);
    public static ResettableIterator<E> emptyIterator();
    public static ResettableListIterator<E> emptyListIterator();
    public static MapIterator<K, V> emptyMapIterator();
    public static OrderedIterator<E> emptyOrderedIterator();
    public static OrderedMapIterator<K, V> emptyOrderedMapIterator();
    public static Iterator<E> filteredIterator(Iterator<? extends E>, Predicate<? super E>);
    public static ListIterator<E> filteredListIterator(ListIterator<? extends E>, Predicate<? super E>);
    public static E find(Iterator<E>, Predicate<? super E>);
    public static E first(Iterator<E>);
    public static void forEach(Iterator<E>, Closure<? super E>);
    public static E forEachButLast(Iterator<E>, Closure<? super E>);
    public static E get(Iterator<E>, int);
    public static Iterator<?> getIterator(Object);
    public static int indexOf(Iterator<E>, Predicate<? super E>);
    public static boolean isEmpty(Iterator<?>);
    public static ResettableIterator<E> loopingIterator(Collection<? extends E>);
    public static ResettableListIterator<E> loopingListIterator(List<E>);
    public static boolean matchesAll(Iterator<E>, Predicate<? super E>);
    public static boolean matchesAny(Iterator<E>, Predicate<? super E>);
    public static NodeListIterator nodeListIterator(Node);
    public static NodeListIterator nodeListIterator(NodeList);
    public static Iterator<E> objectGraphIterator(E, Transformer<? super E, ? extends E>);
    public static Iterator<E> peekingIterator(Iterator<? extends E>);
    public static Iterator<E> pushbackIterator(Iterator<? extends E>);
    public static ResettableIterator<E> singletonIterator(E);
    public static ListIterator<E> singletonListIterator(E);
    public static int size(Iterator<?>);
    public static SkippingIterator<E> skippingIterator(Iterator<E>, long);
    public static Object[] toArray(Iterator<?>);
    public static E[] toArray(Iterator<? extends E>, Class<E>);
    public static List<E> toList(Iterator<? extends E>);
    public static List<E> toList(Iterator<? extends E>, int);
    public static ListIterator<E> toListIterator(Iterator<? extends E>);
    public static String toString(Iterator<E>);
    public static String toString(Iterator<E>, Transformer<? super E, String>);
    public static String toString(Iterator<E>, Transformer<? super E, String>, String, String, String);
    public static Iterator<O> transformedIterator(Iterator<? extends I>, Transformer<? super I, ? extends O>);
    public static Iterator<E> unmodifiableIterator(Iterator<E>);
    public static ListIterator<E> unmodifiableListIterator(ListIterator<E>);
    public static MapIterator<K, V> unmodifiableMapIterator(MapIterator<K, V>);
    public static ZippingIterator<E> zippingIterator(Iterator<? extends E>...);
    public static ZippingIterator<E> zippingIterator(Iterator<? extends E>, Iterator<? extends E>);
    public static ZippingIterator<E> zippingIterator(Iterator<? extends E>, Iterator<? extends E>, Iterator<? extends E>)
}
```

@input{context information}

constructors for class `org.apache.commons.collections4.IteratorUtils`: 
```java
params: 
body:
```java
private IteratorUtils()
{
}
```
```

api document of class org.apache.commons.collections4.IteratorUtils: 

 * Provides static utility methods and decorators for {@link Iterator}
 * instances. The implementations are provided in the iterators subpackage.
 *
 * @since 2.1
 


@input{test class template}
```java
package org.apache.commons.collections4;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.*;
import static org.mockito.Mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
// Add other imports if necessary

@ExtendWith(MockitoExtension.class)
class IteratorUtilsTest {
    @BeforeAll
    static void setupBeforeAll() {
    }

    @BeforeEach
    void setupBeforeEach() {
    }

    @AfterEach
    void teardownAfterEach() {
    }

    @AfterAll
    static void teardownAfterAll() {
    }
}
```

@output{initial test class}: completed by you