You are a professional Java software testing expert. I need you to help me generate high-quality unit test code for a focused method.

I will provide you with:
1. The focused method needs testing
2. Basic information of target class to which the focus method belongs
3. The existing test class structure
4. The context information for generate tests

Please generate unit test code that meets these requirements:

1. Test Coverage Requirements: 
    - Generate test cases to cover all condition branches in the target method
    - Test boundary conditions and edge cases.
2. Code Quality Requirements: 
    - Follow testing best practices and patterns
    - Use clear and descriptive test method names
    - Add detailed comments explaining test scenarios
    - Make the test code easy to understand and maintain.
3. Test Structure:
    - Follow the existing test class, and appropriate test frameworks and assertions
    - Properly set up test fixtures and dependencies
    - Clean up resources after tests
    - Divide test cases into different functions logically
4. Additional Guidelines:
- Mock external dependencies when needed
- Include error/exception test cases
- Validate both expected outputs 

@input{focused method}
```Java
public static Iterator<?> getIterator(final Object obj){
    if (obj == null) {
        return emptyIterator();
    }
    if (obj instanceof Iterator) {
        return (Iterator<?>) obj;
    }
    if (obj instanceof Iterable) {
        return ((Iterable<?>) obj).iterator();
    }
    if (obj instanceof Object[]) {
        return new ObjectArrayIterator<>((Object[]) obj);
    }
    if (obj instanceof Enumeration) {
        return new EnumerationIterator<>((Enumeration<?>) obj);
    }
    if (obj instanceof Map) {
        return ((Map<?, ?>) obj).values().iterator();
    }
    if (obj instanceof NodeList) {
        return new NodeListIterator((NodeList) obj);
    }
    if (obj instanceof Node) {
        return new NodeListIterator((Node) obj);
    }
    if (obj instanceof Dictionary) {
        return new EnumerationIterator<>(((Dictionary<?, ?>) obj).elements());
    }
    if (obj.getClass().isArray()) {
        return new ArrayIterator<>(obj);
    }
    try {
        final Method method = obj.getClass().getMethod("iterator", (Class[]) null);
        if (Iterator.class.isAssignableFrom(method.getReturnType())) {
            final Iterator<?> it = (Iterator<?>) method.invoke(obj, (Object[]) null);
            if (it != null) {
                return it;
            }
        }
    } catch (final RuntimeException | ReflectiveOperationException ignore) {
        // NOPMD
        // ignore
    }
    return singletonIterator(obj);
}
```

@input{target class}
```Java
package org.apache.commons.collections4;

import java.lang.reflect.Array;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Dictionary;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Objects;
import org.apache.commons.collections4.functors.EqualPredicate;
import org.apache.commons.collections4.iterators.ArrayIterator;
import org.apache.commons.collections4.iterators.ArrayListIterator;
import org.apache.commons.collections4.iterators.BoundedIterator;
import org.apache.commons.collections4.iterators.CollatingIterator;
import org.apache.commons.collections4.iterators.EmptyIterator;
import org.apache.commons.collections4.iterators.EmptyListIterator;
import org.apache.commons.collections4.iterators.EmptyMapIterator;
import org.apache.commons.collections4.iterators.EmptyOrderedIterator;
import org.apache.commons.collections4.iterators.EmptyOrderedMapIterator;
import org.apache.commons.collections4.iterators.EnumerationIterator;
import org.apache.commons.collections4.iterators.FilterIterator;
import org.apache.commons.collections4.iterators.FilterListIterator;
import org.apache.commons.collections4.iterators.IteratorChain;
import org.apache.commons.collections4.iterators.IteratorEnumeration;
import org.apache.commons.collections4.iterators.IteratorIterable;
import org.apache.commons.collections4.iterators.ListIteratorWrapper;
import org.apache.commons.collections4.iterators.LoopingIterator;
import org.apache.commons.collections4.iterators.LoopingListIterator;
import org.apache.commons.collections4.iterators.NodeListIterator;
import org.apache.commons.collections4.iterators.ObjectArrayIterator;
import org.apache.commons.collections4.iterators.ObjectArrayListIterator;
import org.apache.commons.collections4.iterators.ObjectGraphIterator;
import org.apache.commons.collections4.iterators.PeekingIterator;
import org.apache.commons.collections4.iterators.PushbackIterator;
import org.apache.commons.collections4.iterators.SingletonIterator;
import org.apache.commons.collections4.iterators.SingletonListIterator;
import org.apache.commons.collections4.iterators.SkippingIterator;
import org.apache.commons.collections4.iterators.TransformIterator;
import org.apache.commons.collections4.iterators.UnmodifiableIterator;
import org.apache.commons.collections4.iterators.UnmodifiableListIterator;
import org.apache.commons.collections4.iterators.UnmodifiableMapIterator;
import org.apache.commons.collections4.iterators.ZippingIterator;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class IteratorUtils {
    // validation is done in this class in certain cases because the
// public classes allow invalid states
@SuppressWarnings("rawtypes")
public static final ResettableIterator EMPTY_ITERATOR = EmptyIterator.RESETTABLE_INSTANCE;
    @SuppressWarnings("rawtypes")
public static final ResettableListIterator EMPTY_LIST_ITERATOR = EmptyListIterator.RESETTABLE_INSTANCE;
    @SuppressWarnings("rawtypes")
public static final OrderedIterator EMPTY_ORDERED_ITERATOR = EmptyOrderedIterator.INSTANCE;
    @SuppressWarnings("rawtypes")
public static final MapIterator EMPTY_MAP_ITERATOR = EmptyMapIterator.INSTANCE;
    @SuppressWarnings("rawtypes")
public static final OrderedMapIterator EMPTY_ORDERED_MAP_ITERATOR = EmptyOrderedMapIterator.INSTANCE;
    private static final String DEFAULT_TOSTRING_DELIMITER = ", ";
    private IteratorUtils();
    public static ResettableIterator<E> arrayIterator(E...);
    public static ResettableIterator<E> arrayIterator(E[], int);
    public static ResettableIterator<E> arrayIterator(E[], int, int);
    public static ResettableIterator<E> arrayIterator(Object);
    public static ResettableIterator<E> arrayIterator(Object, int);
    public static ResettableIterator<E> arrayIterator(Object, int, int);
    public static ResettableListIterator<E> arrayListIterator(E...);
    public static ResettableListIterator<E> arrayListIterator(E[], int);
    public static ResettableListIterator<E> arrayListIterator(E[], int, int);
    public static ResettableListIterator<E> arrayListIterator(Object);
    public static ResettableListIterator<E> arrayListIterator(Object, int);
    public static ResettableListIterator<E> arrayListIterator(Object, int, int);
    public static Enumeration<E> asEnumeration(Iterator<? extends E>);
    public static Iterable<E> asIterable(Iterator<? extends E>);
    public static Iterator<E> asIterator(Enumeration<? extends E>);
    public static Iterator<E> asIterator(Enumeration<? extends E>, Collection<? super E>);
    public static Iterable<E> asMultipleUseIterable(Iterator<? extends E>);
    public static BoundedIterator<E> boundedIterator(Iterator<? extends E>, long);
    public static BoundedIterator<E> boundedIterator(Iterator<? extends E>, long, long);
    public static Iterator<E> chainedIterator(Collection<Iterator<? extends E>>);
    public static Iterator<E> chainedIterator(Iterator<? extends E>...);
    public static Iterator<E> chainedIterator(Iterator<? extends E>, Iterator<? extends E>);
    public static Iterator<E> collatedIterator(Comparator<? super E>, Collection<Iterator<? extends E>>);
    public static Iterator<E> collatedIterator(Comparator<? super E>, Iterator<? extends E>...);
    public static Iterator<E> collatedIterator(Comparator<? super E>, Iterator<? extends E>, Iterator<? extends E>);
    public static boolean contains(Iterator<E>, Object);
    public static ResettableIterator<E> emptyIterator();
    public static ResettableListIterator<E> emptyListIterator();
    public static MapIterator<K, V> emptyMapIterator();
    public static OrderedIterator<E> emptyOrderedIterator();
    public static OrderedMapIterator<K, V> emptyOrderedMapIterator();
    public static Iterator<E> filteredIterator(Iterator<? extends E>, Predicate<? super E>);
    public static ListIterator<E> filteredListIterator(ListIterator<? extends E>, Predicate<? super E>);
    public static E find(Iterator<E>, Predicate<? super E>);
    public static E first(Iterator<E>);
    public static void forEach(Iterator<E>, Closure<? super E>);
    public static E forEachButLast(Iterator<E>, Closure<? super E>);
    public static E get(Iterator<E>, int);
    public static Iterator<?> getIterator(Object);
    public static int indexOf(Iterator<E>, Predicate<? super E>);
    public static boolean isEmpty(Iterator<?>);
    public static ResettableIterator<E> loopingIterator(Collection<? extends E>);
    public static ResettableListIterator<E> loopingListIterator(List<E>);
    public static boolean matchesAll(Iterator<E>, Predicate<? super E>);
    public static boolean matchesAny(Iterator<E>, Predicate<? super E>);
    public static NodeListIterator nodeListIterator(Node);
    public static NodeListIterator nodeListIterator(NodeList);
    public static Iterator<E> objectGraphIterator(E, Transformer<? super E, ? extends E>);
    public static Iterator<E> peekingIterator(Iterator<? extends E>);
    public static Iterator<E> pushbackIterator(Iterator<? extends E>);
    public static ResettableIterator<E> singletonIterator(E);
    public static ListIterator<E> singletonListIterator(E);
    public static int size(Iterator<?>);
    public static SkippingIterator<E> skippingIterator(Iterator<E>, long);
    public static Object[] toArray(Iterator<?>);
    public static E[] toArray(Iterator<? extends E>, Class<E>);
    public static List<E> toList(Iterator<? extends E>);
    public static List<E> toList(Iterator<? extends E>, int);
    public static ListIterator<E> toListIterator(Iterator<? extends E>);
    public static String toString(Iterator<E>);
    public static String toString(Iterator<E>, Transformer<? super E, String>);
    public static String toString(Iterator<E>, Transformer<? super E, String>, String, String, String);
    public static Iterator<O> transformedIterator(Iterator<? extends I>, Transformer<? super I, ? extends O>);
    public static Iterator<E> unmodifiableIterator(Iterator<E>);
    public static ListIterator<E> unmodifiableListIterator(ListIterator<E>);
    public static MapIterator<K, V> unmodifiableMapIterator(MapIterator<K, V>);
    public static ZippingIterator<E> zippingIterator(Iterator<? extends E>...);
    public static ZippingIterator<E> zippingIterator(Iterator<? extends E>, Iterator<? extends E>);
    public static ZippingIterator<E> zippingIterator(Iterator<? extends E>, Iterator<? extends E>, Iterator<? extends E>)
}
```
@input{existing test class}
```Java
<initial_class>
```


@input{context information}

api document of class org.apache.commons.collections4.IteratorUtils: 

 * Provides static utility methods and decorators for {@link Iterator}
 * instances. The implementations are provided in the iterators subpackage.
 *
 * @since 2.1
 

api document of method getIterator(Object): 

     * Gets a suitable Iterator for the given object.
     * <p>
     * This method can handle objects as follows
     * <ul>
     * <li>null - empty iterator
     * <li>Iterator - returned directly
     * <li>Enumeration - wrapped
     * <li>Collection - iterator from collection returned
     * <li>Map - values iterator returned
     * <li>Dictionary - values (elements) enumeration returned as iterator
     * <li>array - iterator over array returned
     * <li>object with iterator() public method accessed by reflection
     * <li>object - singleton iterator
     * <li>NodeList - iterator over the list
     * <li>Node - iterator over the child nodes
     * </ul>
     *
     * @param obj  the object to convert to an iterator
     * @return a suitable iterator, never null
     

parameters: 
java.lang.Object obj

calling methods: 
method: java.lang.Object.getClass(), return: java.lang.Class<?>
method: java.lang.reflect.Method.invoke(java.lang.Object, java.lang.Object...), return: java.lang.Object
method: org.apache.commons.collections4.IteratorUtils.emptyIterator(), return: org.apache.commons.collections4.ResettableIterator<E>
method: java.util.Map.values(), return: java.util.Collection<V>
method: org.apache.commons.collections4.IteratorUtils.singletonIterator(E), return: org.apache.commons.collections4.ResettableIterator<E>
method: java.lang.Iterable.iterator(), return: java.util.Iterator<T>
method: java.lang.Class.getMethod(java.lang.String, java.lang.Class<?>...), return: java.lang.reflect.Method
method: java.lang.Class.isAssignableFrom(java.lang.Class<?>), return: boolean
method: java.lang.reflect.Method.getReturnType(), return: java.lang.Class<?>
method: java.lang.Class.isArray(), return: boolean
method: java.util.Collection.iterator(), return: java.util.Iterator<E>
method: java.util.Dictionary.elements(), return: java.util.Enumeration<V>


@output{test class}: complete by you