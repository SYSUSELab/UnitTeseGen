You are a professional Java software testing expert. I need you to help me generate high-quality unit test code for a focused method.

I will provide you with:
1. The focused method needs testing
2. Basic information of target class to which the focus method belongs
3. The existing test class structure
4. The context information for generate tests

Please generate unit test code that meets these requirements:

1. Test Coverage Requirements: 
    - Generate test cases to cover all condition branches in the target method
    - Test boundary conditions and edge cases.
2. Code Quality Requirements: 
    - Follow testing best practices and patterns
    - Use clear and descriptive test method names
    - Add detailed comments explaining test scenarios
    - Make the test code easy to understand and maintain.
3. Test Structure:
    - Follow the existing test class, and appropriate test frameworks and assertions
    - Properly set up test fixtures and dependencies
    - Clean up resources after tests
    - Divide test cases into different functions logically
4. Additional Guidelines:
- Mock external dependencies when needed
- Include error/exception test cases
- Validate both expected outputs 

@input{focused method}
```Java
public static void populateEnv(SparkApplicationSpec sparkSpec, SubmitApplicationRequest request, AppConfig.SparkCluster sparkCluster){
    if (sparkCluster.getDriver() != null && sparkCluster.getDriver().getEnv() != null) {
        // there is env in spark cluster driver configure, copy it to spark spec
        if (sparkSpec.getDriver() == null) {
            sparkSpec.setDriver(new DriverSpec());
        }
        if (sparkSpec.getDriver().getEnv() == null) {
            sparkSpec.getDriver().setEnv(new ArrayList<>());
        }
        SparkSpecHelper.copyEnv(sparkCluster.getDriver().getEnv(), sparkSpec.getDriver().getEnv());
    }
    if (request.getDriver() != null && request.getDriver().getEnv() != null) {
        // there is env in request driver configure, copy it to spark spec
        if (sparkSpec.getDriver() == null) {
            sparkSpec.setDriver(new DriverSpec());
        }
        if (sparkSpec.getDriver().getEnv() == null) {
            sparkSpec.getDriver().setEnv(new ArrayList<>());
        }
        SparkSpecHelper.copyEnv(request.getDriver().getEnv(), sparkSpec.getDriver().getEnv());
    }
    if (sparkCluster.getExecutor() != null && sparkCluster.getExecutor().getEnv() != null) {
        // there is env in spark cluster executor configure, copy it to spark spec
        if (sparkSpec.getExecutor() == null) {
            sparkSpec.setExecutor(new ExecutorSpec());
        }
        if (sparkSpec.getExecutor().getEnv() == null) {
            sparkSpec.getExecutor().setEnv(new ArrayList<>());
        }
        SparkSpecHelper.copyEnv(sparkCluster.getExecutor().getEnv(), sparkSpec.getExecutor().getEnv());
    }
    if (request.getExecutor() != null && request.getExecutor().getEnv() != null) {
        // there is env in request executor configure, copy it to spark spec
        if (sparkSpec.getExecutor() == null) {
            sparkSpec.setExecutor(new ExecutorSpec());
        }
        if (sparkSpec.getExecutor().getEnv() == null) {
            sparkSpec.getExecutor().setEnv(new ArrayList<>());
        }
        SparkSpecHelper.copyEnv(request.getExecutor().getEnv(), sparkSpec.getExecutor().getEnv());
    }
}
```

@input{target class}
```Java
package com.apple.spark.core;

import static com.apple.spark.core.BatchSchedulerConstants.PLACEHOLDER_TIMEOUT_IN_SECONDS;
import static com.apple.spark.core.BatchSchedulerConstants.YUNIKORN_ROOT_QUEUE;
import static com.apple.spark.core.BatchSchedulerConstants.YUNIKORN_SPARK_DEFAULT_QUEUE;
import static com.apple.spark.core.Constants.*;
import static com.apple.spark.core.SparkConstants.CORE_LIMIT_RATIO;
import static com.apple.spark.core.SparkConstants.DRIVER_CPU_BUFFER_RATIO;
import static com.apple.spark.core.SparkConstants.DRIVER_MEM_BUFFER_RATIO;
import static com.apple.spark.core.SparkConstants.EXECUTOR_CPU_BUFFER_RATIO;
import static com.apple.spark.core.SparkConstants.EXECUTOR_MEM_BUFFER_RATIO;
import com.apple.spark.AppConfig;
import com.apple.spark.AppConfig.SparkCluster;
import com.apple.spark.api.SubmitApplicationRequest;
import com.apple.spark.operator.Affinity;
import com.apple.spark.operator.BatchSchedulerConfiguration;
import com.apple.spark.operator.DriverSpec;
import com.apple.spark.operator.ExecutorSpec;
import com.apple.spark.operator.NodeAffinity;
import com.apple.spark.operator.NodeSelectorOperator;
import com.apple.spark.operator.NodeSelectorRequirement;
import com.apple.spark.operator.NodeSelectorTerm;
import com.apple.spark.operator.RequiredDuringSchedulingIgnoredDuringExecutionTerm;
import com.apple.spark.operator.SparkApplicationSpec;
import com.apple.spark.operator.SparkUIConfiguration;
import com.apple.spark.operator.Volume;
import com.apple.spark.util.ExceptionUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import com.fasterxml.jackson.dataformat.yaml.YAMLGenerator;
import io.fabric8.kubernetes.api.model.PodDNSConfig;
import io.fabric8.kubernetes.api.model.PodDNSConfigOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ApplicationSubmissionHelper {
    private static final Logger logger = LoggerFactory.getLogger(ApplicationSubmissionHelper.class);
    private static final String FILE_PATH_REGEX = "([a-zA-Z~])?(\\/[a-zA-Z0-9_.-]+)+\\/?";
    public static SubmitApplicationRequest parseSubmitRequest(String, String);
    public static String getProxyUser(String, String);
    public static boolean looksLikeFilePath(String);
    public static Map<String, String> getSparkConf(String, SubmitApplicationRequest, AppConfig, AppConfig.SparkCluster);
    public static SparkUIConfiguration getSparkUIConfiguration(String, AppConfig.SparkCluster);
    public static List<Volume> getVolumes(SubmitApplicationRequest, AppConfig.SparkCluster);
    public static void populateEnv(SparkApplicationSpec, SubmitApplicationRequest, AppConfig.SparkCluster);
    public static String generateSubmissionId(String);
    public static String generateSubmissionId(String, String);
    public static String getClusterIdFromSubmissionId(String);
    public static void validateQueueToken(String, String, AppConfig);
    private static String substitutionSparkConfigValue(String, String);
    private static Map<String, String> applyFeatureGate(SubmitApplicationRequest, Map<String, String>);
    public static BatchSchedulerConfiguration getYuniKornSchedulerConfig(String);
    public static DriverSpec getDriverSpec(SubmitApplicationRequest, AppConfig, String, SparkCluster);
    private static double getDriverCPUBufferForQueue(AppConfig, String);
    private static double getDriverMemBufferForQueue(AppConfig, String);
    private static String getDriverNodeLabelKeyForQueue(AppConfig, String);
    private static List<String> getDriverNodeLabelValuesForQueue(AppConfig, String);
    private static double getExecutorMemBufferForQueue(AppConfig, String);
    private static double getExecutorCPUBufferForQueue(AppConfig, String);
    private static List<String> getExecutorSpotNodeLabelValuesForQueue(AppConfig, String);
    private static String getExecutorNodeLabelKeyForQueue(AppConfig, String);
    private static List<String> getExecutorNodeLabelValuesForQueue(AppConfig, String);
    private static long getMemNumFromRequestStr(String);
    private static String getMemUnitFromRequestStr(String);
    private static int getMemUnitIndexFromRequestStr(String);
    public static ExecutorSpec getExecutorSpec(SubmitApplicationRequest, AppConfig, String, SparkCluster);
    public static String getType(String, String);
    public static String getImage(AppConfig, SubmitApplicationRequest, String, String, String)
}
```
@input{existing test class}
```Java
<initial_class>
```


@input{context information}

parameters: 
com.apple.spark.operator.SparkApplicationSpec sparkSpec 
com.apple.spark.api.SubmitApplicationRequest request 
com.apple.spark.AppConfig.SparkCluster sparkCluster 

calling methods: 
method: com.apple.spark.operator.SparkPodSpec.setEnv(java.util.List<com.apple.spark.operator.EnvVar>), return: void
method: com.apple.spark.operator.SparkApplicationSpec.setDriver(com.apple.spark.operator.DriverSpec), return: void
method: com.apple.spark.AppConfig.SparkCluster.getExecutor(), return: com.apple.spark.operator.ExecutorSpec
method: com.apple.spark.operator.SparkApplicationSpec.getDriver(), return: com.apple.spark.operator.DriverSpec
method: com.apple.spark.operator.SparkApplicationSpec.setExecutor(com.apple.spark.operator.ExecutorSpec), return: void
method: com.apple.spark.operator.SparkPodSpec.getEnv(), return: java.util.List<com.apple.spark.operator.EnvVar>
method: com.apple.spark.core.SparkSpecHelper.copyEnv(java.util.List<com.apple.spark.operator.EnvVar>, java.util.List<com.apple.spark.operator.EnvVar>), return: void
method: com.apple.spark.operator.SparkApplicationSpec.getExecutor(), return: com.apple.spark.operator.ExecutorSpec
method: com.apple.spark.AppConfig.SparkCluster.getDriver(), return: com.apple.spark.operator.DriverSpec
method: com.apple.spark.api.SubmitApplicationRequest.getDriver(), return: com.apple.spark.operator.DriverSpec
method: com.apple.spark.api.SubmitApplicationRequest.getExecutor(), return: com.apple.spark.operator.ExecutorSpec


@output{test class}: complete by you