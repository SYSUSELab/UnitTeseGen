You are a professional Java software testing expert. I need you to help me generate high-quality unit test code for a focused method.

I will provide you with:
1. The focused method needs testing
2. Basic information of target class to which the focus method belongs
3. The existing test class structure
4. The context information for generate tests

Please generate unit test code that meets these requirements:

1. Test Coverage Requirements: 
    - Generate test cases to cover all condition branches in the target method
    - Test boundary conditions and edge cases.
2. Code Quality Requirements: 
    - Follow testing best practices and patterns
    - Use clear and descriptive test method names
    - Add detailed comments explaining test scenarios
    - Make the test code easy to understand and maintain.
3. Test Structure:
    - Follow the existing test class, and appropriate test frameworks and assertions
    - Properly set up test fixtures and dependencies
    - Clean up resources after tests
    - Divide test cases into different functions logically
4. Additional Guidelines:
- Mock external dependencies when needed
- Include error/exception test cases
- Validate both expected outputs 

@input{focused method}
```Java
public static void main(String[] args){
    int applications = 10;
    int mapTasks = 2;
    int sleepSeconds = 3;
    int maxWaitSeconds = 60 * 60;
    int executors = 1;
    boolean deleteApplication = true;
    for (int i = 0; i < args.length; ) {
        String argName = args[i++];
        if (argName.equalsIgnoreCase("-applications")) {
            applications = Integer.parseInt(args[i++]);
        } else if (argName.equalsIgnoreCase("-mapTasks")) {
            mapTasks = Integer.parseInt(args[i++]);
        } else if (argName.equalsIgnoreCase("-sleepSeconds")) {
            sleepSeconds = Integer.parseInt(args[i++]);
        } else if (argName.equalsIgnoreCase("-maxWaitSeconds")) {
            maxWaitSeconds = Integer.parseInt(args[i++]);
        } else if (argName.equalsIgnoreCase("-executors")) {
            executors = Integer.parseInt(args[i++]);
        } else if (argName.equalsIgnoreCase("-deleteApplication")) {
            deleteApplication = Boolean.parseBoolean(args[i++]);
        } else {
            throw new RuntimeException(String.format("Unsupported argument: %s", argName));
        }
    }
    for (int i = 0; i < applications; i++) {
        final int applicationIndex = i;
        final int mapTasksFinal = mapTasks;
        final int sleepSecondsFinal = sleepSeconds;
        final int executorsFinal = executors;
        CompletableFuture.runAsync(() -> submitApplication(applicationIndex, mapTasksFinal, sleepSecondsFinal, executorsFinal));
    }
    long waitStartTime = System.currentTimeMillis();
    while (finishedApps.size() < applications) {
        if (System.currentTimeMillis() - waitStartTime > TimeUnit.MINUTES.toMillis(maxWaitSeconds)) {
            break;
        }
        List<TestApplicationInfo> appsToRemove = new ArrayList<>();
        for (TestApplicationInfo app : runningApps) {
            String getStatusUrl = String.format(getStatusUrlFormat, app.getSubmissionId());
            GetSubmissionStatusResponse getSubmissionStatusResponse = HttpUtils.get(getStatusUrl, authHeaderName, authHeaderValue, GetSubmissionStatusResponse.class);
            if (SparkConstants.isApplicationStopped(getSubmissionStatusResponse.getApplicationState())) {
                app.setState(getSubmissionStatusResponse.getApplicationState());
                app.setCompletedTime(getSubmissionStatusResponse.getTerminationTime());
                String getDriverUrl = String.format(getDriverUrlFormat, app.getSubmissionId());
                GetDriverInfoResponse getDriverInfoResponse = HttpUtils.get(getDriverUrl, authHeaderName, authHeaderValue, GetDriverInfoResponse.class);
                app.setDriverStartTime(getDriverInfoResponse.getStartTime());
                logger.info("Test application completed: {}", app);
                appsToRemove.add(app);
            }
        }
        for (TestApplicationInfo app : appsToRemove) {
            runningApps.remove(app);
            finishedApps.add(app);
        }
        if (!runningApps.isEmpty()) {
            int waitSeconds = 10;
            logger.info("Wait {} seconds to check application", waitSeconds);
            try {
                Thread.sleep(waitSeconds * 1000);
            } catch (InterruptedException e) {
            }
        }
    }
    if (deleteApplication) {
        for (TestApplicationInfo app : finishedApps) {
            String deleteUrl = String.format(deleteUrlFormat, app.getSubmissionId());
            logger.info("Deleting application {}", app.getSubmissionId());
            HttpUtils.delete(deleteUrl, authHeaderName, authHeaderValue);
        }
    }
    System.exit(0);
}
```

@input{target class}
```Java
package com.apple.spark.tools;

import com.apple.spark.api.GetDriverInfoResponse;
import com.apple.spark.api.GetSubmissionStatusResponse;
import com.apple.spark.api.SubmitApplicationRequest;
import com.apple.spark.api.SubmitApplicationResponse;
import com.apple.spark.core.SparkConstants;
import com.apple.spark.operator.DriverSpec;
import com.apple.spark.operator.ExecutorSpec;
import com.apple.spark.util.HttpUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.TimeUnit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LoadTest {
    private static final Logger logger = LoggerFactory.getLogger(LoadTest.class);
    private static final String serviceRootUrl = "";
    private static final String submitSparkApplicationUrl = String.format("%s/spark", serviceRootUrl);
    private static final String getStatusUrlFormat = String.format("%s/spark/%%s/status", serviceRootUrl);
    private static final String getDriverUrlFormat = String.format("%s/spark/%%s/driver", serviceRootUrl);
    private static final String deleteUrlFormat = String.format("%s/spark/%%s", serviceRootUrl);
    private static final String authHeaderName = "Authorization";
    private static final String authHeaderValue = "Basic dXNlcjE6cGFzc3dvcmQ=";
    private static final ConcurrentLinkedQueue<TestApplicationInfo> runningApps = new ConcurrentLinkedQueue<>();
    private static final ConcurrentLinkedQueue<TestApplicationInfo> finishedApps = new ConcurrentLinkedQueue<>();
    public static void main(String[]);
    private static void submitApplication(int, int, int, int)
}
```
@input{existing test class}
```Java
<initial_class>
```


@input{context information}

parameters: 
java.lang.String[] args

calling methods: 
method: java.lang.Thread.sleep(long), return: void
method: java.util.concurrent.TimeUnit.toMillis(long), return: long
method: com.apple.spark.api.SubmissionStatus.getApplicationState(), return: java.lang.String
method: java.util.concurrent.ConcurrentLinkedQueue.size(), return: int
method: java.util.concurrent.ConcurrentLinkedQueue.isEmpty(), return: boolean
method: com.apple.spark.util.HttpUtils.delete(java.lang.String, java.lang.String, java.lang.String), return: java.lang.String
method: com.apple.spark.core.SparkConstants.isApplicationStopped(java.lang.String), return: boolean
method: com.apple.spark.tools.LoadTest.TestApplicationInfo.setDriverStartTime(java.lang.Long), return: void
method: org.slf4j.Logger.info(java.lang.String, java.lang.Object), return: void
method: com.apple.spark.api.SubmissionStatus.getTerminationTime(), return: java.lang.Long
method: java.lang.System.currentTimeMillis(), return: long
method: java.util.List.add(E), return: boolean
method: java.lang.String.equalsIgnoreCase(java.lang.String), return: boolean
method: java.util.concurrent.ConcurrentLinkedQueue.add(E), return: boolean
method: com.apple.spark.tools.LoadTest.submitApplication(int, int, int, int), return: void
method: java.lang.System.exit(int), return: void
method: java.lang.String.format(java.lang.String, java.lang.Object...), return: java.lang.String
method: com.apple.spark.util.HttpUtils.get(java.lang.String, java.lang.String, java.lang.String, java.lang.Class<T>), return: T
method: java.util.concurrent.CompletableFuture.runAsync(java.lang.Runnable), return: java.util.concurrent.CompletableFuture<java.lang.Void>
method: com.apple.spark.tools.LoadTest.TestApplicationInfo.getSubmissionId(), return: java.lang.String
method: java.lang.Boolean.parseBoolean(java.lang.String), return: boolean
method: java.util.concurrent.ConcurrentLinkedQueue.remove(java.lang.Object), return: boolean
method: com.apple.spark.api.GetDriverInfoResponse.getStartTime(), return: java.lang.Long
method: com.apple.spark.tools.LoadTest.TestApplicationInfo.setState(java.lang.String), return: void
method: com.apple.spark.tools.LoadTest.TestApplicationInfo.setCompletedTime(java.lang.Long), return: void
method: java.lang.Integer.parseInt(java.lang.String), return: int


@output{test class}: complete by you