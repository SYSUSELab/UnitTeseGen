You are a professional Java developer. I will provide you with a Java class with its context and a test class template. Your task is to generate a test class framework for this class based on the template. You don't need to generate test cases, just complete the functions in the template.

Please analyze the following information and help me complete the test class template:

1. The target class and its constructor parameters
2. Field declarations and their types
3. Dependencies and external resources used by the class

Requirements:
1. Complete the setupBeforeAll(), setupBeforeEach(), teardownAfterEach(), and teardownAfterAll() methods
2. Initialize necessary fields and dependencies
3. Handle any required cleanup
4. Ensure the generated code has no syntax errors

Please provide the completed test class template with proper field declarations and setup/teardown methods.

@input{focused method}
```java
 CSVRecord nextRecord() throws IOException{
    CSVRecord result = null;
    recordList.clear();
    StringBuilder sb = null;
    final long startCharPosition = lexer.getCharacterPosition() + characterOffset;
    final long startBytePosition = lexer.getBytesRead() + this.characterOffset;
    do {
        reusableToken.reset();
        lexer.nextToken(reusableToken);
        switch(reusableToken.type) {
            case TOKEN:
                addRecordValue(false);
                break;
            case EORECORD:
                addRecordValue(true);
                break;
            case EOF:
                if (reusableToken.isReady) {
                    addRecordValue(true);
                } else if (sb != null) {
                    trailerComment = sb.toString();
                }
                break;
            case INVALID:
                throw new CSVException("(line %,d) invalid parse sequence", getCurrentLineNumber());
            case // Ignored currently
            COMMENT:
                if (sb == null) {
                    // first comment for this record
                    sb = new StringBuilder();
                } else {
                    sb.append(Constants.LF);
                }
                sb.append(reusableToken.content);
                // Read another token
                reusableToken.type = TOKEN;
                break;
            default:
                throw new CSVException("Unexpected Token type: %s", reusableToken.type);
        }
    } while (reusableToken.type == TOKEN);
    if (!recordList.isEmpty()) {
        recordNumber++;
        final String comment = Objects.toString(sb, null);
        result = new CSVRecord(this, recordList.toArray(Constants.EMPTY_STRING_ARRAY), comment, recordNumber, startCharPosition, startBytePosition);
    }
    return result;
}
```

@input{target class}
```java
package org.apache.commons.csv;

import static org.apache.commons.csv.Token.Type.TOKEN;
import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.io.UncheckedIOException;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.Spliterator;
import java.util.Spliterators;
import java.util.TreeMap;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import org.apache.commons.io.build.AbstractStreamBuilder;
import org.apache.commons.io.function.Uncheck;

public final class CSVParser implements Iterable<CSVRecord>, Closeable {
    private String headerComment;
    private String trailerComment;
    private final CSVFormat format;
    private final Headers headers;
    private final Lexer lexer;
    private final CSVRecordIterator csvRecordIterator;
    private final List<String> recordList = new ArrayList<>();
    private long recordNumber;
    private final long characterOffset;
    private final Token reusableToken = new Token();
    public CSVParser(final Reader reader, final CSVFormat format) throws IOException;
    public CSVParser(final Reader reader, final CSVFormat format, final long characterOffset, final long recordNumber) throws IOException;
    private CSVParser(final Reader reader, final CSVFormat format, final long characterOffset, final long recordNumber, final Charset charset, final boolean trackBytes) throws IOException;
    public static Builder builder();
    public static CSVParser parse(File, Charset, CSVFormat) throws IOException;
    public static CSVParser parse(InputStream, Charset, CSVFormat) throws IOException;
    public static CSVParser parse(Path, Charset, CSVFormat) throws IOException;
    public static CSVParser parse(Reader, CSVFormat) throws IOException;
    public static CSVParser parse(String, CSVFormat) throws IOException;
    public static CSVParser parse(URL, Charset, CSVFormat) throws IOException;
    private void addRecordValue(boolean);
    public void close() throws IOException;
    private Map<String, Integer> createEmptyHeaderMap();
    private Headers createHeaders() throws IOException;
    public long getCurrentLineNumber();
    public String getFirstEndOfLine();
    public String getHeaderComment();
    public Map<String, Integer> getHeaderMap();
     Map<String, Integer> getHeaderMapRaw();
    public List<String> getHeaderNames();
    public long getRecordNumber();
    public List<CSVRecord> getRecords();
    public String getTrailerComment();
    private String handleNull(String);
    public boolean hasHeaderComment();
    public boolean hasTrailerComment();
    public boolean isClosed();
    private boolean isStrictQuoteMode();
    public Iterator<CSVRecord> iterator();
     CSVRecord nextRecord() throws IOException;
    public Stream<CSVRecord> stream()
}
```

@input{context information}

constructors for class `org.apache.commons.csv.CSVParser`: 
```java
params: java.io.Reader reader
org.apache.commons.csv.CSVFormat format 
body:
```java
public CSVParser(final Reader reader, final CSVFormat format) throws IOException
{
    this(reader, format, 0, 1);
}
```params: java.io.Reader reader
org.apache.commons.csv.CSVFormat format 
long characterOffset
long recordNumber
body:
```java
public CSVParser(final Reader reader, final CSVFormat format, final long characterOffset, final long recordNumber) throws IOException
{
    this(reader, format, characterOffset, recordNumber, null, false);
}
```params: java.io.Reader reader
org.apache.commons.csv.CSVFormat format 
long characterOffset
long recordNumber
java.nio.charset.Charset charset
boolean trackBytes
body:
```java
private CSVParser(final Reader reader, final CSVFormat format, final long characterOffset, final long recordNumber, final Charset charset, final boolean trackBytes) throws IOException
{
    Objects.requireNonNull(reader, "reader");
    Objects.requireNonNull(format, "format");
    this.format = format.copy();
    this.lexer = new Lexer(format, new ExtendedBufferedReader(reader, charset, trackBytes));
    this.csvRecordIterator = new CSVRecordIterator();
    this.headers = createHeaders();
    this.characterOffset = characterOffset;
    this.recordNumber = recordNumber - 1;
}
```
```

api document of class org.apache.commons.csv.CSVParser: 

 * Parses CSV files according to the specified format.
 *
 * Because CSV appears in many different dialects, the parser supports many formats by allowing the
 * specification of a {@link CSVFormat}.
 *
 * The parser works record-wise. It is not possible to go back, once a record has been parsed from the input stream.
 *
 * <h2>Creating instances</h2>
 * <p>
 * There are several static factory methods that can be used to create instances for various types of resources:
 * </p>
 * <ul>
 *     <li>{@link #parse(java.io.File, Charset, CSVFormat)}</li>
 *     <li>{@link #parse(String, CSVFormat)}</li>
 *     <li>{@link #parse(java.net.URL, java.nio.charset.Charset, CSVFormat)}</li>
 * </ul>
 * <p>
 * Alternatively parsers can also be created by passing a {@link Reader} directly to the sole constructor.
 *
 * For those who like fluent APIs, parsers can be created using {@link CSVFormat#parse(java.io.Reader)} as a shortcut:
 * </p>
 * <pre>
 * for (CSVRecord record : CSVFormat.EXCEL.parse(in)) {
 *     ...
 * }
 * </pre>
 *
 * <h2>Parsing record wise</h2>
 * <p>
 * To parse a CSV input from a file, you write:
 * </p>
 *
 * <pre>{@code
 * File csvData = new File("/path/to/csv");
 * CSVParser parser = CSVParser.parse(csvData, CSVFormat.RFC4180);
 * for (CSVRecord csvRecord : parser) {
 *     ...
 * }}
 * </pre>
 *
 * <p>
 * This will read the parse the contents of the file using the
 * <a href="https://tools.ietf.org/html/rfc4180" target="_blank">RFC 4180</a> format.
 * </p>
 *
 * <p>
 * To parse CSV input in a format like Excel, you write:
 * </p>
 *
 * <pre>
 * CSVParser parser = CSVParser.parse(csvData, CSVFormat.EXCEL);
 * for (CSVRecord csvRecord : parser) {
 *     ...
 * }
 * </pre>
 *
 * <p>
 * If the predefined formats don't match the format at hand, custom formats can be defined. More information about
 * customizing CSVFormats is available in {@link CSVFormat CSVFormat Javadoc}.
 * </p>
 *
 * <h2>Parsing into memory</h2>
 * <p>
 * If parsing record-wise is not desired, the contents of the input can be read completely into memory.
 * </p>
 *
 * <pre>{@code
 * Reader in = new StringReader("a;b\nc;d");
 * CSVParser parser = new CSVParser(in, CSVFormat.EXCEL);
 * List<CSVRecord> list = parser.getRecords();
 * }</pre>
 *
 * <p>
 * There are two constraints that have to be kept in mind:
 * </p>
 *
 * <ol>
 *     <li>Parsing into memory starts at the current position of the parser. If you have already parsed records from
 *     the input, those records will not end up in the in-memory representation of your CSV data.</li>
 *     <li>Parsing into memory may consume a lot of system resources depending on the input. For example, if you're
 *     parsing a 150MB file of CSV data the contents will be read completely into memory.</li>
 * </ol>
 *
 * <h2>Notes</h2>
 * <p>
 * The internal parser state is completely covered by the format and the reader state.
 * </p>
 *
 * @see <a href="package-summary.html">package documentation for more details</a>
 


@input{test class template}
```java
package org.apache.commons.csv;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.*;
import static org.mockito.Mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
// Add other imports if necessary

@ExtendWith(MockitoExtension.class)
class CSVParser_1_Test {
    @BeforeAll
    static void setupBeforeAll() {
    }

    @BeforeEach
    void setupBeforeEach() {
    }

    @AfterEach
    void teardownAfterEach() {
    }

    @AfterAll
    static void teardownAfterAll() {
    }
}
```

@output{initial test class}: completed by you