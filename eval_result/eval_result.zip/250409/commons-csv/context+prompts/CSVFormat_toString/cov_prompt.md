You are a professional Java software testing expert. I need you to help me generate high-quality unit test code for a focused method.

I will provide you with:
1. The focused method needs testing
2. Basic information of target class to which the focus method belongs
3. The existing test class structure
4. The context information for generate tests

Please generate unit test code that meets these requirements:

1. Test Coverage Requirements: 
    - Generate test cases to cover all condition branches in the target method
    - Test boundary conditions and edge cases.
2. Code Quality Requirements: 
    - Follow testing best practices and patterns
    - Use clear and descriptive test method names
    - Add detailed comments explaining test scenarios
    - Make the test code easy to understand and maintain.
3. Test Structure:
    - Follow the existing test class, and appropriate test frameworks and assertions
    - Properly set up test fixtures and dependencies
    - Clean up resources after tests
    - Divide test cases into different functions logically
4. Additional Guidelines:
- Mock external dependencies when needed
- Include error/exception test cases
- Validate both expected outputs 

@input{focused method}
```Java
public String toString(){
    final StringBuilder sb = new StringBuilder();
    sb.append("Delimiter=<").append(delimiter).append('>');
    if (isEscapeCharacterSet()) {
        sb.append(' ');
        sb.append("Escape=<").append(escapeCharacter).append('>');
    }
    if (isQuoteCharacterSet()) {
        sb.append(' ');
        sb.append("QuoteChar=<").append(quoteCharacter).append('>');
    }
    if (quoteMode != null) {
        sb.append(' ');
        sb.append("QuoteMode=<").append(quoteMode).append('>');
    }
    if (isCommentMarkerSet()) {
        sb.append(' ');
        sb.append("CommentStart=<").append(commentMarker).append('>');
    }
    if (isNullStringSet()) {
        sb.append(' ');
        sb.append("NullString=<").append(nullString).append('>');
    }
    if (recordSeparator != null) {
        sb.append(' ');
        sb.append("RecordSeparator=<").append(recordSeparator).append('>');
    }
    if (getIgnoreEmptyLines()) {
        sb.append(" EmptyLines:ignored");
    }
    if (getIgnoreSurroundingSpaces()) {
        sb.append(" SurroundingSpaces:ignored");
    }
    if (getIgnoreHeaderCase()) {
        sb.append(" IgnoreHeaderCase:ignored");
    }
    sb.append(" SkipHeaderRecord:").append(skipHeaderRecord);
    if (headerComments != null) {
        sb.append(' ');
        sb.append("HeaderComments:").append(Arrays.toString(headerComments));
    }
    if (headers != null) {
        sb.append(' ');
        sb.append("Header:").append(Arrays.toString(headers));
    }
    return sb.toString();
}
```

@input{target class}
```Java
package org.apache.commons.csv;

import static org.apache.commons.io.IOUtils.EOF;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Serializable;
import java.io.StringWriter;
import java.io.Writer;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;
import org.apache.commons.codec.binary.Base64OutputStream;
import org.apache.commons.io.IOUtils;
import org.apache.commons.io.function.Uncheck;
import org.apache.commons.io.output.AppendableOutputStream;

public final class CSVFormat implements Serializable {
    public static final CSVFormat DEFAULT = new CSVFormat(Builder.create());
    public static final CSVFormat EXCEL = DEFAULT.builder().setIgnoreEmptyLines(false).setAllowMissingColumnNames(true).setTrailingData(true).setLenientEof(true).get();
    public static final CSVFormat INFORMIX_UNLOAD = DEFAULT.builder().setDelimiter(Constants.PIPE).setEscape(Constants.BACKSLASH).setQuote(Constants.DOUBLE_QUOTE_CHAR).setRecordSeparator(Constants.LF).get();
    public static final CSVFormat INFORMIX_UNLOAD_CSV = DEFAULT.builder().setDelimiter(Constants.COMMA).setQuote(Constants.DOUBLE_QUOTE_CHAR).setRecordSeparator(Constants.LF).get();
    public static final CSVFormat MONGODB_CSV = DEFAULT.builder().setDelimiter(Constants.COMMA).setEscape(Constants.DOUBLE_QUOTE_CHAR).setQuote(Constants.DOUBLE_QUOTE_CHAR).setQuoteMode(QuoteMode.MINIMAL).get();
    public static final CSVFormat MONGODB_TSV = DEFAULT.builder().setDelimiter(Constants.TAB).setEscape(Constants.DOUBLE_QUOTE_CHAR).setQuote(Constants.DOUBLE_QUOTE_CHAR).setQuoteMode(QuoteMode.MINIMAL).setSkipHeaderRecord(false).get();
    public static final CSVFormat MYSQL = DEFAULT.builder().setDelimiter(Constants.TAB).setEscape(Constants.BACKSLASH).setIgnoreEmptyLines(false).setQuote(null).setRecordSeparator(Constants.LF).setNullString(Constants.SQL_NULL_STRING).setQuoteMode(QuoteMode.ALL_NON_NULL).get();
    public static final CSVFormat ORACLE = DEFAULT.builder().setDelimiter(Constants.COMMA).setEscape(Constants.BACKSLASH).setIgnoreEmptyLines(false).setQuote(Constants.DOUBLE_QUOTE_CHAR).setNullString(Constants.SQL_NULL_STRING).setTrim(true).setRecordSeparator(System.lineSeparator()).setQuoteMode(QuoteMode.MINIMAL).get();
    public static final CSVFormat POSTGRESQL_CSV = DEFAULT.builder().setDelimiter(Constants.COMMA).setEscape(null).setIgnoreEmptyLines(false).setQuote(Constants.DOUBLE_QUOTE_CHAR).setRecordSeparator(Constants.LF).setNullString(Constants.EMPTY).setQuoteMode(QuoteMode.ALL_NON_NULL).get();
    public static final CSVFormat POSTGRESQL_TEXT = DEFAULT.builder().setDelimiter(Constants.TAB).setEscape(Constants.BACKSLASH).setIgnoreEmptyLines(false).setQuote(null).setRecordSeparator(Constants.LF).setNullString(Constants.SQL_NULL_STRING).setQuoteMode(QuoteMode.ALL_NON_NULL).get();
    public static final CSVFormat RFC4180 = DEFAULT.builder().setIgnoreEmptyLines(false).get();
    private static final long serialVersionUID = 2L;
    public static final CSVFormat TDF = DEFAULT.builder().setDelimiter(Constants.TAB).setIgnoreSurroundingSpaces(true).get();
    private final DuplicateHeaderMode duplicateHeaderMode;
    private final boolean allowMissingColumnNames;
    private final boolean autoFlush;
    private final Character commentMarker;
    private final String delimiter;
    private final Character escapeCharacter;
    private final String[] headers;
    private final String[] headerComments;
    private final boolean ignoreEmptyLines;
    private final boolean ignoreHeaderCase;
    private final boolean ignoreSurroundingSpaces;
    private final String nullString;
    private final Character quoteCharacter;
    private final String quotedNullString;
    private final QuoteMode quoteMode;
    private final String recordSeparator;
    private final boolean skipHeaderRecord;
    private final boolean lenientEof;
    private final boolean trailingData;
    private final boolean trailingDelimiter;
    private final boolean trim;
    private CSVFormat(final Builder builder);
     static T[] clone(T...);
    private static boolean contains(String, char);
    private static boolean containsLineBreak(String);
     static CSVFormat copy(CSVFormat);
     static boolean isBlank(String);
    private static boolean isLineBreak(char);
    private static boolean isLineBreak(Character);
    private static boolean isTrimChar(char);
    private static boolean isTrimChar(CharSequence, int);
    public static CSVFormat newFormat(char);
     static String[] toStringArray(Object[]);
     static CharSequence trim(CharSequence);
    public static CSVFormat valueOf(String);
    private void append(char, Appendable) throws IOException;
    private void append(CharSequence, Appendable) throws IOException;
    public Builder builder();
     CSVFormat copy();
    public boolean equals(Object);
    private void escape(char, Appendable) throws IOException;
    public String format(Object...);
    private String format_(Object...) throws IOException;
    public boolean getAllowDuplicateHeaderNames();
    public boolean getAllowMissingColumnNames();
    public boolean getAutoFlush();
    public Character getCommentMarker();
    public char getDelimiter();
     char[] getDelimiterCharArray();
    public String getDelimiterString();
    public DuplicateHeaderMode getDuplicateHeaderMode();
     char getEscapeChar();
    public Character getEscapeCharacter();
    public String[] getHeader();
    public String[] getHeaderComments();
    public boolean getIgnoreEmptyLines();
    public boolean getIgnoreHeaderCase();
    public boolean getIgnoreSurroundingSpaces();
    public boolean getLenientEof();
    public String getNullString();
    public Character getQuoteCharacter();
    public QuoteMode getQuoteMode();
    public String getRecordSeparator();
    public boolean getSkipHeaderRecord();
    public boolean getTrailingData();
    public boolean getTrailingDelimiter();
    public boolean getTrim();
    public int hashCode();
    public boolean isCommentMarkerSet();
    private boolean isDelimiter(char, CharSequence, int, char[], int);
    public boolean isEscapeCharacterSet();
    public boolean isNullStringSet();
    public boolean isQuoteCharacterSet();
    public CSVParser parse(Reader) throws IOException;
    public CSVPrinter print(Appendable) throws IOException;
    public CSVPrinter print(File, Charset) throws IOException;
    private void print(InputStream, Appendable, boolean) throws IOException;
    public synchronized void print(Object, Appendable, boolean) throws IOException;
    private synchronized void print(Object, CharSequence, Appendable, boolean) throws IOException;
    public CSVPrinter print(Path, Charset) throws IOException;
    private void print(Reader, Appendable, boolean) throws IOException;
    public CSVPrinter printer() throws IOException;
    public synchronized void println(Appendable) throws IOException;
    public synchronized void printRecord(Appendable, Object...) throws IOException;
    private void printWithEscapes(CharSequence, Appendable) throws IOException;
    private void printWithEscapes(Reader, Appendable) throws IOException;
    private void printWithQuotes(Object, CharSequence, Appendable, boolean) throws IOException;
    private void printWithQuotes(Reader, Appendable) throws IOException;
    public String toString();
     String trim(String);
    private void validate() throws IllegalArgumentException;
    public CSVFormat withAllowDuplicateHeaderNames();
    public CSVFormat withAllowDuplicateHeaderNames(boolean);
    public CSVFormat withAllowMissingColumnNames();
    public CSVFormat withAllowMissingColumnNames(boolean);
    public CSVFormat withAutoFlush(boolean);
    public CSVFormat withCommentMarker(char);
    public CSVFormat withCommentMarker(Character);
    public CSVFormat withDelimiter(char);
    public CSVFormat withEscape(char);
    public CSVFormat withEscape(Character);
    public CSVFormat withFirstRecordAsHeader();
    public CSVFormat withHeader(Class<? extends Enum<?>>);
    public CSVFormat withHeader(ResultSet) throws SQLException;
    public CSVFormat withHeader(ResultSetMetaData) throws SQLException;
    public CSVFormat withHeader(String...);
    public CSVFormat withHeaderComments(Object...);
    public CSVFormat withIgnoreEmptyLines();
    public CSVFormat withIgnoreEmptyLines(boolean);
    public CSVFormat withIgnoreHeaderCase();
    public CSVFormat withIgnoreHeaderCase(boolean);
    public CSVFormat withIgnoreSurroundingSpaces();
    public CSVFormat withIgnoreSurroundingSpaces(boolean);
    public CSVFormat withNullString(String);
    public CSVFormat withQuote(char);
    public CSVFormat withQuote(Character);
    public CSVFormat withQuoteMode(QuoteMode);
    public CSVFormat withRecordSeparator(char);
    public CSVFormat withRecordSeparator(String);
    public CSVFormat withSkipHeaderRecord();
    public CSVFormat withSkipHeaderRecord(boolean);
    public CSVFormat withSystemRecordSeparator();
    public CSVFormat withTrailingDelimiter();
    public CSVFormat withTrailingDelimiter(boolean);
    public CSVFormat withTrim();
    public CSVFormat withTrim(boolean)
}
```
@input{existing test class}
```Java
<initial_class>
```


@input{context information}

api document of class org.apache.commons.csv.CSVFormat: 

 * Specifies the format of a CSV file for parsing and writing.
 *
 * <h2>Using predefined formats</h2>
 *
 * <p>
 * You can use one of the predefined formats:
 * </p>
 *
 * <ul>
 * <li>{@link #DEFAULT}</li>
 * <li>{@link #EXCEL}</li>
 * <li>{@link #INFORMIX_UNLOAD}</li>
 * <li>{@link #INFORMIX_UNLOAD_CSV}</li>
 * <li>{@link #MONGODB_CSV}</li>
 * <li>{@link #MONGODB_TSV}</li>
 * <li>{@link #MYSQL}</li>
 * <li>{@link #ORACLE}</li>
 * <li>{@link #POSTGRESQL_CSV}</li>
 * <li>{@link #POSTGRESQL_TEXT}</li>
 * <li>{@link #RFC4180}</li>
 * <li>{@link #TDF}</li>
 * </ul>
 *
 * <p>
 * For example:
 * </p>
 *
 * <pre>
 * CSVParser parser = CSVFormat.EXCEL.parse(reader);
 * </pre>
 *
 * <p>
 * The {@link CSVParser} provides static methods to parse other input types, for example:
 * </p>
 *
 * <pre>
 * CSVParser parser = CSVParser.parse(file, StandardCharsets.US_ASCII, CSVFormat.EXCEL);
 * </pre>
 *
 * <h2>Defining formats</h2>
 *
 * <p>
 * You can extend a format by calling the {@code set} methods. For example:
 * </p>
 *
 * <pre>{@code
 * CSVFormat.EXCEL.builder().setNullString("N/A").setIgnoreSurroundingSpaces(true).get();
 * }</pre>
 *
 * <h2>Defining column names</h2>
 *
 * <p>
 * To define the column names you want to use to access records, write:
 * </p>
 *
 * <pre>{@code
 * CSVFormat.EXCEL.builder().setHeader("Col1", "Col2", "Col3").get();
 * }</pre>
 *
 * <p>
 * Calling {@link Builder#setHeader(String...)} lets you use the given names to address values in a {@link CSVRecord}, and assumes that your CSV source does not
 * contain a first record that also defines column names.
 *
 * If it does, then you are overriding this metadata with your names and you should skip the first record by calling
 * {@link Builder#setSkipHeaderRecord(boolean)} with {@code true}.
 * </p>
 *
 * <h2>Parsing</h2>
 *
 * <p>
 * You can use a format directly to parse a reader. For example, to parse an Excel file with columns header, write:
 * </p>
 *
 * <pre>{@code
 * Reader in = ...;
 * CSVFormat.EXCEL.builder().setHeader("Col1", "Col2", "Col3").get().parse(in);
 * }</pre>
 *
 * <p>
 * For other input types, like resources, files, and URLs, use the static methods on {@link CSVParser}.
 * </p>
 *
 * <h2>Referencing columns safely</h2>
 *
 * <p>
 * If your source contains a header record, you can simplify your code and safely reference columns, by using {@link Builder#setHeader(String...)} with no
 * arguments:
 * </p>
 *
 * <pre>
 * CSVFormat.EXCEL.builder().setHeader().get();
 * </pre>
 *
 * <p>
 * This causes the parser to read the first record and use its values as column names.
 *
 * Then, call one of the {@link CSVRecord} get method that takes a String column name argument:
 * </p>
 *
 * <pre>{@code
 * String value = record.get("Col1");
 * }</pre>
 *
 * <p>
 * This makes your code impervious to changes in column order in the CSV file.
 * </p>
 *
 * <h2>Serialization</h2>
 * <p>
 * This class implements the {@link Serializable} interface with the following caveats:
 * </p>
 * <ul>
 * <li>This class will no longer implement Serializable in 2.0.</li>
 * <li>Serialization is not supported from one version to the next.</li>
 * </ul>
 * <p>
 * The {@code serialVersionUID} values are:
 * </p>
 * <ul>
 * <li>Version 1.10.0: {@code 2L}</li>
 * <li>Version 1.9.0 through 1.0: {@code 1L}</li>
 * </ul>
 *
 * <h2>Notes</h2>
 * <p>
 * This class is immutable.
 * </p>
 * <p>
 * Not all settings are used for both parsing and writing.
 * </p>
 

calling methods: 
method: java.lang.StringBuilder.append(java.lang.Object), return: java.lang.StringBuilder
method: org.apache.commons.csv.CSVFormat.getIgnoreSurroundingSpaces(), return: boolean
method: java.lang.StringBuilder.append(boolean), return: java.lang.StringBuilder
method: java.lang.StringBuilder.append(java.lang.String), return: java.lang.StringBuilder
method: org.apache.commons.csv.CSVFormat.isEscapeCharacterSet(), return: boolean
method: org.apache.commons.csv.CSVFormat.isQuoteCharacterSet(), return: boolean
method: org.apache.commons.csv.CSVFormat.getIgnoreHeaderCase(), return: boolean
method: java.lang.StringBuilder.toString(), return: java.lang.String
method: java.util.Arrays.toString(java.lang.Object[]), return: java.lang.String
method: org.apache.commons.csv.CSVFormat.isNullStringSet(), return: boolean
method: org.apache.commons.csv.CSVFormat.getIgnoreEmptyLines(), return: boolean
method: java.lang.StringBuilder.append(char), return: java.lang.StringBuilder
method: org.apache.commons.csv.CSVFormat.isCommentMarkerSet(), return: boolean


@output{test class}: complete by you