You are a professional Java developer. I will provide you with a Java class with its context and a test class template. Your task is to generate a test class framework for this class based on the template. You don't need to generate test cases, just complete the functions in the template.

Please analyze the following information and help me complete the test class template:

1. The target class and its constructor parameters
2. Field declarations and their types
3. Dependencies and external resources used by the class

Requirements:
1. Complete the setupBeforeAll(), setupBeforeEach(), teardownAfterEach(), and teardownAfterAll() methods
2. Initialize necessary fields and dependencies
3. Handle any required cleanup
4. Ensure the generated code has no syntax errors

Please provide the completed test class template with proper field declarations and setup/teardown methods.

@input{focused method}
```java
 Token parseEncapsulatedToken(final Token token) throws IOException{
    //    private Token parseEncapsulatedToken(final Token token) throws IOException {
    token.isQuoted = true;
    // Save current line number in case needed for IOE
    final long startLineNumber = getCurrentLineNumber();
    int c;
    while (true) {
        c = reader.read();
        if (isQuoteChar(c)) {
            if (isQuoteChar(reader.peek())) {
                // double or escaped encapsulator -> add single encapsulator to token
                c = reader.read();
                token.content.append((char) c);
            } else {
                // token finish mark (encapsulator) reached: ignore whitespace till delimiter
                while (true) {
                    c = reader.read();
                    if (isDelimiter(c)) {
                        token.type = Token.Type.TOKEN;
                        return token;
                    }
                    if (isEndOfFile(c)) {
                        token.type = Token.Type.EOF;
                        // There is data at EOF
                        token.isReady = true;
                        return token;
                    }
                    if (readEndOfLine(c)) {
                        token.type = Token.Type.EORECORD;
                        return token;
                    }
                    if (trailingData) {
                        token.content.append((char) c);
                    } else if (!Character.isWhitespace((char) c)) {
                        // error invalid char between token and next delimiter
                        throw new CSVException("Invalid character between encapsulated token and delimiter at line: %,d, position: %,d", getCurrentLineNumber(), getCharacterPosition());
                    }
                }
            }
        } else if (isEscape(c)) {
            appendNextEscapedCharacterToToken(token);
        } else if (isEndOfFile(c)) {
            if (lenientEof) {
                token.type = Token.Type.EOF;
                // There is data at EOF
                token.isReady = true;
                return token;
            }
            // error condition (end of file before end of token)
            throw new CSVException("(startline %,d) EOF reached before encapsulated token finished", startLineNumber);
        } else {
            // consume character
            token.content.append((char) c);
        }
    }
}
```

@input{target class}
```java
package org.apache.commons.csv;

import static org.apache.commons.io.IOUtils.EOF;
import java.io.Closeable;
import java.io.IOException;
import org.apache.commons.io.IOUtils;

final class Lexer implements Closeable {
    private static final String CR_STRING = Character.toString(Constants.CR);
    private static final String LF_STRING = Character.toString(Constants.LF);
    //    private final char[] delimiter;
char[] delimiter;
    private final char[] delimiterBuf;
    private final char[] escapeDelimiterBuf;
    private final int escape;
    private final int quoteChar;
    private final int commentStart;
    private final boolean ignoreSurroundingSpaces;
    private final boolean ignoreEmptyLines;
    private final boolean lenientEof;
    private final boolean trailingData;
    private final ExtendedBufferedReader reader;
    private String firstEol;
    private boolean isLastTokenDelimiter;
     Lexer(final CSVFormat format, final ExtendedBufferedReader reader);
     void appendNextEscapedCharacterToToken(Token) throws IOException;
    public void close() throws IOException;
     long getBytesRead();
     long getCharacterPosition();
     long getCurrentLineNumber();
     String getFirstEol();
     boolean isClosed();
     boolean isCommentStart(int);
     boolean isDelimiter(int) throws IOException;
     boolean isEndOfFile(int);
     boolean isEscape(int);
     boolean isEscapeDelimiter() throws IOException;
    private boolean isMetaChar(int);
     boolean isQuoteChar(int);
     boolean isStartOfLine(int);
     Token nextToken(Token) throws IOException;
    private int nullToDisabled(Character);
     Token parseEncapsulatedToken(Token) throws IOException;
    private Token parseSimpleToken(Token, int) throws IOException;
     boolean readEndOfLine(int) throws IOException;
     int readEscape() throws IOException;
     void trimTrailingSpaces(StringBuilder)
}
```

@input{context information}

constructors for class `org.apache.commons.csv.Lexer`: 
```java
params: org.apache.commons.csv.CSVFormat format 
org.apache.commons.csv.ExtendedBufferedReader reader 
body:
```java
 Lexer(final CSVFormat format, final ExtendedBufferedReader reader)
{
    this.reader = reader;
    this.delimiter = format.getDelimiterCharArray();
    this.escape = nullToDisabled(format.getEscapeCharacter());
    this.quoteChar = nullToDisabled(format.getQuoteCharacter());
    this.commentStart = nullToDisabled(format.getCommentMarker());
    this.ignoreSurroundingSpaces = format.getIgnoreSurroundingSpaces();
    this.ignoreEmptyLines = format.getIgnoreEmptyLines();
    this.lenientEof = format.getLenientEof();
    this.trailingData = format.getTrailingData();
    this.delimiterBuf = new char[delimiter.length - 1];
    this.escapeDelimiterBuf = new char[2 * delimiter.length - 1];
}
```
```

api document of class org.apache.commons.csv.Lexer: 

 * Lexical analyzer.
 


@input{test class template}
```java
package org.apache.commons.csv;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.*;
import static org.mockito.Mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
// Add other imports if necessary

@ExtendWith(MockitoExtension.class)
class LexerTest {
    @BeforeAll
    static void setupBeforeAll() {
    }

    @BeforeEach
    void setupBeforeEach() {
    }

    @AfterEach
    void teardownAfterEach() {
    }

    @AfterAll
    static void teardownAfterAll() {
    }
}
```

@output{initial test class}: completed by you