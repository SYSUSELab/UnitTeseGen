You are a professional Java software testing expert. I need you to help me generate high-quality unit test code for a focused method.

I will provide you with:
1. The focused method needs testing
2. Basic information of target class to which the focus method belongs
3. The existing test class structure
4. The context information for generate tests

Please generate unit test code that meets these requirements:

1. Test Coverage Requirements: 
    - Generate test cases to cover all condition branches in the target method
    - Test boundary conditions and edge cases.
2. Code Quality Requirements: 
    - Follow testing best practices and patterns
    - Use clear and descriptive test method names
    - Add detailed comments explaining test scenarios
    - Make the test code easy to understand and maintain.
3. Test Structure:
    - Follow the existing test class, and appropriate test frameworks and assertions
    - Properly set up test fixtures and dependencies
    - Clean up resources after tests
    - Divide test cases into different functions logically
4. Additional Guidelines:
- Mock external dependencies when needed
- Include error/exception test cases
- Validate both expected outputs 

@input{focused method}
```Java
 Token parseEncapsulatedToken(final Token token) throws IOException{
    //    private Token parseEncapsulatedToken(final Token token) throws IOException {
    token.isQuoted = true;
    // Save current line number in case needed for IOE
    final long startLineNumber = getCurrentLineNumber();
    int c;
    while (true) {
        c = reader.read();
        if (isQuoteChar(c)) {
            if (isQuoteChar(reader.peek())) {
                // double or escaped encapsulator -> add single encapsulator to token
                c = reader.read();
                token.content.append((char) c);
            } else {
                // token finish mark (encapsulator) reached: ignore whitespace till delimiter
                while (true) {
                    c = reader.read();
                    if (isDelimiter(c)) {
                        token.type = Token.Type.TOKEN;
                        return token;
                    }
                    if (isEndOfFile(c)) {
                        token.type = Token.Type.EOF;
                        // There is data at EOF
                        token.isReady = true;
                        return token;
                    }
                    if (readEndOfLine(c)) {
                        token.type = Token.Type.EORECORD;
                        return token;
                    }
                    if (trailingData) {
                        token.content.append((char) c);
                    } else if (!Character.isWhitespace((char) c)) {
                        // error invalid char between token and next delimiter
                        throw new CSVException("Invalid character between encapsulated token and delimiter at line: %,d, position: %,d", getCurrentLineNumber(), getCharacterPosition());
                    }
                }
            }
        } else if (isEscape(c)) {
            appendNextEscapedCharacterToToken(token);
        } else if (isEndOfFile(c)) {
            if (lenientEof) {
                token.type = Token.Type.EOF;
                // There is data at EOF
                token.isReady = true;
                return token;
            }
            // error condition (end of file before end of token)
            throw new CSVException("(startline %,d) EOF reached before encapsulated token finished", startLineNumber);
        } else {
            // consume character
            token.content.append((char) c);
        }
    }
}
```

@input{target class}
```Java
package org.apache.commons.csv;

import static org.apache.commons.io.IOUtils.EOF;
import java.io.Closeable;
import java.io.IOException;
import org.apache.commons.io.IOUtils;

final class Lexer implements Closeable {
    private static final String CR_STRING = Character.toString(Constants.CR);
    private static final String LF_STRING = Character.toString(Constants.LF);
    //    private final char[] delimiter;
char[] delimiter;
    private final char[] delimiterBuf;
    private final char[] escapeDelimiterBuf;
    private final int escape;
    private final int quoteChar;
    private final int commentStart;
    private final boolean ignoreSurroundingSpaces;
    private final boolean ignoreEmptyLines;
    private final boolean lenientEof;
    private final boolean trailingData;
    private final ExtendedBufferedReader reader;
    private String firstEol;
    private boolean isLastTokenDelimiter;
     Lexer(final CSVFormat format, final ExtendedBufferedReader reader);
     void appendNextEscapedCharacterToToken(Token) throws IOException;
    public void close() throws IOException;
     long getBytesRead();
     long getCharacterPosition();
     long getCurrentLineNumber();
     String getFirstEol();
     boolean isClosed();
     boolean isCommentStart(int);
     boolean isDelimiter(int) throws IOException;
     boolean isEndOfFile(int);
     boolean isEscape(int);
     boolean isEscapeDelimiter() throws IOException;
    private boolean isMetaChar(int);
     boolean isQuoteChar(int);
     boolean isStartOfLine(int);
     Token nextToken(Token) throws IOException;
    private int nullToDisabled(Character);
     Token parseEncapsulatedToken(Token) throws IOException;
    private Token parseSimpleToken(Token, int) throws IOException;
     boolean readEndOfLine(int) throws IOException;
     int readEscape() throws IOException;
     void trimTrailingSpaces(StringBuilder)
}
```
@input{existing test class}
```Java
<initial_class>
```


@input{context information}

api document of class org.apache.commons.csv.Lexer: 

 * Lexical analyzer.
 

api document of method parseEncapsulatedToken(Token): 

     * Parses an encapsulated token.
     * <p>
     * Encapsulated tokens are surrounded by the given encapsulating string. The encapsulator itself might be included
     * in the token using a doubling syntax (as "", '') or using escaping (as in \", \'). Whitespaces before and after
     * an encapsulated token is ignored. The token is finished when one of the following conditions becomes true:
     * </p>
     * <ul>
     * <li>An unescaped encapsulator has been reached and is followed by optional whitespace then:</li>
     * <ul>
     * <li>delimiter (TOKEN)</li>
     * <li>end of line (EORECORD)</li>
     * </ul>
     * <li>end of stream has been reached (EOF)</li> </ul>
     *
     * @param token
     *            the current token
     * @return a valid token object
     * @throws IOException
     *             Thrown when in an invalid state: EOF before closing encapsulator or invalid character before
     *             delimiter or EOL.
     * @throws CSVException Thrown on invalid input.
     

parameters: 
org.apache.commons.csv.Token token 

calling methods: 
method: org.apache.commons.io.input.UnsynchronizedBufferedReader.peek(), return: int
method: org.apache.commons.csv.Lexer.getCharacterPosition(), return: long
method: org.apache.commons.csv.ExtendedBufferedReader.read(), return: int
method: org.apache.commons.csv.Lexer.readEndOfLine(int), return: boolean
method: org.apache.commons.csv.Lexer.isEndOfFile(int), return: boolean
method: org.apache.commons.csv.Lexer.isDelimiter(int), return: boolean
method: org.apache.commons.csv.Lexer.appendNextEscapedCharacterToToken(org.apache.commons.csv.Token), return: void
method: java.lang.Character.isWhitespace(char), return: boolean
method: java.lang.StringBuilder.append(char), return: java.lang.StringBuilder
method: org.apache.commons.csv.Lexer.isEscape(int), return: boolean
method: org.apache.commons.csv.Lexer.getCurrentLineNumber(), return: long
method: org.apache.commons.csv.Lexer.isQuoteChar(int), return: boolean


@output{test class}: complete by you