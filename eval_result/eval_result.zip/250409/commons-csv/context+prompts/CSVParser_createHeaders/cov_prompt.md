You are a professional Java software testing expert. I need you to help me generate high-quality unit test code for a focused method.

I will provide you with:
1. The focused method needs testing
2. Basic information of target class to which the focus method belongs
3. The existing test class structure
4. The context information for generate tests

Please generate unit test code that meets these requirements:

1. Test Coverage Requirements: 
    - Generate test cases to cover all condition branches in the target method
    - Test boundary conditions and edge cases.
2. Code Quality Requirements: 
    - Follow testing best practices and patterns
    - Use clear and descriptive test method names
    - Add detailed comments explaining test scenarios
    - Make the test code easy to understand and maintain.
3. Test Structure:
    - Follow the existing test class, and appropriate test frameworks and assertions
    - Properly set up test fixtures and dependencies
    - Clean up resources after tests
    - Divide test cases into different functions logically
4. Additional Guidelines:
- Mock external dependencies when needed
- Include error/exception test cases
- Validate both expected outputs 

@input{focused method}
```Java
private Headers createHeaders() throws IOException{
    Map<String, Integer> hdrMap = null;
    List<String> headerNames = null;
    final String[] formatHeader = format.getHeader();
    if (formatHeader != null) {
        hdrMap = createEmptyHeaderMap();
        String[] headerRecord = null;
        if (formatHeader.length == 0) {
            // read the header from the first line of the file
            final CSVRecord nextRecord = nextRecord();
            if (nextRecord != null) {
                headerRecord = nextRecord.values();
                headerComment = nextRecord.getComment();
            }
        } else {
            if (format.getSkipHeaderRecord()) {
                final CSVRecord nextRecord = nextRecord();
                if (nextRecord != null) {
                    headerComment = nextRecord.getComment();
                }
            }
            headerRecord = formatHeader;
        }
        // build the name to index mappings
        if (headerRecord != null) {
            // Track an occurrence of a null, empty or blank header.
            boolean observedMissing = false;
            for (int i = 0; i < headerRecord.length; i++) {
                final String header = headerRecord[i];
                final boolean blankHeader = CSVFormat.isBlank(header);
                if (blankHeader && !format.getAllowMissingColumnNames()) {
                    throw new IllegalArgumentException("A header name is missing in " + Arrays.toString(headerRecord));
                }
                final boolean containsHeader = blankHeader ? observedMissing : hdrMap.containsKey(header);
                final DuplicateHeaderMode headerMode = format.getDuplicateHeaderMode();
                final boolean duplicatesAllowed = headerMode == DuplicateHeaderMode.ALLOW_ALL;
                final boolean emptyDuplicatesAllowed = headerMode == DuplicateHeaderMode.ALLOW_EMPTY;
                if (containsHeader && !duplicatesAllowed && !(blankHeader && emptyDuplicatesAllowed)) {
                    throw new IllegalArgumentException(String.format("The header contains a duplicate name: \"%s\" in %s. If this is valid then use CSVFormat.Builder.setDuplicateHeaderMode().", header, Arrays.toString(headerRecord)));
                }
                observedMissing |= blankHeader;
                if (header != null) {
                    // N.B. Explicit (un)boxing is intentional
                    hdrMap.put(header, Integer.valueOf(i));
                    if (headerNames == null) {
                        headerNames = new ArrayList<>(headerRecord.length);
                    }
                    headerNames.add(header);
                }
            }
        }
    }
    // Make header names Collection immutable
    return new Headers(hdrMap, headerNames == null ? Collections.emptyList() : Collections.unmodifiableList(headerNames));
}
```

@input{target class}
```Java
package org.apache.commons.csv;

import static org.apache.commons.csv.Token.Type.TOKEN;
import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.io.UncheckedIOException;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.Spliterator;
import java.util.Spliterators;
import java.util.TreeMap;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import org.apache.commons.io.build.AbstractStreamBuilder;
import org.apache.commons.io.function.Uncheck;

public final class CSVParser implements Iterable<CSVRecord>, Closeable {
    private String headerComment;
    private String trailerComment;
    private final CSVFormat format;
    private final Headers headers;
    private final Lexer lexer;
    private final CSVRecordIterator csvRecordIterator;
    private final List<String> recordList = new ArrayList<>();
    private long recordNumber;
    private final long characterOffset;
    private final Token reusableToken = new Token();
    public CSVParser(final Reader reader, final CSVFormat format) throws IOException;
    public CSVParser(final Reader reader, final CSVFormat format, final long characterOffset, final long recordNumber) throws IOException;
    private CSVParser(final Reader reader, final CSVFormat format, final long characterOffset, final long recordNumber, final Charset charset, final boolean trackBytes) throws IOException;
    public static Builder builder();
    public static CSVParser parse(File, Charset, CSVFormat) throws IOException;
    public static CSVParser parse(InputStream, Charset, CSVFormat) throws IOException;
    public static CSVParser parse(Path, Charset, CSVFormat) throws IOException;
    public static CSVParser parse(Reader, CSVFormat) throws IOException;
    public static CSVParser parse(String, CSVFormat) throws IOException;
    public static CSVParser parse(URL, Charset, CSVFormat) throws IOException;
    private void addRecordValue(boolean);
    public void close() throws IOException;
    private Map<String, Integer> createEmptyHeaderMap();
    private Headers createHeaders() throws IOException;
    public long getCurrentLineNumber();
    public String getFirstEndOfLine();
    public String getHeaderComment();
    public Map<String, Integer> getHeaderMap();
     Map<String, Integer> getHeaderMapRaw();
    public List<String> getHeaderNames();
    public long getRecordNumber();
    public List<CSVRecord> getRecords();
    public String getTrailerComment();
    private String handleNull(String);
    public boolean hasHeaderComment();
    public boolean hasTrailerComment();
    public boolean isClosed();
    private boolean isStrictQuoteMode();
    public Iterator<CSVRecord> iterator();
     CSVRecord nextRecord() throws IOException;
    public Stream<CSVRecord> stream()
}
```
@input{existing test class}
```Java
<initial_class>
```


@input{context information}

api document of class org.apache.commons.csv.CSVParser: 

 * Parses CSV files according to the specified format.
 *
 * Because CSV appears in many different dialects, the parser supports many formats by allowing the
 * specification of a {@link CSVFormat}.
 *
 * The parser works record-wise. It is not possible to go back, once a record has been parsed from the input stream.
 *
 * <h2>Creating instances</h2>
 * <p>
 * There are several static factory methods that can be used to create instances for various types of resources:
 * </p>
 * <ul>
 *     <li>{@link #parse(java.io.File, Charset, CSVFormat)}</li>
 *     <li>{@link #parse(String, CSVFormat)}</li>
 *     <li>{@link #parse(java.net.URL, java.nio.charset.Charset, CSVFormat)}</li>
 * </ul>
 * <p>
 * Alternatively parsers can also be created by passing a {@link Reader} directly to the sole constructor.
 *
 * For those who like fluent APIs, parsers can be created using {@link CSVFormat#parse(java.io.Reader)} as a shortcut:
 * </p>
 * <pre>
 * for (CSVRecord record : CSVFormat.EXCEL.parse(in)) {
 *     ...
 * }
 * </pre>
 *
 * <h2>Parsing record wise</h2>
 * <p>
 * To parse a CSV input from a file, you write:
 * </p>
 *
 * <pre>{@code
 * File csvData = new File("/path/to/csv");
 * CSVParser parser = CSVParser.parse(csvData, CSVFormat.RFC4180);
 * for (CSVRecord csvRecord : parser) {
 *     ...
 * }}
 * </pre>
 *
 * <p>
 * This will read the parse the contents of the file using the
 * <a href="https://tools.ietf.org/html/rfc4180" target="_blank">RFC 4180</a> format.
 * </p>
 *
 * <p>
 * To parse CSV input in a format like Excel, you write:
 * </p>
 *
 * <pre>
 * CSVParser parser = CSVParser.parse(csvData, CSVFormat.EXCEL);
 * for (CSVRecord csvRecord : parser) {
 *     ...
 * }
 * </pre>
 *
 * <p>
 * If the predefined formats don't match the format at hand, custom formats can be defined. More information about
 * customizing CSVFormats is available in {@link CSVFormat CSVFormat Javadoc}.
 * </p>
 *
 * <h2>Parsing into memory</h2>
 * <p>
 * If parsing record-wise is not desired, the contents of the input can be read completely into memory.
 * </p>
 *
 * <pre>{@code
 * Reader in = new StringReader("a;b\nc;d");
 * CSVParser parser = new CSVParser(in, CSVFormat.EXCEL);
 * List<CSVRecord> list = parser.getRecords();
 * }</pre>
 *
 * <p>
 * There are two constraints that have to be kept in mind:
 * </p>
 *
 * <ol>
 *     <li>Parsing into memory starts at the current position of the parser. If you have already parsed records from
 *     the input, those records will not end up in the in-memory representation of your CSV data.</li>
 *     <li>Parsing into memory may consume a lot of system resources depending on the input. For example, if you're
 *     parsing a 150MB file of CSV data the contents will be read completely into memory.</li>
 * </ol>
 *
 * <h2>Notes</h2>
 * <p>
 * The internal parser state is completely covered by the format and the reader state.
 * </p>
 *
 * @see <a href="package-summary.html">package documentation for more details</a>
 

api document of method createHeaders(): 

     * Creates the name to index mapping if the format defines a header.
     *
     * @return null if the format has no header.
     * @throws IOException if there is a problem reading the header or skipping the first record
     * @throws CSVException on invalid input.
     

calling methods: 
method: java.util.Map.put(K, V), return: V
method: org.apache.commons.csv.CSVRecord.values(), return: java.lang.String[]
method: java.util.List.add(E), return: boolean
method: org.apache.commons.csv.CSVFormat.getDuplicateHeaderMode(), return: org.apache.commons.csv.DuplicateHeaderMode
method: java.util.Collections.unmodifiableList(java.util.List<? extends T>), return: java.util.List<T>
method: org.apache.commons.csv.CSVParser.createEmptyHeaderMap(), return: java.util.Map<java.lang.String, java.lang.Integer>
method: org.apache.commons.csv.CSVRecord.getComment(), return: java.lang.String
method: java.lang.String.format(java.lang.String, java.lang.Object...), return: java.lang.String
method: org.apache.commons.csv.CSVFormat.getAllowMissingColumnNames(), return: boolean
method: java.util.Arrays.toString(java.lang.Object[]), return: java.lang.String
method: java.util.Collections.emptyList(), return: java.util.List<T>
method: org.apache.commons.csv.CSVParser.nextRecord(), return: org.apache.commons.csv.CSVRecord
method: org.apache.commons.csv.CSVFormat.isBlank(java.lang.String), return: boolean
method: java.lang.Integer.valueOf(int), return: java.lang.Integer
method: org.apache.commons.csv.CSVFormat.getSkipHeaderRecord(), return: boolean
method: org.apache.commons.csv.CSVFormat.getHeader(), return: java.lang.String[]
method: java.util.Map.containsKey(java.lang.Object), return: boolean


@output{test class}: complete by you