You are a professional Java software testing expert. I need you to help me generate high-quality unit test code for a focused method.

I will provide you with:
1. The focused method needs testing
2. Basic information of target class to which the focus method belongs
3. The existing test class structure
4. The context information for generate tests

Please generate unit test code that meets these requirements:

1. Test Coverage Requirements: 
    - Generate test cases to cover all condition branches in the target method
    - Test boundary conditions and edge cases.
2. Code Quality Requirements: 
    - Follow testing best practices and patterns
    - Use clear and descriptive test method names
    - Add detailed comments explaining test scenarios
    - Make the test code easy to understand and maintain.
3. Test Structure:
    - Follow the existing test class, and appropriate test frameworks and assertions
    - Properly set up test fixtures and dependencies
    - Clean up resources after tests
    - Divide test cases into different functions logically
4. Additional Guidelines:
- Mock external dependencies when needed
- Include error/exception test cases
- Validate both expected outputs 

@input{focused method}
```Java
 Token nextToken(final Token token) throws IOException{
    // Get the last read char (required for empty line detection)
    int lastChar = reader.getLastChar();
    // read the next char and set eol
    int c = reader.read();
    // Note: The following call will swallow LF if c == CR. But we don't need to know if the last char was CR or LF - they are equivalent here.
    boolean eol = readEndOfLine(c);
    // empty line detection: eol AND (last char was EOL or beginning)
    if (ignoreEmptyLines) {
        while (eol && isStartOfLine(lastChar)) {
            // Go on char ahead ...
            lastChar = c;
            c = reader.read();
            eol = readEndOfLine(c);
            // reached the end of the file without any content (empty line at the end)
            if (isEndOfFile(c)) {
                token.type = Token.Type.EOF;
                // don't set token.isReady here because no content
                return token;
            }
        }
    }
    // Did we reach EOF during the last iteration already? EOF
    if (isEndOfFile(lastChar) || !isLastTokenDelimiter && isEndOfFile(c)) {
        token.type = Token.Type.EOF;
        // don't set token.isReady here because no content
        return token;
    }
    if (isStartOfLine(lastChar) && isCommentStart(c)) {
        final String line = reader.readLine();
        if (line == null) {
            token.type = Token.Type.EOF;
            // don't set token.isReady here because no content
            return token;
        }
        final String comment = line.trim();
        token.content.append(comment);
        token.type = Token.Type.COMMENT;
        return token;
    }
    // Important: make sure a new char gets consumed in each iteration
    while (token.type == Token.Type.INVALID) {
        // ignore whitespaces at beginning of a token
        if (ignoreSurroundingSpaces) {
            while (Character.isWhitespace((char) c) && !isDelimiter(c) && !eol) {
                c = reader.read();
                eol = readEndOfLine(c);
            }
        }
        // ok, start of token reached: encapsulated, or token
        if (isDelimiter(c)) {
            // empty token return TOKEN("")
            token.type = Token.Type.TOKEN;
        } else if (eol) {
            // empty token return EORECORD("")
            // noop: token.content.append("");
            token.type = Token.Type.EORECORD;
        } else if (isQuoteChar(c)) {
            // consume encapsulated token
            parseEncapsulatedToken(token);
        } else if (isEndOfFile(c)) {
            // end of file return EOF()
            // noop: token.content.append("");
            token.type = Token.Type.EOF;
            // there is data at EOF
            token.isReady = true;
        } else {
            // next token must be a simple token
            // add removed blanks when not ignoring whitespace chars...
            parseSimpleToken(token, c);
        }
    }
    return token;
}
```

@input{target class}
```Java
package org.apache.commons.csv;

import static org.apache.commons.io.IOUtils.EOF;
import java.io.Closeable;
import java.io.IOException;
import org.apache.commons.io.IOUtils;

final class Lexer implements Closeable {
    private static final String CR_STRING = Character.toString(Constants.CR);
    private static final String LF_STRING = Character.toString(Constants.LF);
    //    private final char[] delimiter;
char[] delimiter;
    private final char[] delimiterBuf;
    private final char[] escapeDelimiterBuf;
    private final int escape;
    private final int quoteChar;
    private final int commentStart;
    private final boolean ignoreSurroundingSpaces;
    private final boolean ignoreEmptyLines;
    private final boolean lenientEof;
    private final boolean trailingData;
    private final ExtendedBufferedReader reader;
    private String firstEol;
    private boolean isLastTokenDelimiter;
     Lexer(final CSVFormat format, final ExtendedBufferedReader reader);
     void appendNextEscapedCharacterToToken(Token) throws IOException;
    public void close() throws IOException;
     long getBytesRead();
     long getCharacterPosition();
     long getCurrentLineNumber();
     String getFirstEol();
     boolean isClosed();
     boolean isCommentStart(int);
     boolean isDelimiter(int) throws IOException;
     boolean isEndOfFile(int);
     boolean isEscape(int);
     boolean isEscapeDelimiter() throws IOException;
    private boolean isMetaChar(int);
     boolean isQuoteChar(int);
     boolean isStartOfLine(int);
     Token nextToken(Token) throws IOException;
    private int nullToDisabled(Character);
     Token parseEncapsulatedToken(Token) throws IOException;
    private Token parseSimpleToken(Token, int) throws IOException;
     boolean readEndOfLine(int) throws IOException;
     int readEscape() throws IOException;
     void trimTrailingSpaces(StringBuilder)
}
```
@input{existing test class}
```Java
<initial_class>
```


@input{context information}

api document of class org.apache.commons.csv.Lexer: 

 * Lexical analyzer.
 

api document of method nextToken(Token): 

     * Returns the next token.
     * <p>
     * A token corresponds to a term, a record change or an end-of-file indicator.
     * </p>
     *
     * @param token an existing Token object to reuse. The caller is responsible for initializing the Token.
     * @return the next token found.
     * @throws IOException  on stream access error.
     * @throws CSVException Thrown on invalid input.
     

parameters: 
org.apache.commons.csv.Token token 

calling methods: 
method: org.apache.commons.csv.Lexer.readEndOfLine(int), return: boolean
method: org.apache.commons.csv.Lexer.isDelimiter(int), return: boolean
method: org.apache.commons.csv.ExtendedBufferedReader.getLastChar(), return: int
method: java.lang.StringBuilder.append(java.lang.String), return: java.lang.StringBuilder
method: org.apache.commons.csv.Lexer.parseEncapsulatedToken(org.apache.commons.csv.Token), return: org.apache.commons.csv.Token
method: org.apache.commons.csv.ExtendedBufferedReader.readLine(), return: java.lang.String
method: org.apache.commons.csv.Lexer.parseSimpleToken(org.apache.commons.csv.Token, int), return: org.apache.commons.csv.Token
method: org.apache.commons.csv.Lexer.isCommentStart(int), return: boolean
method: org.apache.commons.csv.Lexer.isQuoteChar(int), return: boolean
method: org.apache.commons.csv.Lexer.isStartOfLine(int), return: boolean
method: org.apache.commons.csv.ExtendedBufferedReader.read(), return: int
method: java.lang.String.trim(), return: java.lang.String
method: org.apache.commons.csv.Lexer.isEndOfFile(int), return: boolean
method: java.lang.Character.isWhitespace(char), return: boolean


@output{test class}: complete by you