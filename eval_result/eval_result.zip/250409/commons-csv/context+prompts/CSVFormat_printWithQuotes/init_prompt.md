You are a professional Java developer. I will provide you with a Java class with its context and a test class template. Your task is to generate a test class framework for this class based on the template. You don't need to generate test cases, just complete the functions in the template.

Please analyze the following information and help me complete the test class template:

1. The target class and its constructor parameters
2. Field declarations and their types
3. Dependencies and external resources used by the class

Requirements:
1. Complete the setupBeforeAll(), setupBeforeEach(), teardownAfterEach(), and teardownAfterAll() methods
2. Initialize necessary fields and dependencies
3. Handle any required cleanup
4. Ensure the generated code has no syntax errors

Please provide the completed test class template with proper field declarations and setup/teardown methods.

@input{focused method}
```java
private void printWithQuotes(final Object object, final CharSequence charSeq, final Appendable out, final boolean newRecord) throws IOException{
    boolean quote = false;
    int start = 0;
    int pos = 0;
    final int len = charSeq.length();
    final char[] delim = getDelimiterCharArray();
    final int delimLength = delim.length;
    // N.B. Explicit (un)boxing is intentional
    final char quoteChar = getQuoteCharacter().charValue();
    // If escape char not specified, default to the quote char
    // This avoids having to keep checking whether there is an escape character
    // at the cost of checking against quote twice
    final char escapeChar = isEscapeCharacterSet() ? getEscapeChar() : quoteChar;
    QuoteMode quoteModePolicy = getQuoteMode();
    if (quoteModePolicy == null) {
        quoteModePolicy = QuoteMode.MINIMAL;
    }
    switch(quoteModePolicy) {
        case ALL:
        case ALL_NON_NULL:
            quote = true;
            break;
        case NON_NUMERIC:
            quote = !(object instanceof Number);
            break;
        case NONE:
            // Use the existing escaping code
            printWithEscapes(charSeq, out);
            return;
        case MINIMAL:
            if (len <= 0) {
                // Always quote an empty token that is the first
                // on the line, as it may be the only thing on the
                // line. If it were not quoted in that case,
                // an empty line has no tokens.
                if (newRecord) {
                    quote = true;
                }
            } else {
                char c = charSeq.charAt(pos);
                if (c <= Constants.COMMENT) {
                    // Some other chars at the start of a value caused the parser to fail, so for now
                    // encapsulate if we start in anything less than '#'. We are being conservative
                    // by including the default comment char too.
                    quote = true;
                } else {
                    while (pos < len) {
                        c = charSeq.charAt(pos);
                        if (c == Constants.LF || c == Constants.CR || c == quoteChar || c == escapeChar || isDelimiter(c, charSeq, pos, delim, delimLength)) {
                            quote = true;
                            break;
                        }
                        pos++;
                    }
                    if (!quote) {
                        pos = len - 1;
                        c = charSeq.charAt(pos);
                        // Some other chars at the end caused the parser to fail, so for now
                        // encapsulate if we end in anything less than ' '
                        if (isTrimChar(c)) {
                            quote = true;
                        }
                    }
                }
            }
            if (!quote) {
                // No encapsulation needed - write out the original value
                out.append(charSeq, start, len);
                return;
            }
            break;
        default:
            throw new IllegalStateException("Unexpected Quote value: " + quoteModePolicy);
    }
    if (!quote) {
        // No encapsulation needed - write out the original value
        out.append(charSeq, start, len);
        return;
    }
    // We hit something that needed encapsulation
    out.append(quoteChar);
    // Pick up where we left off: pos should be positioned on the first character that caused
    // the need for encapsulation.
    while (pos < len) {
        final char c = charSeq.charAt(pos);
        if (c == quoteChar || c == escapeChar) {
            // write out the chunk up until this point
            out.append(charSeq, start, pos);
            // now output the escape
            out.append(escapeChar);
            // and restart with the matched char
            start = pos;
        }
        pos++;
    }
    // Write the last segment
    out.append(charSeq, start, pos);
    out.append(quoteChar);
}
```

@input{target class}
```java
package org.apache.commons.csv;

import static org.apache.commons.io.IOUtils.EOF;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Serializable;
import java.io.StringWriter;
import java.io.Writer;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;
import org.apache.commons.codec.binary.Base64OutputStream;
import org.apache.commons.io.IOUtils;
import org.apache.commons.io.function.Uncheck;
import org.apache.commons.io.output.AppendableOutputStream;

public final class CSVFormat implements Serializable {
    public static final CSVFormat DEFAULT = new CSVFormat(Builder.create());
    public static final CSVFormat EXCEL = DEFAULT.builder().setIgnoreEmptyLines(false).setAllowMissingColumnNames(true).setTrailingData(true).setLenientEof(true).get();
    public static final CSVFormat INFORMIX_UNLOAD = DEFAULT.builder().setDelimiter(Constants.PIPE).setEscape(Constants.BACKSLASH).setQuote(Constants.DOUBLE_QUOTE_CHAR).setRecordSeparator(Constants.LF).get();
    public static final CSVFormat INFORMIX_UNLOAD_CSV = DEFAULT.builder().setDelimiter(Constants.COMMA).setQuote(Constants.DOUBLE_QUOTE_CHAR).setRecordSeparator(Constants.LF).get();
    public static final CSVFormat MONGODB_CSV = DEFAULT.builder().setDelimiter(Constants.COMMA).setEscape(Constants.DOUBLE_QUOTE_CHAR).setQuote(Constants.DOUBLE_QUOTE_CHAR).setQuoteMode(QuoteMode.MINIMAL).get();
    public static final CSVFormat MONGODB_TSV = DEFAULT.builder().setDelimiter(Constants.TAB).setEscape(Constants.DOUBLE_QUOTE_CHAR).setQuote(Constants.DOUBLE_QUOTE_CHAR).setQuoteMode(QuoteMode.MINIMAL).setSkipHeaderRecord(false).get();
    public static final CSVFormat MYSQL = DEFAULT.builder().setDelimiter(Constants.TAB).setEscape(Constants.BACKSLASH).setIgnoreEmptyLines(false).setQuote(null).setRecordSeparator(Constants.LF).setNullString(Constants.SQL_NULL_STRING).setQuoteMode(QuoteMode.ALL_NON_NULL).get();
    public static final CSVFormat ORACLE = DEFAULT.builder().setDelimiter(Constants.COMMA).setEscape(Constants.BACKSLASH).setIgnoreEmptyLines(false).setQuote(Constants.DOUBLE_QUOTE_CHAR).setNullString(Constants.SQL_NULL_STRING).setTrim(true).setRecordSeparator(System.lineSeparator()).setQuoteMode(QuoteMode.MINIMAL).get();
    public static final CSVFormat POSTGRESQL_CSV = DEFAULT.builder().setDelimiter(Constants.COMMA).setEscape(null).setIgnoreEmptyLines(false).setQuote(Constants.DOUBLE_QUOTE_CHAR).setRecordSeparator(Constants.LF).setNullString(Constants.EMPTY).setQuoteMode(QuoteMode.ALL_NON_NULL).get();
    public static final CSVFormat POSTGRESQL_TEXT = DEFAULT.builder().setDelimiter(Constants.TAB).setEscape(Constants.BACKSLASH).setIgnoreEmptyLines(false).setQuote(null).setRecordSeparator(Constants.LF).setNullString(Constants.SQL_NULL_STRING).setQuoteMode(QuoteMode.ALL_NON_NULL).get();
    public static final CSVFormat RFC4180 = DEFAULT.builder().setIgnoreEmptyLines(false).get();
    private static final long serialVersionUID = 2L;
    public static final CSVFormat TDF = DEFAULT.builder().setDelimiter(Constants.TAB).setIgnoreSurroundingSpaces(true).get();
    private final DuplicateHeaderMode duplicateHeaderMode;
    private final boolean allowMissingColumnNames;
    private final boolean autoFlush;
    private final Character commentMarker;
    private final String delimiter;
    private final Character escapeCharacter;
    private final String[] headers;
    private final String[] headerComments;
    private final boolean ignoreEmptyLines;
    private final boolean ignoreHeaderCase;
    private final boolean ignoreSurroundingSpaces;
    private final String nullString;
    private final Character quoteCharacter;
    private final String quotedNullString;
    private final QuoteMode quoteMode;
    private final String recordSeparator;
    private final boolean skipHeaderRecord;
    private final boolean lenientEof;
    private final boolean trailingData;
    private final boolean trailingDelimiter;
    private final boolean trim;
    private CSVFormat(final Builder builder);
     static T[] clone(T...);
    private static boolean contains(String, char);
    private static boolean containsLineBreak(String);
     static CSVFormat copy(CSVFormat);
     static boolean isBlank(String);
    private static boolean isLineBreak(char);
    private static boolean isLineBreak(Character);
    private static boolean isTrimChar(char);
    private static boolean isTrimChar(CharSequence, int);
    public static CSVFormat newFormat(char);
     static String[] toStringArray(Object[]);
     static CharSequence trim(CharSequence);
    public static CSVFormat valueOf(String);
    private void append(char, Appendable) throws IOException;
    private void append(CharSequence, Appendable) throws IOException;
    public Builder builder();
     CSVFormat copy();
    public boolean equals(Object);
    private void escape(char, Appendable) throws IOException;
    public String format(Object...);
    private String format_(Object...) throws IOException;
    public boolean getAllowDuplicateHeaderNames();
    public boolean getAllowMissingColumnNames();
    public boolean getAutoFlush();
    public Character getCommentMarker();
    public char getDelimiter();
     char[] getDelimiterCharArray();
    public String getDelimiterString();
    public DuplicateHeaderMode getDuplicateHeaderMode();
     char getEscapeChar();
    public Character getEscapeCharacter();
    public String[] getHeader();
    public String[] getHeaderComments();
    public boolean getIgnoreEmptyLines();
    public boolean getIgnoreHeaderCase();
    public boolean getIgnoreSurroundingSpaces();
    public boolean getLenientEof();
    public String getNullString();
    public Character getQuoteCharacter();
    public QuoteMode getQuoteMode();
    public String getRecordSeparator();
    public boolean getSkipHeaderRecord();
    public boolean getTrailingData();
    public boolean getTrailingDelimiter();
    public boolean getTrim();
    public int hashCode();
    public boolean isCommentMarkerSet();
    private boolean isDelimiter(char, CharSequence, int, char[], int);
    public boolean isEscapeCharacterSet();
    public boolean isNullStringSet();
    public boolean isQuoteCharacterSet();
    public CSVParser parse(Reader) throws IOException;
    public CSVPrinter print(Appendable) throws IOException;
    public CSVPrinter print(File, Charset) throws IOException;
    private void print(InputStream, Appendable, boolean) throws IOException;
    public synchronized void print(Object, Appendable, boolean) throws IOException;
    private synchronized void print(Object, CharSequence, Appendable, boolean) throws IOException;
    public CSVPrinter print(Path, Charset) throws IOException;
    private void print(Reader, Appendable, boolean) throws IOException;
    public CSVPrinter printer() throws IOException;
    public synchronized void println(Appendable) throws IOException;
    public synchronized void printRecord(Appendable, Object...) throws IOException;
    private void printWithEscapes(CharSequence, Appendable) throws IOException;
    private void printWithEscapes(Reader, Appendable) throws IOException;
    private void printWithQuotes(Object, CharSequence, Appendable, boolean) throws IOException;
    private void printWithQuotes(Reader, Appendable) throws IOException;
    public String toString();
     String trim(String);
    private void validate() throws IllegalArgumentException;
    public CSVFormat withAllowDuplicateHeaderNames();
    public CSVFormat withAllowDuplicateHeaderNames(boolean);
    public CSVFormat withAllowMissingColumnNames();
    public CSVFormat withAllowMissingColumnNames(boolean);
    public CSVFormat withAutoFlush(boolean);
    public CSVFormat withCommentMarker(char);
    public CSVFormat withCommentMarker(Character);
    public CSVFormat withDelimiter(char);
    public CSVFormat withEscape(char);
    public CSVFormat withEscape(Character);
    public CSVFormat withFirstRecordAsHeader();
    public CSVFormat withHeader(Class<? extends Enum<?>>);
    public CSVFormat withHeader(ResultSet) throws SQLException;
    public CSVFormat withHeader(ResultSetMetaData) throws SQLException;
    public CSVFormat withHeader(String...);
    public CSVFormat withHeaderComments(Object...);
    public CSVFormat withIgnoreEmptyLines();
    public CSVFormat withIgnoreEmptyLines(boolean);
    public CSVFormat withIgnoreHeaderCase();
    public CSVFormat withIgnoreHeaderCase(boolean);
    public CSVFormat withIgnoreSurroundingSpaces();
    public CSVFormat withIgnoreSurroundingSpaces(boolean);
    public CSVFormat withNullString(String);
    public CSVFormat withQuote(char);
    public CSVFormat withQuote(Character);
    public CSVFormat withQuoteMode(QuoteMode);
    public CSVFormat withRecordSeparator(char);
    public CSVFormat withRecordSeparator(String);
    public CSVFormat withSkipHeaderRecord();
    public CSVFormat withSkipHeaderRecord(boolean);
    public CSVFormat withSystemRecordSeparator();
    public CSVFormat withTrailingDelimiter();
    public CSVFormat withTrailingDelimiter(boolean);
    public CSVFormat withTrim();
    public CSVFormat withTrim(boolean)
}
```

@input{context information}

constructors for class `org.apache.commons.csv.CSVFormat`: 
```java
params: org.apache.commons.csv.CSVFormat.Builder builder 
body:
```java
private CSVFormat(final Builder builder)
{
    this.delimiter = builder.delimiter;
    this.quoteCharacter = builder.quoteCharacter;
    this.quoteMode = builder.quoteMode;
    this.commentMarker = builder.commentMarker;
    this.escapeCharacter = builder.escapeCharacter;
    this.ignoreSurroundingSpaces = builder.ignoreSurroundingSpaces;
    this.allowMissingColumnNames = builder.allowMissingColumnNames;
    this.ignoreEmptyLines = builder.ignoreEmptyLines;
    this.recordSeparator = builder.recordSeparator;
    this.nullString = builder.nullString;
    this.headerComments = builder.headerComments;
    this.headers = builder.headers;
    this.skipHeaderRecord = builder.skipHeaderRecord;
    this.ignoreHeaderCase = builder.ignoreHeaderCase;
    this.lenientEof = builder.lenientEof;
    this.trailingData = builder.trailingData;
    this.trailingDelimiter = builder.trailingDelimiter;
    this.trim = builder.trim;
    this.autoFlush = builder.autoFlush;
    this.quotedNullString = builder.quotedNullString;
    this.duplicateHeaderMode = builder.duplicateHeaderMode;
    validate();
}
```
```

api document of class org.apache.commons.csv.CSVFormat: 

 * Specifies the format of a CSV file for parsing and writing.
 *
 * <h2>Using predefined formats</h2>
 *
 * <p>
 * You can use one of the predefined formats:
 * </p>
 *
 * <ul>
 * <li>{@link #DEFAULT}</li>
 * <li>{@link #EXCEL}</li>
 * <li>{@link #INFORMIX_UNLOAD}</li>
 * <li>{@link #INFORMIX_UNLOAD_CSV}</li>
 * <li>{@link #MONGODB_CSV}</li>
 * <li>{@link #MONGODB_TSV}</li>
 * <li>{@link #MYSQL}</li>
 * <li>{@link #ORACLE}</li>
 * <li>{@link #POSTGRESQL_CSV}</li>
 * <li>{@link #POSTGRESQL_TEXT}</li>
 * <li>{@link #RFC4180}</li>
 * <li>{@link #TDF}</li>
 * </ul>
 *
 * <p>
 * For example:
 * </p>
 *
 * <pre>
 * CSVParser parser = CSVFormat.EXCEL.parse(reader);
 * </pre>
 *
 * <p>
 * The {@link CSVParser} provides static methods to parse other input types, for example:
 * </p>
 *
 * <pre>
 * CSVParser parser = CSVParser.parse(file, StandardCharsets.US_ASCII, CSVFormat.EXCEL);
 * </pre>
 *
 * <h2>Defining formats</h2>
 *
 * <p>
 * You can extend a format by calling the {@code set} methods. For example:
 * </p>
 *
 * <pre>{@code
 * CSVFormat.EXCEL.builder().setNullString("N/A").setIgnoreSurroundingSpaces(true).get();
 * }</pre>
 *
 * <h2>Defining column names</h2>
 *
 * <p>
 * To define the column names you want to use to access records, write:
 * </p>
 *
 * <pre>{@code
 * CSVFormat.EXCEL.builder().setHeader("Col1", "Col2", "Col3").get();
 * }</pre>
 *
 * <p>
 * Calling {@link Builder#setHeader(String...)} lets you use the given names to address values in a {@link CSVRecord}, and assumes that your CSV source does not
 * contain a first record that also defines column names.
 *
 * If it does, then you are overriding this metadata with your names and you should skip the first record by calling
 * {@link Builder#setSkipHeaderRecord(boolean)} with {@code true}.
 * </p>
 *
 * <h2>Parsing</h2>
 *
 * <p>
 * You can use a format directly to parse a reader. For example, to parse an Excel file with columns header, write:
 * </p>
 *
 * <pre>{@code
 * Reader in = ...;
 * CSVFormat.EXCEL.builder().setHeader("Col1", "Col2", "Col3").get().parse(in);
 * }</pre>
 *
 * <p>
 * For other input types, like resources, files, and URLs, use the static methods on {@link CSVParser}.
 * </p>
 *
 * <h2>Referencing columns safely</h2>
 *
 * <p>
 * If your source contains a header record, you can simplify your code and safely reference columns, by using {@link Builder#setHeader(String...)} with no
 * arguments:
 * </p>
 *
 * <pre>
 * CSVFormat.EXCEL.builder().setHeader().get();
 * </pre>
 *
 * <p>
 * This causes the parser to read the first record and use its values as column names.
 *
 * Then, call one of the {@link CSVRecord} get method that takes a String column name argument:
 * </p>
 *
 * <pre>{@code
 * String value = record.get("Col1");
 * }</pre>
 *
 * <p>
 * This makes your code impervious to changes in column order in the CSV file.
 * </p>
 *
 * <h2>Serialization</h2>
 * <p>
 * This class implements the {@link Serializable} interface with the following caveats:
 * </p>
 * <ul>
 * <li>This class will no longer implement Serializable in 2.0.</li>
 * <li>Serialization is not supported from one version to the next.</li>
 * </ul>
 * <p>
 * The {@code serialVersionUID} values are:
 * </p>
 * <ul>
 * <li>Version 1.10.0: {@code 2L}</li>
 * <li>Version 1.9.0 through 1.0: {@code 1L}</li>
 * </ul>
 *
 * <h2>Notes</h2>
 * <p>
 * This class is immutable.
 * </p>
 * <p>
 * Not all settings are used for both parsing and writing.
 * </p>
 


@input{test class template}
```java
package org.apache.commons.csv;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.*;
import static org.mockito.Mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
// Add other imports if necessary

@ExtendWith(MockitoExtension.class)
class CSVFormatTest {
    @BeforeAll
    static void setupBeforeAll() {
    }

    @BeforeEach
    void setupBeforeEach() {
    }

    @AfterEach
    void teardownAfterEach() {
    }

    @AfterAll
    static void teardownAfterAll() {
    }
}
```

@output{initial test class}: completed by you