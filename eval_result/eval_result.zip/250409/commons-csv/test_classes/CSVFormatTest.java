package org.apache.commons.csv;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.*;
import static org.mockito.Mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import java.io.IOException;
import java.io.StringWriter;

@ExtendWith(MockitoExtension.class)
class CSVFormatTest {
    private CSVFormat csvFormat;
    private Appendable mockAppendable;
    private StringWriter stringWriter;
    
    @BeforeAll
    static void setupBeforeAll() {
        // Initialize any static resources if needed
    }

    @BeforeEach
    void setupBeforeEach() {
        // Initialize default CSV format (RFC4180)
        csvFormat = CSVFormat.RFC4180;
        
        // Create a real StringWriter for some tests and a mock Appendable for others
        stringWriter = new StringWriter();
        mockAppendable = mock(Appendable.class);
    }

    @AfterEach
    void teardownAfterEach() {
        // Reset any mocks if needed
        Mockito.reset(mockAppendable);
        
        // Clear the string writer
        if (stringWriter != null) {
            try {
                stringWriter.close();
            } catch (IOException e) {
                // Ignore for test purposes
            }
        }
    }

    @AfterAll
    static void teardownAfterAll() {
        // Clean up any static resources if needed
    }

    @Nested
    @DisplayName("printWithQuotes tests")
    class PrintWithQuotesTests {
        
        @Test
        @DisplayName("Should quote entire string when QuoteMode is ALL")
        void shouldQuoteEntireStringWhenQuoteModeIsAll() throws IOException {
            // Setup
            CSVFormat format = csvFormat.builder().setQuoteMode(QuoteMode.ALL).get();
            String input = "test,string";
            
            // Execute
            format.printWithQuotes(null, input, stringWriter, false);
            
            // Verify
            assertEquals("\"test,string\"", stringWriter.toString());
        }

        @Test
        @DisplayName("Should quote non-numeric strings when QuoteMode is NON_NUMERIC")
        void shouldQuoteNonNumericStringsWhenQuoteModeIsNonNumeric() throws IOException {
            // Setup
            CSVFormat format = csvFormat.builder().setQuoteMode(QuoteMode.NON_NUMERIC).get();
            String stringInput = "text";
            Number numberInput = 123;
            
            // Execute
            format.printWithQuotes(null, stringInput, stringWriter, false);
            String stringResult = stringWriter.toString();
            
            stringWriter.getBuffer().setLength(0); // Reset
            format.printWithQuotes(numberInput, numberInput.toString(), stringWriter, false);
            String numberResult = stringWriter.toString();
            
            // Verify
            assertEquals("\"text\"", stringResult);
            assertEquals("123", numberResult);
        }

        @Test
        @DisplayName("Should use escapes instead of quotes when QuoteMode is NONE")
        void shouldUseEscapesWhenQuoteModeIsNone() throws IOException {
            // Setup
            CSVFormat format = csvFormat.builder().setQuoteMode(QuoteMode.NONE).get();
            String input = "test,string";
            
            // Mock the printWithEscapes method
            CSVFormat spyFormat = spy(format);
            doNothing().when(spyFormat).printWithEscapes(any(CharSequence.class), any(Appendable.class));
            
            // Execute
            spyFormat.printWithQuotes(null, input, mockAppendable, false);
            
            // Verify
            verify(spyFormat).printWithEscapes(eq(input), eq(mockAppendable));
        }

        @Test
        @DisplayName("Should quote empty string when newRecord is true in MINIMAL mode")
        void shouldQuoteEmptyStringWhenNewRecordIsTrueInMinimalMode() throws IOException {
            // Setup
            CSVFormat format = csvFormat.builder().setQuoteMode(QuoteMode.MINIMAL).get();
            
            // Execute
            format.printWithQuotes(null, "", stringWriter, true);
            
            // Verify
            assertEquals("\"\"", stringWriter.toString());
        }

        @Test
        @DisplayName("Should quote string starting with control character in MINIMAL mode")
        void shouldQuoteStringStartingWithControlCharacterInMinimalMode() throws IOException {
            // Setup
            CSVFormat format = csvFormat.builder().setQuoteMode(QuoteMode.MINIMAL).get();
            String input = "\u0001test";
            
            // Execute
            format.printWithQuotes(null, input, stringWriter, false);
            
            // Verify
            assertEquals("\"\u0001test\"", stringWriter.toString());
        }

        @Test
        @DisplayName("Should quote string containing delimiter in MINIMAL mode")
        void shouldQuoteStringContainingDelimiterInMinimalMode() throws IOException {
            // Setup
            CSVFormat format = csvFormat.builder().setQuoteMode(QuoteMode.MINIMAL).setDelimiter(',').get();
            String input = "test,string";
            
            // Execute
            format.printWithQuotes(null, input, stringWriter, false);
            
            // Verify
            assertEquals("\"test,string\"", stringWriter.toString());
        }

        @Test
        @DisplayName("Should quote string containing quote character in MINIMAL mode")
        void shouldQuoteStringContainingQuoteCharacterInMinimalMode() throws IOException {
            // Setup
            CSVFormat format = csvFormat.builder().setQuoteMode(QuoteMode.MINIMAL).setQuote('"').get();
            String input = "test\"string";
            
            // Execute
            format.printWithQuotes(null, input, stringWriter, false);
            
            // Verify
            assertEquals("\"test\"\"string\"", stringWriter.toString());
        }

        @Test
        @DisplayName("Should quote string ending with trim character in MINIMAL mode")
        void shouldQuoteStringEndingWithTrimCharacterInMinimalMode() throws IOException {
            // Setup
            CSVFormat format = csvFormat.builder().setQuoteMode(QuoteMode.MINIMAL).get();
            String input = "test ";
            
            // Execute
            format.printWithQuotes(null, input, stringWriter, false);
            
            // Verify
            assertEquals("\"test \"", stringWriter.toString());
        }

        @Test
        @DisplayName("Should escape quote characters within quoted string")
        void shouldEscapeQuoteCharactersWithinQuotedString() throws IOException {
            // Setup
            CSVFormat format = csvFormat.builder().setQuoteMode(QuoteMode.MINIMAL).setQuote('"').get();
            String input = "test\"string";
            
            // Execute
            format.printWithQuotes(null, input, stringWriter, false);
            
            // Verify
            assertEquals("\"test\"\"string\"", stringWriter.toString());
        }

        @Test
        @DisplayName("Should throw IllegalStateException for unknown QuoteMode")
        void shouldThrowIllegalStateExceptionForUnknownQuoteMode() {
            // Setup
            CSVFormat format = spy(csvFormat);
            when(format.getQuoteMode()).thenReturn(null); // Will trigger default to MINIMAL
            
            // For testing the default branch, we need to mock the enum value
            QuoteMode invalidMode = mock(QuoteMode.class);
            when(format.getQuoteMode()).thenReturn(invalidMode);
            
            // Execute & Verify
            assertThrows(IllegalStateException.class, 
                () -> format.printWithQuotes(null, "test", stringWriter, false));
        }

        @Test
        @DisplayName("Should handle IOException from Appendable")
        void shouldHandleIOExceptionFromAppendable() throws IOException {
            // Setup
            CSVFormat format = csvFormat.builder().setQuoteMode(QuoteMode.ALL).get();
            doThrow(new IOException()).when(mockAppendable).append(anyChar());
            
            // Execute & Verify
            assertThrows(IOException.class, 
                () -> format.printWithQuotes(null, "test", mockAppendable, false));
        }

        @Test
        @DisplayName("Should not quote simple string in MINIMAL mode")
        void shouldNotQuoteSimpleStringInMinimalMode() throws IOException {
            // Setup
            CSVFormat format = csvFormat.builder().setQuoteMode(QuoteMode.MINIMAL).get();
            String input = "simple_string";
            
            // Execute
            format.printWithQuotes(null, input, stringWriter, false);
            
            // Verify
            assertEquals("simple_string", stringWriter.toString());
        }

        @Test
        @DisplayName("Should use escape character when set")
        void shouldUseEscapeCharacterWhenSet() throws IOException {
            // Setup
            CSVFormat format = csvFormat.builder()
                .setQuoteMode(QuoteMode.MINIMAL)
                .setEscape('\\')
                .setQuote('"')
                .get();
            String input = "test\"string";
            
            // Execute
            format.printWithQuotes(null, input, stringWriter, false);
            
            // Verify
            assertEquals("\"test\\\"string\"", stringWriter.toString());
        }

        @Test
        @DisplayName("Should handle null object in NON_NUMERIC mode")
        void shouldHandleNullObjectInNonNumericMode() throws IOException {
            // Setup
            CSVFormat format = csvFormat.builder().setQuoteMode(QuoteMode.NON_NUMERIC).get();
            String input = "text";
            
            // Execute
            format.printWithQuotes(null, input, stringWriter, false);
            
            // Verify
            assertEquals("\"text\"", stringWriter.toString());
        }
    }
}