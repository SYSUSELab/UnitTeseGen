package org.apache.commons.csv;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.*;
import static org.mockito.Mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class CSVFormat_1_Test {
    private CSVFormat csvFormat;
    private CSVFormat.Builder builder;
    
    @BeforeAll
    static void setupBeforeAll() {
        // No setup needed for all tests
    }

    @BeforeEach
    void setupBeforeEach() {
        builder = CSVFormat.DEFAULT.builder();
        // Initialize with default values that can be modified in individual tests
        csvFormat = builder
            .setDelimiter(',')
            .setQuote('"')
            .setRecordSeparator("\n")
            .setNullString("NULL")
            .setIgnoreEmptyLines(true)
            .setIgnoreSurroundingSpaces(true)
            .setHeader("Header1", "Header2")
            .setHeaderComments("Comment1", "Comment2")
            .get();
    }

    @AfterEach
    void teardownAfterEach() {
        // Clear any mock state if needed
        Mockito.framework().clearInlineMocks();
    }

    @AfterAll
    static void teardownAfterAll() {
        // No cleanup needed after all tests
    }

    @Test
    @DisplayName("Test toString with all fields set")
    void testToStringWithAllFieldsSet() {
        // Setup: Create format with all possible fields set
        CSVFormat fullFormat = builder
            .setEscape('\\')
            .setQuoteMode(QuoteMode.ALL)
            .setCommentMarker('#')
            .setSkipHeaderRecord(true)
            .setIgnoreHeaderCase(true)
            .get();
        
        // Execute
        String result = fullFormat.toString();
        
        // Verify
        String expected = "Delimiter=<,> Escape=<\\> QuoteChar=<\"> QuoteMode=<ALL> " +
                          "CommentStart=<#> NullString=<NULL> RecordSeparator=<\\n> " +
                          "EmptyLines:ignored SurroundingSpaces:ignored IgnoreHeaderCase:ignored " +
                          "SkipHeaderRecord:true HeaderComments:[Comment1, Comment2] " +
                          "Header:[Header1, Header2]";
        assertEquals(expected, result);
    }

    @Test
    @DisplayName("Test toString with minimal fields set")
    void testToStringWithMinimalFieldsSet() {
        // Setup: Create format with only required fields
        CSVFormat minimalFormat = CSVFormat.DEFAULT.builder()
            .setDelimiter(';')
            .get();
        
        // Execute
        String result = minimalFormat.toString();
        
        // Verify
        String expected = "Delimiter=<;> SkipHeaderRecord:false";
        assertEquals(expected, result);
    }

    @Test
    @DisplayName("Test toString with no optional fields set")
    void testToStringWithNoOptionalFieldsSet() {
        // Setup: Create format with only delimiter set
        CSVFormat format = builder
            .setEscape(null)
            .setQuote(null)
            .setQuoteMode(null)
            .setCommentMarker(null)
            .setNullString(null)
            .setRecordSeparator(null)
            .setIgnoreEmptyLines(false)
            .setIgnoreSurroundingSpaces(false)
            .setIgnoreHeaderCase(false)
            .setSkipHeaderRecord(false)
            .setHeaderComments((String[]) null)
            .setHeader((String[]) null)
            .get();
        
        // Execute
        String result = format.toString();
        
        // Verify
        String expected = "Delimiter=<,> SkipHeaderRecord:false";
        assertEquals(expected, result);
    }

    @Test
    @DisplayName("Test toString with escape character set")
    void testToStringWithEscapeCharacterSet() {
        // Setup: Set only escape character
        CSVFormat format = builder
            .setEscape('\\')
            .setQuote(null)
            .setQuoteMode(null)
            .setCommentMarker(null)
            .get();
        
        // Execute
        String result = format.toString();
        
        // Verify
        String expected = "Delimiter=<,> Escape=<\\> SkipHeaderRecord:false";
        assertTrue(result.contains("Escape=<\\>"));
        assertEquals(expected, result);
    }

    @Test
    @DisplayName("Test toString with quote character set")
    void testToStringWithQuoteCharacterSet() {
        // Setup: Set only quote character
        CSVFormat format = builder
            .setEscape(null)
            .setQuote('\'')
            .setQuoteMode(null)
            .setCommentMarker(null)
            .get();
        
        // Execute
        String result = format.toString();
        
        // Verify
        String expected = "Delimiter=<,> QuoteChar=<'> SkipHeaderRecord:false";
        assertTrue(result.contains("QuoteChar=<'>"));
        assertEquals(expected, result);
    }

    @Test
    @DisplayName("Test toString with quote mode set")
    void testToStringWithQuoteModeSet() {
        // Setup: Set only quote mode
        CSVFormat format = builder
            .setEscape(null)
            .setQuote(null)
            .setQuoteMode(QuoteMode.NON_NUMERIC)
            .setCommentMarker(null)
            .get();
        
        // Execute
        String result = format.toString();
        
        // Verify
        String expected = "Delimiter=<,> QuoteMode=<NON_NUMERIC> SkipHeaderRecord:false";
        assertTrue(result.contains("QuoteMode=<NON_NUMERIC>"));
        assertEquals(expected, result);
    }

    @Test
    @DisplayName("Test toString with comment marker set")
    void testToStringWithCommentMarkerSet() {
        // Setup: Set only comment marker
        CSVFormat format = builder
            .setEscape(null)
            .setQuote(null)
            .setQuoteMode(null)
            .setCommentMarker('!')
            .get();
        
        // Execute
        String result = format.toString();
        
        // Verify
        String expected = "Delimiter=<,> CommentStart=<!> SkipHeaderRecord:false";
        assertTrue(result.contains("CommentStart=<!>"));
        assertEquals(expected, result);
    }

    @Test
    @DisplayName("Test toString with null string set")
    void testToStringWithNullStringSet() {
        // Setup: Set only null string
        CSVFormat format = builder
            .setEscape(null)
            .setQuote(null)
            .setQuoteMode(null)
            .setCommentMarker(null)
            .setNullString("\\N")
            .get();
        
        // Execute
        String result = format.toString();
        
        // Verify
        String expected = "Delimiter=<,> NullString=<\\N> SkipHeaderRecord:false";
        assertTrue(result.contains("NullString=<\\N>"));
        assertEquals(expected, result);
    }

    @Test
    @DisplayName("Test toString with record separator set")
    void testToStringWithRecordSeparatorSet() {
        // Setup: Set only record separator
        CSVFormat format = builder
            .setEscape(null)
            .setQuote(null)
            .setQuoteMode(null)
            .setCommentMarker(null)
            .setRecordSeparator("\r\n")
            .get();
        
        // Execute
        String result = format.toString();
        
        // Verify
        String expected = "Delimiter=<,> RecordSeparator=<\\r\\n> SkipHeaderRecord:false";
        assertTrue(result.contains("RecordSeparator=<\\r\\n>"));
        assertEquals(expected, result);
    }

    @Test
    @DisplayName("Test toString with boolean flags set")
    void testToStringWithBooleanFlagsSet() {
        // Setup: Set various boolean flags
        CSVFormat format = builder
            .setIgnoreEmptyLines(true)
            .setIgnoreSurroundingSpaces(true)
            .setIgnoreHeaderCase(true)
            .setSkipHeaderRecord(true)
            .get();
        
        // Execute
        String result = format.toString();
        
        // Verify
        assertTrue(result.contains("EmptyLines:ignored"));
        assertTrue(result.contains("SurroundingSpaces:ignored"));
        assertTrue(result.contains("IgnoreHeaderCase:ignored"));
        assertTrue(result.contains("SkipHeaderRecord:true"));
    }

    @Test
    @DisplayName("Test toString with headers and header comments")
    void testToStringWithHeadersAndHeaderComments() {
        // Setup: Set headers and header comments
        CSVFormat format = builder
            .setHeader("Col1", "Col2", "Col3")
            .setHeaderComments("Note1", "Note2")
            .get();
        
        // Execute
        String result = format.toString();
        
        // Verify
        assertTrue(result.contains("HeaderComments:[Note1, Note2]"));
        assertTrue(result.contains("Header:[Col1, Col2, Col3]"));
    }

    @Test
    @DisplayName("Test toString with empty headers and header comments")
    void testToStringWithEmptyHeadersAndHeaderComments() {
        // Setup: Set empty headers and header comments
        CSVFormat format = builder
            .setHeader()
            .setHeaderComments()
            .get();
        
        // Execute
        String result = format.toString();
        
        // Verify
        assertTrue(result.contains("HeaderComments:[]"));
        assertTrue(result.contains("Header:[]"));
    }

    @Test
    @DisplayName("Test toString with null headers and header comments")
    void testToStringWithNullHeadersAndHeaderComments() {
        // Setup: Set null headers and header comments
        CSVFormat format = builder
            .setHeader((String[]) null)
            .setHeaderComments((String[]) null)
            .get();
        
        // Execute
        String result = format.toString();
        
        // Verify
        assertFalse(result.contains("HeaderComments:"));
        assertFalse(result.contains("Header:"));
    }
}