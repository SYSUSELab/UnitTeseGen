package org.apache.commons.csv;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.*;
import static org.mockito.Mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

@ExtendWith(MockitoExtension.class)
class CSVParserTest {
    @Mock
    private Reader mockReader;
    
    @Mock
    private CSVFormat mockFormat;
    
    @Mock
    private Lexer mockLexer;
    
    @Mock
    private ExtendedBufferedReader mockExtendedBufferedReader;
    
    @Mock
    private CSVRecordIterator mockCsvRecordIterator;
    
    @Mock
    private CSVRecord mockCsvRecord;
    
    private CSVParser csvParser;
    private final String testCsvString = "header1,header2\nvalue1,value2";
    private final Charset testCharset = Charset.defaultCharset();

    @BeforeAll
    static void setupBeforeAll() {
        // One-time setup if needed
    }

    @BeforeEach
    void setupBeforeEach() throws IOException {
        // Initialize mocks
        MockitoAnnotations.openMocks(this);
        
        // Setup default CSVFormat behavior
        when(mockFormat.copy()).thenReturn(mockFormat);
        when(mockFormat.getHeader()).thenReturn(new String[0]);
        when(mockFormat.getSkipHeaderRecord()).thenReturn(false);
        when(mockFormat.getAllowMissingColumnNames()).thenReturn(false);
        when(mockFormat.getDuplicateHeaderMode()).thenReturn(CSVFormat.DuplicateHeaderMode.ALLOW_ALL);
        when(mockFormat.isBlank(anyString())).thenCallRealMethod();
        
        // Create a real parser instance for testing with simple CSV data
        csvParser = new CSVParser(new StringReader(testCsvString), CSVFormat.DEFAULT);
    }

    @AfterEach
    void teardownAfterEach() throws IOException {
        // Clean up resources
        if (csvParser != null && !csvParser.isClosed()) {
            csvParser.close();
        }
    }

    @AfterAll
    static void teardownAfterAll() {
        // One-time cleanup if needed
    }

    @Nested
    @DisplayName("createHeaders() tests")
    class CreateHeadersTests {
        
        @Test
        @DisplayName("Should return empty headers when format has no header")
        void createHeaders_WhenFormatHasNoHeader_ReturnsEmptyHeaders() throws IOException {
            // Setup
            when(mockFormat.getHeader()).thenReturn(null);
            CSVParser parser = new CSVParser(mockReader, mockFormat);
            
            // Execute
            Headers headers = parser.createHeaders();
            
            // Verify
            assertNotNull(headers);
            assertTrue(headers.getHeaderNames().isEmpty());
            assertTrue(headers.getHeaderMap().isEmpty());
        }
        
        @Test
        @DisplayName("Should read headers from first record when format header is empty")
        void createHeaders_WhenFormatHeaderEmpty_ReadsFromFirstRecord() throws IOException {
            // Setup
            when(mockFormat.getHeader()).thenReturn(new String[0]);
            when(mockFormat.getSkipHeaderRecord()).thenReturn(false);
            
            String[] recordValues = {"col1", "col2"};
            when(mockCsvRecord.values()).thenReturn(recordValues);
            when(mockCsvRecord.getComment()).thenReturn("test comment");
            
            CSVParser parser = spy(new CSVParser(mockReader, mockFormat));
            doReturn(mockCsvRecord).when(parser).nextRecord();
            doReturn(new LinkedHashMap<>()).when(parser).createEmptyHeaderMap();
            
            // Execute
            Headers headers = parser.createHeaders();
            
            // Verify
            assertNotNull(headers);
            assertEquals(Arrays.asList(recordValues), headers.getHeaderNames());
            assertEquals("test comment", parser.getHeaderComment());
        }
        
        @Test
        @DisplayName("Should skip header record when configured")
        void createHeaders_WhenSkipHeaderRecordTrue_SkipsFirstRecord() throws IOException {
            // Setup
            String[] formatHeader = {"col1", "col2"};
            when(mockFormat.getHeader()).thenReturn(formatHeader);
            when(mockFormat.getSkipHeaderRecord()).thenReturn(true);
            
            when(mockCsvRecord.getComment()).thenReturn("test comment");
            
            CSVParser parser = spy(new CSVParser(mockReader, mockFormat));
            doReturn(mockCsvRecord).when(parser).nextRecord();
            doReturn(new LinkedHashMap<>()).when(parser).createEmptyHeaderMap();
            
            // Execute
            Headers headers = parser.createHeaders();
            
            // Verify
            assertNotNull(headers);
            assertEquals(Arrays.asList(formatHeader), headers.getHeaderNames());
            assertEquals("test comment", parser.getHeaderComment());
        }
        
        @Test
        @DisplayName("Should use format headers when not empty and not skipping")
        void createHeaders_WhenFormatHeaderNotEmpty_UseFormatHeaders() throws IOException {
            // Setup
            String[] formatHeader = {"col1", "col2"};
            when(mockFormat.getHeader()).thenReturn(formatHeader);
            when(mockFormat.getSkipHeaderRecord()).thenReturn(false);
            
            CSVParser parser = spy(new CSVParser(mockReader, mockFormat));
            doReturn(new LinkedHashMap<>()).when(parser).createEmptyHeaderMap();
            
            // Execute
            Headers headers = parser.createHeaders();
            
            // Verify
            assertNotNull(headers);
            assertEquals(Arrays.asList(formatHeader), headers.getHeaderNames());
            assertNull(parser.getHeaderComment());
        }
        
        @Test
        @DisplayName("Should throw exception when missing column names not allowed")
        void createHeaders_WhenMissingColumnNamesNotAllowed_ThrowsException() throws IOException {
            // Setup
            String[] formatHeader = {"col1", ""};
            when(mockFormat.getHeader()).thenReturn(formatHeader);
            when(mockFormat.getAllowMissingColumnNames()).thenReturn(false);
            
            CSVParser parser = spy(new CSVParser(mockReader, mockFormat));
            doReturn(new LinkedHashMap<>()).when(parser).createEmptyHeaderMap();
            
            // Execute & Verify
            IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, 
                () -> parser.createHeaders());
            assertTrue(exception.getMessage().contains("A header name is missing"));
        }
        
        @Test
        @DisplayName("Should allow missing column names when configured")
        void createHeaders_WhenMissingColumnNamesAllowed_ProcessesHeaders() throws IOException {
            // Setup
            String[] formatHeader = {"col1", ""};
            when(mockFormat.getHeader()).thenReturn(formatHeader);
            when(mockFormat.getAllowMissingColumnNames()).thenReturn(true);
            
            CSVParser parser = spy(new CSVParser(mockReader, mockFormat));
            doReturn(new LinkedHashMap<>()).when(parser).createEmptyHeaderMap();
            
            // Execute
            Headers headers = parser.createHeaders();
            
            // Verify
            assertNotNull(headers);
            assertEquals(1, headers.getHeaderNames().size());
            assertEquals("col1", headers.getHeaderNames().get(0));
        }
        
        @Test
        @DisplayName("Should throw exception for duplicate headers when not allowed")
        void createHeaders_WhenDuplicateHeadersNotAllowed_ThrowsException() throws IOException {
            // Setup
            String[] formatHeader = {"col1", "col1"};
            when(mockFormat.getHeader()).thenReturn(formatHeader);
            when(mockFormat.getDuplicateHeaderMode()).thenReturn(CSVFormat.DuplicateHeaderMode.DISALLOW);
            
            CSVParser parser = spy(new CSVParser(mockReader, mockFormat));
            doReturn(new LinkedHashMap<>()).when(parser).createEmptyHeaderMap();
            
            // Execute & Verify
            IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, 
                () -> parser.createHeaders());
            assertTrue(exception.getMessage().contains("The header contains a duplicate name"));
        }
        
        @Test
        @DisplayName("Should allow duplicate empty headers when configured")
        void createHeaders_WhenDuplicateEmptyHeadersAllowed_ProcessesHeaders() throws IOException {
            // Setup
            String[] formatHeader = {"", ""};
            when(mockFormat.getHeader()).thenReturn(formatHeader);
            when(mockFormat.getDuplicateHeaderMode()).thenReturn(CSVFormat.DuplicateHeaderMode.ALLOW_EMPTY);
            when(mockFormat.getAllowMissingColumnNames()).thenReturn(true);
            
            CSVParser parser = spy(new CSVParser(mockReader, mockFormat));
            doReturn(new LinkedHashMap<>()).when(parser).createEmptyHeaderMap();
            
            // Execute
            Headers headers = parser.createHeaders();
            
            // Verify
            assertNotNull(headers);
            assertTrue(headers.getHeaderNames().isEmpty());
        }
        
        @Test
        @DisplayName("Should return empty headers when no records available")
        void createHeaders_WhenNoRecordsAvailable_ReturnsEmptyHeaders() throws IOException {
            // Setup
            when(mockFormat.getHeader()).thenReturn(new String[0]);
            when(mockFormat.getSkipHeaderRecord()).thenReturn(false);
            
            CSVParser parser = spy(new CSVParser(mockReader, mockFormat));
            doReturn(null).when(parser).nextRecord();
            doReturn(new LinkedHashMap<>()).when(parser).createEmptyHeaderMap();
            
            // Execute
            Headers headers = parser.createHeaders();
            
            // Verify
            assertNotNull(headers);
            assertTrue(headers.getHeaderNames().isEmpty());
            assertTrue(headers.getHeaderMap().isEmpty());
        }
        
        @Test
        @DisplayName("Should handle null header values when allowed")
        void createHeaders_WhenNullHeaderValues_ProcessesCorrectly() throws IOException {
            // Setup
            String[] formatHeader = {"col1", null};
            when(mockFormat.getHeader()).thenReturn(formatHeader);
            when(mockFormat.getAllowMissingColumnNames()).thenReturn(true);
            
            CSVParser parser = spy(new CSVParser(mockReader, mockFormat));
            doReturn(new LinkedHashMap<>()).when(parser).createEmptyHeaderMap();
            
            // Execute
            Headers headers = parser.createHeaders();
            
            // Verify
            assertNotNull(headers);
            assertEquals(1, headers.getHeaderNames().size());
            assertEquals("col1", headers.getHeaderNames().get(0));
        }
    }
}