package org.apache.commons.csv;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.*;
import static org.mockito.Mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.Charset;

@ExtendWith(MockitoExtension.class)
class CSVParser_1_Test {
    @Mock
    private Lexer lexer;
    
    @Mock
    private ExtendedBufferedReader bufferedReader;
    
    private CSVParser parser;
    private CSVFormat format;
    private Reader reader;
    private Token reusableToken;

    @BeforeAll
    static void setupBeforeAll() {
        // Initialize any static resources if needed
    }

    @BeforeEach
    void setupBeforeEach() throws IOException {
        format = CSVFormat.DEFAULT;
        reader = new StringReader("test,data\nanother,record");
        parser = new CSVParser(reader, format);
        
        // Initialize reusableToken
        reusableToken = new Token();
        
        // Mock lexer behavior if needed
        when(lexer.getCharacterPosition()).thenReturn(0L);
        when(lexer.getBytesRead()).thenReturn(0L);
    }

    @AfterEach
    void teardownAfterEach() throws IOException {
        if (parser != null) {
            parser.close();
        }
        if (reader != null) {
            reader.close();
        }
    }

    @AfterAll
    static void teardownAfterAll() {
        // Clean up any static resources if needed
    }

    @Test
    void nextRecord_ShouldReturnNullWhenNoRecords() throws IOException {
        // Setup
        CSVParser parser = new CSVParser(new StringReader(""), format);
        
        // Execute
        CSVRecord result = parser.nextRecord();
        
        // Verify
        assertNull(result, "Should return null for empty input");
    }

    @Test
    void nextRecord_ShouldParseSimpleRecord() throws IOException {
        // Setup
        String input = "field1,field2";
        CSVParser parser = new CSVParser(new StringReader(input), format);
        
        // Execute
        CSVRecord result = parser.nextRecord();
        
        // Verify
        assertNotNull(result, "Should return a record");
        assertEquals(2, result.size(), "Should have 2 fields");
        assertEquals("field1", result.get(0), "First field should match");
        assertEquals("field2", result.get(1), "Second field should match");
    }

    @Test
    void nextRecord_ShouldHandleEORECORDToken() throws IOException {
        // Setup
        Token token = new Token();
        token.type = Token.Type.EORECORD;
        token.isReady = true;
        
        when(lexer.nextToken(any())).thenReturn(token);
        
        CSVParser parser = new CSVParser(reader, format);
        parser.lexer = lexer;
        
        // Execute
        CSVRecord result = parser.nextRecord();
        
        // Verify
        assertNotNull(result, "Should return a record for EORECORD token");
    }

    @Test
    void nextRecord_ShouldHandleEOFWithReadyToken() throws IOException {
        // Setup
        Token token = new Token();
        token.type = Token.Type.EOF;
        token.isReady = true;
        
        when(lexer.nextToken(any())).thenReturn(token);
        
        CSVParser parser = new CSVParser(reader, format);
        parser.lexer = lexer;
        
        // Execute
        CSVRecord result = parser.nextRecord();
        
        // Verify
        assertNotNull(result, "Should return a record for EOF with ready token");
    }

    @Test
    void nextRecord_ShouldHandleEOFWithTrailerComment() throws IOException {
        // Setup
        Token token = new Token();
        token.type = Token.Type.EOF;
        token.isReady = false;
        token.content = "comment";
        
        when(lexer.nextToken(any())).thenReturn(token);
        
        CSVParser parser = new CSVParser(reader, format);
        parser.lexer = lexer;
        
        // Execute
        CSVRecord result = parser.nextRecord();
        
        // Verify
        assertNull(result, "Should return null for EOF without ready token");
        assertEquals("comment", parser.getTrailerComment(), "Should set trailer comment");
    }

    @Test
    void nextRecord_ShouldThrowExceptionForInvalidToken() {
        // Setup
        Token token = new Token();
        token.type = Token.Type.INVALID;
        
        when(lexer.nextToken(any())).thenReturn(token);
        
        CSVParser parser = new CSVParser(reader, format);
        parser.lexer = lexer;
        
        // Execute & Verify
        assertThrows(CSVException.class, () -> parser.nextRecord(),
            "Should throw CSVException for INVALID token");
    }

    @Test
    void nextRecord_ShouldHandleCommentTokens() throws IOException {
        // Setup
        Token token1 = new Token();
        token1.type = Token.Type.COMMENT;
        token1.content = "comment1";
        
        Token token2 = new Token();
        token2.type = Token.Type.TOKEN;
        token2.content = "field1";
        
        Token token3 = new Token();
        token3.type = Token.Type.EORECORD;
        
        when(lexer.nextToken(any()))
            .thenReturn(token1)
            .thenReturn(token2)
            .thenReturn(token3);
        
        CSVParser parser = new CSVParser(reader, format);
        parser.lexer = lexer;
        
        // Execute
        CSVRecord result = parser.nextRecord();
        
        // Verify
        assertNotNull(result, "Should return a record");
        assertEquals("comment1", result.getComment(), "Should include comment in record");
    }

    @Test
    void nextRecord_ShouldHandleMultipleCommentTokens() throws IOException {
        // Setup
        Token token1 = new Token();
        token1.type = Token.Type.COMMENT;
        token1.content = "comment1";
        
        Token token2 = new Token();
        token2.type = Token.Type.COMMENT;
        token2.content = "comment2";
        
        Token token3 = new Token();
        token3.type = Token.Type.TOKEN;
        token3.content = "field1";
        
        Token token4 = new Token();
        token4.type = Token.Type.EORECORD;
        
        when(lexer.nextToken(any()))
            .thenReturn(token1)
            .thenReturn(token2)
            .thenReturn(token3)
            .thenReturn(token4);
        
        CSVParser parser = new CSVParser(reader, format);
        parser.lexer = lexer;
        
        // Execute
        CSVRecord result = parser.nextRecord();
        
        // Verify
        assertNotNull(result, "Should return a record");
        assertEquals("comment1" + Constants.LF + "comment2", result.getComment(), 
            "Should concatenate multiple comments");
    }

    @Test
    void nextRecord_ShouldIncrementRecordNumber() throws IOException {
        // Setup
        String input = "field1,field2\nfield3,field4";
        CSVParser parser = new CSVParser(new StringReader(input), format);
        
        // Execute
        CSVRecord firstRecord = parser.nextRecord();
        CSVRecord secondRecord = parser.nextRecord();
        
        // Verify
        assertEquals(0, firstRecord.getRecordNumber(), "First record should have number 0");
        assertEquals(1, secondRecord.getRecordNumber(), "Second record should have number 1");
    }

    @Test
    void nextRecord_ShouldTrackCharacterPositions() throws IOException {
        // Setup
        String input = "field1,field2";
        CSVParser parser = new CSVParser(new StringReader(input), format);
        
        // Execute
        CSVRecord result = parser.nextRecord();
        
        // Verify
        assertEquals(0, result.getCharacterPosition(), "Should track character position");
    }

    @Test
    void nextRecord_ShouldThrowExceptionForUnexpectedTokenType() {
        // Setup
        Token token = new Token();
        token.type = Token.Type.IGNORED; // This type should not be encountered
        
        when(lexer.nextToken(any())).thenReturn(token);
        
        CSVParser parser = new CSVParser(reader, format);
        parser.lexer = lexer;
        
        // Execute & Verify
        assertThrows(CSVException.class, () -> parser.nextRecord(),
            "Should throw CSVException for unexpected token type");
    }
}