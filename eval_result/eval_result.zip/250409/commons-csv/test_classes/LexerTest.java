package org.apache.commons.csv;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.*;
import static org.mockito.Mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import java.io.IOException;

@ExtendWith(MockitoExtension.class)
class LexerTest {
    @Mock
    private ExtendedBufferedReader reader;
    
    @Mock
    private CSVFormat format;
    
    private Lexer lexer;
    private Token token;
    
    @BeforeAll
    static void setupBeforeAll() {
        // One-time setup code if needed
    }

    @BeforeEach
    void setupBeforeEach() throws IOException {
        // Initialize mocks
        MockitoAnnotations.openMocks(this);
        
        // Setup CSVFormat mock
        when(format.getDelimiterCharArray()).thenReturn(new char[]{','});
        when(format.getEscapeCharacter()).thenReturn('\\');
        when(format.getQuoteCharacter()).thenReturn('"');
        when(format.getCommentMarker()).thenReturn('#');
        when(format.getIgnoreSurroundingSpaces()).thenReturn(false);
        when(format.getIgnoreEmptyLines()).thenReturn(false);
        when(format.getLenientEof()).thenReturn(false);
        when(format.getTrailingData()).thenReturn(false);
        
        // Create Lexer instance
        lexer = new Lexer(format, reader);
        
        // Initialize test token
        token = new Token();
    }

    @AfterEach
    void teardownAfterEach() throws IOException {
        // Clean up resources if needed
        if (lexer != null) {
            lexer.close();
        }
    }

    @AfterAll
    static void teardownAfterAll() {
        // One-time cleanup code if needed
    }

    @Test
    void parseEncapsulatedToken_ShouldHandleDoubleQuoteCharacters() throws IOException {
        // Setup: double quote scenario ("")
        when(reader.read()).thenReturn((int) '"', (int) '"', (int) ',');
        when(reader.peek()).thenReturn((int) '"');
        when(lexer.isQuoteChar('"')).thenReturn(true);
        when(lexer.isDelimiter(',')).thenReturn(true);

        // Execute
        Token result = lexer.parseEncapsulatedToken(token);

        // Verify
        assertEquals(Token.Type.TOKEN, result.type);
        assertTrue(result.isQuoted);
        assertEquals("\"", result.content.toString());
        verify(reader, times(3)).read();
    }

    @Test
    void parseEncapsulatedToken_ShouldReturnTokenWhenEncounteringDelimiter() throws IOException {
        // Setup: single quote followed by delimiter (",)
        when(reader.read()).thenReturn((int) '"', (int) ',');
        when(lexer.isQuoteChar('"')).thenReturn(true);
        when(lexer.isDelimiter(',')).thenReturn(true);

        // Execute
        Token result = lexer.parseEncapsulatedToken(token);

        // Verify
        assertEquals(Token.Type.TOKEN, result.type);
        assertTrue(result.isQuoted);
        assertEquals("", result.content.toString());
    }

    @Test
    void parseEncapsulatedToken_ShouldReturnEORECORDWhenEncounteringEndOfLine() throws IOException {
        // Setup: single quote followed by end of line
        when(reader.read()).thenReturn((int) '"', (int) '\n');
        when(lexer.isQuoteChar('"')).thenReturn(true);
        when(lexer.readEndOfLine('\n')).thenReturn(true);

        // Execute
        Token result = lexer.parseEncapsulatedToken(token);

        // Verify
        assertEquals(Token.Type.EORECORD, result.type);
        assertTrue(result.isQuoted);
        assertEquals("", result.content.toString());
    }

    @Test
    void parseEncapsulatedToken_ShouldReturnEOFWhenEncounteringEndOfFile() throws IOException {
        // Setup: single quote followed by EOF
        when(reader.read()).thenReturn((int) '"', IOUtils.EOF);
        when(lexer.isQuoteChar('"')).thenReturn(true);
        when(lexer.isEndOfFile(IOUtils.EOF)).thenReturn(true);

        // Execute
        Token result = lexer.parseEncapsulatedToken(token);

        // Verify
        assertEquals(Token.Type.EOF, result.type);
        assertTrue(result.isQuoted);
        assertTrue(result.isReady);
        assertEquals("", result.content.toString());
    }

    @Test
    void parseEncapsulatedToken_ShouldHandleEscapedCharacters() throws IOException {
        // Setup: escape character followed by another character
        when(reader.read()).thenReturn((int) '\\', (int) 'n', (int) '"', (int) ',');
        when(lexer.isEscape('\\')).thenReturn(true);
        when(lexer.isQuoteChar('"')).thenReturn(true);
        when(lexer.isDelimiter(',')).thenReturn(true);
        
        // Mock the appendNextEscapedCharacterToToken behavior
        doAnswer(invocation -> {
            Token t = invocation.getArgument(0);
            t.content.append('n');
            return null;
        }).when(lexer).appendNextEscapedCharacterToToken(any(Token.class));

        // Execute
        Token result = lexer.parseEncapsulatedToken(token);

        // Verify
        assertEquals(Token.Type.TOKEN, result.type);
        assertTrue(result.isQuoted);
        assertEquals("n", result.content.toString());
        verify(lexer).appendNextEscapedCharacterToToken(any(Token.class));
    }

    @Test
    void parseEncapsulatedToken_ShouldThrowExceptionOnInvalidCharacterAfterQuote() throws IOException {
        // Setup: quote followed by invalid character (non-whitespace)
        when(reader.read()).thenReturn((int) '"', (int) 'x');
        when(lexer.isQuoteChar('"')).thenReturn(true);
        when(lexer.isDelimiter('x')).thenReturn(false);
        when(lexer.isEndOfFile('x')).thenReturn(false);
        when(lexer.readEndOfLine('x')).thenReturn(false);
        when(lexer.getCurrentLineNumber()).thenReturn(1L);
        when(lexer.getCharacterPosition()).thenReturn(1L);

        // Execute & Verify
        CSVException exception = assertThrows(CSVException.class, 
            () -> lexer.parseEncapsulatedToken(token));
        assertEquals("Invalid character between encapsulated token and delimiter at line: 1, position: 1", 
            exception.getMessage());
    }

    @Test
    void parseEncapsulatedToken_ShouldThrowExceptionOnPrematureEOF() throws IOException {
        // Setup: EOF before closing quote
        when(reader.read()).thenReturn(IOUtils.EOF);
        when(lexer.isEndOfFile(IOUtils.EOF)).thenReturn(true);
        when(lexer.getCurrentLineNumber()).thenReturn(1L);

        // Execute & Verify
        CSVException exception = assertThrows(CSVException.class, 
            () -> lexer.parseEncapsulatedToken(token));
        assertEquals("(startline 1) EOF reached before encapsulated token finished", 
            exception.getMessage());
    }

    @Test
    void parseEncapsulatedToken_ShouldHandleLenientEOF() throws IOException {
        // Setup: lenient EOF enabled
        when(format.getLenientEof()).thenReturn(true);
        lexer = new Lexer(format, reader);
        
        when(reader.read()).thenReturn(IOUtils.EOF);
        when(lexer.isEndOfFile(IOUtils.EOF)).thenReturn(true);

        // Execute
        Token result = lexer.parseEncapsulatedToken(token);

        // Verify
        assertEquals(Token.Type.EOF, result.type);
        assertTrue(result.isQuoted);
        assertTrue(result.isReady);
    }

    @Test
    void parseEncapsulatedToken_ShouldHandleTrailingData() throws IOException {
        // Setup: trailing data enabled
        when(format.getTrailingData()).thenReturn(true);
        lexer = new Lexer(format, reader);
        
        when(reader.read()).thenReturn((int) '"', (int) 'x', (int) ',');
        when(lexer.isQuoteChar('"')).thenReturn(true);
        when(lexer.isDelimiter(',')).thenReturn(true);

        // Execute
        Token result = lexer.parseEncapsulatedToken(token);

        // Verify
        assertEquals(Token.Type.TOKEN, result.type);
        assertTrue(result.isQuoted);
        assertEquals("x", result.content.toString());
    }

    @Test
    void parseEncapsulatedToken_ShouldAppendRegularCharacters() throws IOException {
        // Setup: regular characters between quotes
        when(reader.read()).thenReturn((int) 'a', (int) 'b', (int) '"', (int) ',');
        when(lexer.isQuoteChar('"')).thenReturn(true);
        when(lexer.isDelimiter(',')).thenReturn(true);

        // Execute
        Token result = lexer.parseEncapsulatedToken(token);

        // Verify
        assertEquals(Token.Type.TOKEN, result.type);
        assertTrue(result.isQuoted);
        assertEquals("ab", result.content.toString());
    }
}